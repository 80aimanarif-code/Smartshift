package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class NegotiationOffer {
    public double amount;
    public String senderRole;
    public long timestamp;
    public String type;

    public NegotiationOffer() {
    }

    public NegotiationOffer(String senderRole, double amount, String type, long timestamp) {
        this.senderRole = senderRole;
        this.amount = amount;
        this.type = type;
        this.timestamp = timestamp;
    }
}
