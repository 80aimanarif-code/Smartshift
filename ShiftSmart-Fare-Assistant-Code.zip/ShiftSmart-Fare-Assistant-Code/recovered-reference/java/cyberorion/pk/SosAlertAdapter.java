package cyberorion.pk;

import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class SosAlertAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final List<SosAlert> alerts;
    private final OnSosActionListener listener;

    public interface OnSosActionListener {
        void onResolve(SosAlert sosAlert);

        void onViewLocation(SosAlert sosAlert);
    }

    public SosAlertAdapter(List<SosAlert> alerts, OnSosActionListener listener) {
        this.alerts = alerts;
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sos_alert, parent, false);
        return new ViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        final SosAlert alert = this.alerts.get(position);
        String who = BookingKeys.ROLE_DRIVER.equals(alert.role) ? "Driver" : "Customer";
        holder.tvWho.setText(who + " • Booking " + shortId(alert.bookingId));
        holder.tvMessage.setText((alert.message == null || alert.message.isEmpty()) ? "Emergency assistance requested" : alert.message);
        holder.tvTime.setText(DateFormat.format("MMM d, yyyy, h:mm a", alert.timestamp));
        boolean hasLocation = (alert.lat == null || alert.lng == null) ? false : true;
        holder.btnViewLocation.setVisibility(hasLocation ? 0 : 8);
        holder.btnViewLocation.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.SosAlertAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m457lambda$onBindViewHolder$0$cyberorionpkSosAlertAdapter(alert, view);
            }
        });
        holder.btnResolve.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.SosAlertAdapter$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m458lambda$onBindViewHolder$1$cyberorionpkSosAlertAdapter(alert, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-SosAlertAdapter, reason: not valid java name */
    /* synthetic */ void m457lambda$onBindViewHolder$0$cyberorionpkSosAlertAdapter(SosAlert alert, View v) {
        this.listener.onViewLocation(alert);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$1$cyberorion-pk-SosAlertAdapter, reason: not valid java name */
    /* synthetic */ void m458lambda$onBindViewHolder$1$cyberorionpkSosAlertAdapter(SosAlert alert, View v) {
        this.listener.onResolve(alert);
    }

    private String shortId(String bookingId) {
        if (bookingId == null) {
            return "—";
        }
        return bookingId.length() > 6 ? bookingId.substring(bookingId.length() - 6) : bookingId;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.alerts.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialButton btnResolve;
        MaterialButton btnViewLocation;
        TextView tvMessage;
        TextView tvTime;
        TextView tvWho;

        ViewHolder(View itemView) {
            super(itemView);
            this.tvWho = (TextView) itemView.findViewById(R.id.tvSosWho);
            this.tvMessage = (TextView) itemView.findViewById(R.id.tvSosMessage);
            this.tvTime = (TextView) itemView.findViewById(R.id.tvSosTime);
            this.btnResolve = (MaterialButton) itemView.findViewById(R.id.btnSosResolve);
            this.btnViewLocation = (MaterialButton) itemView.findViewById(R.id.btnSosViewLocation);
        }
    }
}
