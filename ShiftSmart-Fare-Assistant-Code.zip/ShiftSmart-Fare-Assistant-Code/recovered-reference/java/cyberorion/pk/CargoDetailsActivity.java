package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.TextInputEditText;

/* JADX INFO: loaded from: classes3.dex */
public class CargoDetailsActivity extends AppCompatActivity {
    private static final int MAX_LABOR = 10;
    private static final int MAX_QUANTITY = 99;
    private static final int MIN_LABOR = 1;
    private static final int MIN_QUANTITY = 1;
    private AutoCompleteTextView actRouteType;
    private TextInputEditText etDimensions;
    private TextInputEditText etSpecialHandling;
    private TextInputEditText etWeight;
    private View layoutLaborCount;
    private CargoSelection selection;
    private MaterialSwitch switchLoading;
    private MaterialSwitch switchUnloading;
    private TextView tvLaborCount;
    private TextView tvQuantity;
    private int quantity = 1;
    private int laborCount = 1;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        String string;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cargo_details);
        this.selection = (CargoSelection) getIntent().getSerializableExtra(BookingKeys.EXTRA_CARGO_SELECTION);
        if (this.selection == null) {
            this.selection = new CargoSelection();
            this.selection.cargoCategoryName = "Cargo";
        }
        TextView tvSelectedCategory = (TextView) findViewById(R.id.tvSelectedCategory);
        if (this.selection.fragile) {
            string = getString(R.string.selected_category_fragile_format, new Object[]{this.selection.cargoCategoryName});
        } else {
            string = this.selection.cargoCategoryName;
        }
        tvSelectedCategory.setText(string);
        this.tvQuantity = (TextView) findViewById(R.id.tvQuantity);
        this.etWeight = (TextInputEditText) findViewById(R.id.etWeight);
        this.etDimensions = (TextInputEditText) findViewById(R.id.etDimensions);
        this.etSpecialHandling = (TextInputEditText) findViewById(R.id.etSpecialHandling);
        this.actRouteType = (AutoCompleteTextView) findViewById(R.id.actRouteType);
        String[] routeTypes = {"Factory → Warehouse", "Warehouse → Factory", "Supplier → Factory", "Factory → Customer", "Other / General"};
        this.actRouteType.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, routeTypes));
        this.actRouteType.setText((CharSequence) ((this.selection.routeType == null || this.selection.routeType.isEmpty()) ? routeTypes[0] : this.selection.routeType), false);
        findViewById(R.id.btnQtyMinus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m319lambda$onCreate$0$cyberorionpkCargoDetailsActivity(view);
            }
        });
        findViewById(R.id.btnQtyPlus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m320lambda$onCreate$1$cyberorionpkCargoDetailsActivity(view);
            }
        });
        this.switchLoading = (MaterialSwitch) findViewById(R.id.switchLoading);
        this.switchUnloading = (MaterialSwitch) findViewById(R.id.switchUnloading);
        this.layoutLaborCount = findViewById(R.id.layoutLaborCount);
        this.tvLaborCount = (TextView) findViewById(R.id.tvLaborCount);
        this.switchLoading.setChecked(this.selection.loadingRequired);
        this.switchUnloading.setChecked(this.selection.unloadingRequired);
        this.laborCount = this.selection.laborCount > 0 ? this.selection.laborCount : 1;
        this.tvLaborCount.setText(String.valueOf(this.laborCount));
        this.switchLoading.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda2
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.m321lambda$onCreate$2$cyberorionpkCargoDetailsActivity(compoundButton, z);
            }
        });
        this.switchUnloading.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda3
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.m322lambda$onCreate$3$cyberorionpkCargoDetailsActivity(compoundButton, z);
            }
        });
        refreshLaborVisibility();
        findViewById(R.id.btnLaborMinus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m323lambda$onCreate$4$cyberorionpkCargoDetailsActivity(view);
            }
        });
        findViewById(R.id.btnLaborPlus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m324lambda$onCreate$5$cyberorionpkCargoDetailsActivity(view);
            }
        });
        Button btnNext = (Button) findViewById(R.id.btnNextDetails);
        btnNext.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoDetailsActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m325lambda$onCreate$6$cyberorionpkCargoDetailsActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m319lambda$onCreate$0$cyberorionpkCargoDetailsActivity(View v) {
        changeQuantity(-1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m320lambda$onCreate$1$cyberorionpkCargoDetailsActivity(View v) {
        changeQuantity(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m321lambda$onCreate$2$cyberorionpkCargoDetailsActivity(CompoundButton btn, boolean checked) {
        refreshLaborVisibility();
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m322lambda$onCreate$3$cyberorionpkCargoDetailsActivity(CompoundButton btn, boolean checked) {
        refreshLaborVisibility();
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m323lambda$onCreate$4$cyberorionpkCargoDetailsActivity(View v) {
        changeLaborCount(-1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$5$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m324lambda$onCreate$5$cyberorionpkCargoDetailsActivity(View v) {
        changeLaborCount(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$6$cyberorion-pk-CargoDetailsActivity, reason: not valid java name */
    /* synthetic */ void m325lambda$onCreate$6$cyberorionpkCargoDetailsActivity(View v) {
        goToRoute();
    }

    private void changeQuantity(int delta) {
        int newQuantity = this.quantity + delta;
        if (newQuantity < 1 || newQuantity > MAX_QUANTITY) {
            return;
        }
        this.quantity = newQuantity;
        this.tvQuantity.setText(String.valueOf(this.quantity));
    }

    private void refreshLaborVisibility() {
        boolean needsLabor = this.switchLoading.isChecked() || this.switchUnloading.isChecked();
        this.layoutLaborCount.setVisibility(needsLabor ? 0 : 8);
    }

    private void changeLaborCount(int delta) {
        int newCount = this.laborCount + delta;
        if (newCount < 1 || newCount > 10) {
            return;
        }
        this.laborCount = newCount;
        this.tvLaborCount.setText(String.valueOf(this.laborCount));
    }

    private void goToRoute() {
        String weightText = this.etWeight.getText() != null ? this.etWeight.getText().toString().trim() : "";
        this.selection.quantity = this.quantity;
        this.selection.dimensions = this.etDimensions.getText() != null ? this.etDimensions.getText().toString().trim() : "";
        this.selection.specialHandling = this.etSpecialHandling.getText() != null ? this.etSpecialHandling.getText().toString().trim() : "";
        this.selection.routeType = this.actRouteType.getText() != null ? this.actRouteType.getText().toString().trim() : "Other / General";
        boolean zIsEmpty = TextUtils.isEmpty(weightText);
        CargoSelection cargoSelection = this.selection;
        if (!zIsEmpty) {
            try {
                cargoSelection.weightKg = Double.parseDouble(weightText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, R.string.invalid_weight_message, 0).show();
                return;
            }
        } else {
            cargoSelection.weightKg = this.selection.approxCapacityKg;
        }
        this.selection.loadingRequired = this.switchLoading.isChecked();
        this.selection.unloadingRequired = this.switchUnloading.isChecked();
        this.selection.laborCount = (this.selection.loadingRequired || this.selection.unloadingRequired) ? this.laborCount : 1;
        Intent intent = new Intent(this, (Class<?>) BookingActivity.class);
        intent.putExtra(BookingKeys.EXTRA_CARGO_SELECTION, this.selection);
        intent.putExtra(BookingKeys.EXTRA_LUGGAGE_TYPE, this.selection.cargoCategoryName);
        startActivity(intent);
    }
}
