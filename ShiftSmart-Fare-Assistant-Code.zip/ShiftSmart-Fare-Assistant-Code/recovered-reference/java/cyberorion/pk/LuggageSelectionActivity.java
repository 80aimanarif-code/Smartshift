package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

/* JADX INFO: loaded from: classes3.dex */
public class LuggageSelectionActivity extends AppCompatActivity {
    private Button btnNext;
    private MaterialCardView cardFragile;
    private MaterialCardView cardHeavy;
    private MaterialCardView cardMedium;
    private MaterialCardView cardSmall;
    private ImageView ivCheckFragile;
    private ImageView ivCheckHeavy;
    private ImageView ivCheckMedium;
    private ImageView ivCheckSmall;
    private String selectedType = null;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_luggage_selection);
        this.cardSmall = (MaterialCardView) findViewById(R.id.cardLuggageSmall);
        this.cardMedium = (MaterialCardView) findViewById(R.id.cardLuggageMedium);
        this.cardHeavy = (MaterialCardView) findViewById(R.id.cardLuggageHeavy);
        this.cardFragile = (MaterialCardView) findViewById(R.id.cardLuggageFragile);
        this.ivCheckSmall = (ImageView) findViewById(R.id.ivCheckSmall);
        this.ivCheckMedium = (ImageView) findViewById(R.id.ivCheckMedium);
        this.ivCheckHeavy = (ImageView) findViewById(R.id.ivCheckHeavy);
        this.ivCheckFragile = (ImageView) findViewById(R.id.ivCheckFragile);
        this.btnNext = (Button) findViewById(R.id.btnNextLuggage);
        this.btnNext.setEnabled(false);
        this.cardSmall.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LuggageSelectionActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m409lambda$onCreate$0$cyberorionpkLuggageSelectionActivity(view);
            }
        });
        this.cardMedium.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LuggageSelectionActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m410lambda$onCreate$1$cyberorionpkLuggageSelectionActivity(view);
            }
        });
        this.cardHeavy.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LuggageSelectionActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m411lambda$onCreate$2$cyberorionpkLuggageSelectionActivity(view);
            }
        });
        this.cardFragile.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LuggageSelectionActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m412lambda$onCreate$3$cyberorionpkLuggageSelectionActivity(view);
            }
        });
        this.btnNext.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LuggageSelectionActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m413lambda$onCreate$4$cyberorionpkLuggageSelectionActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-LuggageSelectionActivity, reason: not valid java name */
    /* synthetic */ void m409lambda$onCreate$0$cyberorionpkLuggageSelectionActivity(View v) {
        select(getString(R.string.luggage_small_title), this.cardSmall, this.ivCheckSmall);
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-LuggageSelectionActivity, reason: not valid java name */
    /* synthetic */ void m410lambda$onCreate$1$cyberorionpkLuggageSelectionActivity(View v) {
        select(getString(R.string.luggage_medium_title), this.cardMedium, this.ivCheckMedium);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-LuggageSelectionActivity, reason: not valid java name */
    /* synthetic */ void m411lambda$onCreate$2$cyberorionpkLuggageSelectionActivity(View v) {
        select(getString(R.string.luggage_heavy_title), this.cardHeavy, this.ivCheckHeavy);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-LuggageSelectionActivity, reason: not valid java name */
    /* synthetic */ void m412lambda$onCreate$3$cyberorionpkLuggageSelectionActivity(View v) {
        select(getString(R.string.luggage_fragile_title), this.cardFragile, this.ivCheckFragile);
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-LuggageSelectionActivity, reason: not valid java name */
    /* synthetic */ void m413lambda$onCreate$4$cyberorionpkLuggageSelectionActivity(View v) {
        Intent intent = new Intent(this, (Class<?>) BookingActivity.class);
        intent.putExtra(BookingKeys.EXTRA_LUGGAGE_TYPE, this.selectedType);
        startActivity(intent);
    }

    private void select(String type, MaterialCardView selectedCard, ImageView checkIcon) {
        this.selectedType = type;
        this.btnNext.setEnabled(true);
        resetCard(this.cardSmall, this.ivCheckSmall);
        resetCard(this.cardMedium, this.ivCheckMedium);
        resetCard(this.cardHeavy, this.ivCheckHeavy);
        resetCard(this.cardFragile, this.ivCheckFragile);
        selectedCard.setStrokeWidth(4);
        selectedCard.setStrokeColor(getColor(R.color.primaryColor));
        checkIcon.setVisibility(0);
    }

    private void resetCard(MaterialCardView card, ImageView checkIcon) {
        card.setStrokeWidth(1);
        card.setStrokeColor(getColor(R.color.lightGray));
        checkIcon.setVisibility(8);
    }
}
