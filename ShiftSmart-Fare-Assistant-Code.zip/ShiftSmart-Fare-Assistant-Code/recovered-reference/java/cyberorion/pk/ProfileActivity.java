package cyberorion.pk;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class ProfileActivity extends AppCompatActivity {
    private MaterialButton btnAdminDashboard;
    private User loadedUser;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private TextView tvEmail;
    private TextView tvName;
    private TextView tvPhone;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        this.mAuth = FirebaseAuth.getInstance();
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
        this.tvName = (TextView) findViewById(R.id.tvProfileName);
        this.tvEmail = (TextView) findViewById(R.id.tvProfileEmail);
        this.tvPhone = (TextView) findViewById(R.id.tvProfilePhone);
        this.btnAdminDashboard = (MaterialButton) findViewById(R.id.btnAdminDashboard);
        this.btnAdminDashboard.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m445lambda$onCreate$0$cyberorionpkProfileActivity(view);
            }
        });
        findViewById(R.id.btnEditProfile).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m446lambda$onCreate$1$cyberorionpkProfileActivity(view);
            }
        });
        findViewById(R.id.btnSubmitComplaint).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m447lambda$onCreate$2$cyberorionpkProfileActivity(view);
            }
        });
        findViewById(R.id.btnLogout).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m448lambda$onCreate$3$cyberorionpkProfileActivity(view);
            }
        });
        loadUserProfile();
        checkAdminAccess();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m445lambda$onCreate$0$cyberorionpkProfileActivity(View v) {
        startActivity(new Intent(this, (Class<?>) AdminDashboardActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m446lambda$onCreate$1$cyberorionpkProfileActivity(View v) {
        showEditDialog();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m447lambda$onCreate$2$cyberorionpkProfileActivity(View v) {
        startActivity(new Intent(this, (Class<?>) SubmitComplaintActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m448lambda$onCreate$3$cyberorionpkProfileActivity(View v) {
        this.mAuth.signOut();
        Intent i = new Intent(this, (Class<?>) LoginActivity.class);
        i.addFlags(268468224);
        startActivity(i);
        finish();
    }

    private void checkAdminAccess() {
        if (this.mAuth.getCurrentUser() == null) {
            return;
        }
        this.mDatabase.child("admins").child(this.mAuth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.ProfileActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                ProfileActivity.this.btnAdminDashboard.setVisibility(s.exists() ? 0 : 8);
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
            }
        });
    }

    private void loadUserProfile() {
        if (this.mAuth.getCurrentUser() == null) {
            return;
        }
        this.mDatabase.child("users").child(this.mAuth.getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.ProfileActivity.2
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                ProfileActivity.this.loadedUser = (User) snapshot.getValue(User.class);
                if (ProfileActivity.this.loadedUser == null) {
                    ProfileActivity.this.loadedUser = new User("User", ProfileActivity.this.mAuth.getCurrentUser().getEmail(), "");
                }
                ProfileActivity.this.tvName.setText(ProfileActivity.this.loadedUser.name != null ? ProfileActivity.this.loadedUser.name : "User");
                TextView textView = ProfileActivity.this.tvEmail;
                String str = ProfileActivity.this.loadedUser.email;
                ProfileActivity profileActivity = ProfileActivity.this;
                textView.setText(str == null ? profileActivity.mAuth.getCurrentUser().getEmail() : profileActivity.loadedUser.email);
                ProfileActivity.this.tvPhone.setText(TextUtils.isEmpty(ProfileActivity.this.loadedUser.phone) ? "Not added" : ProfileActivity.this.loadedUser.phone);
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
                Toast.makeText(ProfileActivity.this, "Failed to load profile", 0).show();
            }
        });
    }

    private void showEditDialog() {
        if (this.mAuth.getCurrentUser() == null) {
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(1);
        int p = (int) (getResources().getDisplayMetrics().density * 20.0f);
        box.setPadding(p, p / 2, p, p / 2);
        final TextInputEditText name = new TextInputEditText(this);
        name.setHint("Full name");
        name.setText(this.loadedUser != null ? this.loadedUser.name : "");
        final TextInputEditText phone = new TextInputEditText(this);
        phone.setHint("Phone number");
        phone.setInputType(3);
        phone.setText(this.loadedUser != null ? this.loadedUser.phone : "");
        box.addView(name);
        box.addView(phone);
        final AlertDialog d = new AlertDialog.Builder(this).setTitle("Edit profile").setView(box).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).setPositiveButton("Save", (DialogInterface.OnClickListener) null).create();
        d.setOnShowListener(new DialogInterface.OnShowListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnShowListener
            public final void onShow(DialogInterface dialogInterface) {
                this.f$0.m451lambda$showEditDialog$6$cyberorionpkProfileActivity(d, name, phone, dialogInterface);
            }
        });
        d.show();
    }

    /* JADX INFO: renamed from: lambda$showEditDialog$6$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m451lambda$showEditDialog$6$cyberorionpkProfileActivity(final AlertDialog d, final TextInputEditText name, final TextInputEditText phone, DialogInterface x) {
        d.getButton(-1).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m450lambda$showEditDialog$5$cyberorionpkProfileActivity(name, phone, d, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEditDialog$5$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m450lambda$showEditDialog$5$cyberorionpkProfileActivity(TextInputEditText name, TextInputEditText phone, final AlertDialog d, View v) {
        String n = name.getText() != null ? name.getText().toString().trim() : "";
        String ph = phone.getText() != null ? phone.getText().toString().trim() : "";
        if (TextUtils.isEmpty(n) || TextUtils.isEmpty(ph)) {
            Toast.makeText(this, "Name and phone are required", 0).show();
            return;
        }
        Map<String, Object> u = new HashMap<>();
        u.put("name", n);
        u.put("phone", ph);
        this.mDatabase.child("users").child(this.mAuth.getCurrentUser().getUid()).updateChildren(u).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.ProfileActivity$$ExternalSyntheticLambda6
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m449lambda$showEditDialog$4$cyberorionpkProfileActivity(d, task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$showEditDialog$4$cyberorion-pk-ProfileActivity, reason: not valid java name */
    /* synthetic */ void m449lambda$showEditDialog$4$cyberorionpkProfileActivity(AlertDialog d, Task t) {
        if (t.isSuccessful()) {
            d.dismiss();
            loadUserProfile();
            Toast.makeText(this, "Profile updated", 0).show();
        }
    }
}
