package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/* JADX INFO: loaded from: classes3.dex */
public class DriverLoginActivity extends AppCompatActivity {
    private Button btnLogin;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_driver_login);
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1768638687895-b5ee4a586c7f", getResources().getDisplayMetrics().widthPixels);
        this.mAuth = FirebaseAuth.getInstance();
        this.etEmail = (TextInputEditText) findViewById(R.id.etEmail);
        this.etPassword = (TextInputEditText) findViewById(R.id.etPassword);
        this.btnLogin = (Button) findViewById(R.id.btnDriverLogin);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.btnLogin.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverLoginActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m377lambda$onCreate$0$cyberorionpkDriverLoginActivity(view);
            }
        });
        findViewById(R.id.tvDriverSignUp).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverLoginActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m378lambda$onCreate$1$cyberorionpkDriverLoginActivity(view);
            }
        });
        findViewById(R.id.tvBackToCustomer).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverLoginActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m379lambda$onCreate$2$cyberorionpkDriverLoginActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DriverLoginActivity, reason: not valid java name */
    /* synthetic */ void m377lambda$onCreate$0$cyberorionpkDriverLoginActivity(View v) {
        loginDriver();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-DriverLoginActivity, reason: not valid java name */
    /* synthetic */ void m378lambda$onCreate$1$cyberorionpkDriverLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) DriverSignUpActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-DriverLoginActivity, reason: not valid java name */
    /* synthetic */ void m379lambda$onCreate$2$cyberorionpkDriverLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) LoginActivity.class));
        finish();
    }

    private void loginDriver() {
        String email = text(this.etEmail);
        String pass = text(this.etPassword);
        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)) {
            Toast.makeText(this, "Please enter both email and password", 0).show();
        } else {
            setLoading(true);
            this.mAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.DriverLoginActivity$$ExternalSyntheticLambda0
                @Override // com.google.android.gms.tasks.OnCompleteListener
                public final void onComplete(Task task) {
                    this.f$0.m376lambda$loginDriver$3$cyberorionpkDriverLoginActivity(task);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$loginDriver$3$cyberorion-pk-DriverLoginActivity, reason: not valid java name */
    /* synthetic */ void m376lambda$loginDriver$3$cyberorionpkDriverLoginActivity(Task t) {
        if (t.isSuccessful()) {
            verifyDriverProfile();
        } else {
            setLoading(false);
            Toast.makeText(this, t.getException() != null ? t.getException().getMessage() : "Login failed", 1).show();
        }
    }

    private void verifyDriverProfile() {
        String uid = this.mAuth.getCurrentUser() != null ? this.mAuth.getCurrentUser().getUid() : null;
        if (uid == null) {
            setLoading(false);
        } else {
            FirebaseDatabase.getInstance().getReference("drivers").child(uid).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.DriverLoginActivity.1
                @Override // com.google.firebase.database.ValueEventListener
                public void onCancelled(DatabaseError e) {
                    DriverLoginActivity.this.setLoading(false);
                    Toast.makeText(DriverLoginActivity.this, e.getMessage(), 1).show();
                }

                @Override // com.google.firebase.database.ValueEventListener
                public void onDataChange(DataSnapshot s) {
                    DriverLoginActivity.this.setLoading(false);
                    Driver d = (Driver) s.getValue(Driver.class);
                    if (d == null) {
                        DriverLoginActivity.this.deny("No driver profile found for this account.");
                        return;
                    }
                    if (d.disabled) {
                        DriverLoginActivity.this.deny("This driver account is disabled. Contact support.");
                    } else if (d.isApproved()) {
                        DriverLoginActivity.this.goToDashboard();
                    } else {
                        String st = d.approvalStatus == null ? Driver.STATUS_PENDING : d.approvalStatus;
                        DriverLoginActivity.this.deny(Driver.STATUS_REJECTED.equals(st) ? "Your driver application was rejected. Contact support for review." : "Your driver application is still pending admin approval.");
                    }
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void deny(String m) {
        this.mAuth.signOut();
        Toast.makeText(this, m, 1).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void goToDashboard() {
        Intent i = new Intent(this, (Class<?>) DriverDashboardActivity.class);
        i.addFlags(268468224);
        startActivity(i);
        finish();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setLoading(boolean l) {
        this.progressBar.setVisibility(l ? 0 : 8);
        this.btnLogin.setEnabled(!l);
    }

    private String text(TextInputEditText e) {
        return e.getText() != null ? e.getText().toString().trim() : "";
    }
}
