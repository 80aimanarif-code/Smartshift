package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.checkbox.MaterialCheckBox;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class FareEstimateActivity extends AppCompatActivity {
    private CargoSelection cargoSelection;
    private MaterialCheckBox cbLoading;
    private MaterialCheckBox cbUnloading;
    private FareEstimate currentEstimate;
    private double distanceKm;
    private String dropoff;
    private Double dropoffLat;
    private Double dropoffLng;
    private ImageView ivVehicleIcon;
    private LinearLayout layoutBreakdown;
    private LinearLayout layoutLabor;
    private String luggageType;
    private String pickup;
    private Double pickupLat;
    private Double pickupLng;
    private VehicleRecommendation recommendation;
    private TextView tvEtaDistance;
    private TextView tvLaborCount;
    private TextView tvTotalFare;
    private TextView tvVehicleName;
    private TextView tvVehicleReason;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fare_estimate);
        Intent in = getIntent();
        this.luggageType = in.getStringExtra(BookingKeys.EXTRA_LUGGAGE_TYPE);
        this.cargoSelection = (CargoSelection) in.getSerializableExtra(BookingKeys.EXTRA_CARGO_SELECTION);
        this.pickup = in.getStringExtra(BookingKeys.EXTRA_PICKUP);
        this.dropoff = in.getStringExtra(BookingKeys.EXTRA_DROPOFF);
        this.distanceKm = in.getDoubleExtra(BookingKeys.EXTRA_DISTANCE_KM, 0.0d);
        if (in.hasExtra(BookingKeys.EXTRA_PICKUP_LAT)) {
            this.pickupLat = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_PICKUP_LAT, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_PICKUP_LNG)) {
            this.pickupLng = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_PICKUP_LNG, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_DROPOFF_LAT)) {
            this.dropoffLat = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_DROPOFF_LAT, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_DROPOFF_LNG)) {
            this.dropoffLng = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_DROPOFF_LNG, 0.0d));
        }
        if (this.cargoSelection == null) {
            this.cargoSelection = new CargoSelection();
        }
        this.tvTotalFare = (TextView) findViewById(R.id.tvTotalFare);
        this.tvEtaDistance = (TextView) findViewById(R.id.tvEtaDistance);
        this.tvVehicleName = (TextView) findViewById(R.id.tvVehicleName);
        this.tvVehicleReason = (TextView) findViewById(R.id.tvVehicleReason);
        this.ivVehicleIcon = (ImageView) findViewById(R.id.ivVehicleIcon);
        this.layoutBreakdown = (LinearLayout) findViewById(R.id.layoutBreakdown);
        this.layoutLabor = (LinearLayout) findViewById(R.id.layoutLabor);
        this.tvLaborCount = (TextView) findViewById(R.id.tvLaborCount);
        this.cbLoading = (MaterialCheckBox) findViewById(R.id.cbLoading);
        this.cbUnloading = (MaterialCheckBox) findViewById(R.id.cbUnloading);
        this.cbLoading.setChecked(this.cargoSelection.loadingRequired);
        this.cbUnloading.setChecked(this.cargoSelection.unloadingRequired);
        this.cbLoading.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: cyberorion.pk.FareEstimateActivity$$ExternalSyntheticLambda0
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.m392lambda$onCreate$0$cyberorionpkFareEstimateActivity(compoundButton, z);
            }
        });
        this.cbUnloading.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: cyberorion.pk.FareEstimateActivity$$ExternalSyntheticLambda1
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                this.f$0.m393lambda$onCreate$1$cyberorionpkFareEstimateActivity(compoundButton, z);
            }
        });
        findViewById(R.id.btnLaborMinus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.FareEstimateActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m394lambda$onCreate$2$cyberorionpkFareEstimateActivity(view);
            }
        });
        findViewById(R.id.btnLaborPlus).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.FareEstimateActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m395lambda$onCreate$3$cyberorionpkFareEstimateActivity(view);
            }
        });
        findViewById(R.id.btnFindDrivers).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.FareEstimateActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m396lambda$onCreate$4$cyberorionpkFareEstimateActivity(view);
            }
        });
        recalculate();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-FareEstimateActivity, reason: not valid java name */
    /* synthetic */ void m392lambda$onCreate$0$cyberorionpkFareEstimateActivity(CompoundButton btn, boolean checked) {
        this.cargoSelection.loadingRequired = checked;
        recalculate();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-FareEstimateActivity, reason: not valid java name */
    /* synthetic */ void m393lambda$onCreate$1$cyberorionpkFareEstimateActivity(CompoundButton btn, boolean checked) {
        this.cargoSelection.unloadingRequired = checked;
        recalculate();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-FareEstimateActivity, reason: not valid java name */
    /* synthetic */ void m394lambda$onCreate$2$cyberorionpkFareEstimateActivity(View v) {
        changeLabor(-1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-FareEstimateActivity, reason: not valid java name */
    /* synthetic */ void m395lambda$onCreate$3$cyberorionpkFareEstimateActivity(View v) {
        changeLabor(1);
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-FareEstimateActivity, reason: not valid java name */
    /* synthetic */ void m396lambda$onCreate$4$cyberorionpkFareEstimateActivity(View v) {
        goToDriverSelection();
    }

    private void changeLabor(int delta) {
        int updated = Math.max(1, Math.min(8, this.cargoSelection.laborCount + delta));
        this.cargoSelection.laborCount = updated;
        this.tvLaborCount.setText(String.valueOf(updated));
        recalculate();
    }

    private void recalculate() {
        this.layoutLabor.setVisibility((this.cargoSelection.loadingRequired || this.cargoSelection.unloadingRequired) ? 0 : 8);
        this.tvLaborCount.setText(String.valueOf(this.cargoSelection.laborCount));
        this.recommendation = VehicleRecommender.recommend(this.cargoSelection, this.distanceKm);
        this.currentEstimate = FareEstimator.estimate(this.cargoSelection, this.distanceKm, this.recommendation.vehicle);
        this.tvTotalFare.setText(getString(R.string.fare_amount_format, new Object[]{Double.valueOf(this.currentEstimate.totalFare)}));
        this.tvEtaDistance.setText(String.format(Locale.getDefault(), "ETA %s • %.1f km", this.currentEstimate.durationLabel(), Double.valueOf(this.distanceKm)));
        this.tvVehicleName.setText(this.recommendation.vehicle.name);
        this.tvVehicleReason.setText(this.recommendation.reason);
        this.ivVehicleIcon.setImageResource(this.recommendation.vehicle.iconRes);
        this.layoutBreakdown.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (FareBreakdownItem item : this.currentEstimate.breakdown) {
            View row = inflater.inflate(R.layout.item_fare_line, (ViewGroup) this.layoutBreakdown, false);
            ((TextView) row.findViewById(R.id.tvLineLabel)).setText(item.label);
            ((TextView) row.findViewById(R.id.tvLineAmount)).setText(getString(R.string.fare_amount_format, new Object[]{Double.valueOf(item.amount)}));
            this.layoutBreakdown.addView(row);
        }
    }

    private void goToDriverSelection() {
        Intent intent = new Intent(this, (Class<?>) DriverSelectionActivity.class);
        intent.putExtra(BookingKeys.EXTRA_LUGGAGE_TYPE, this.luggageType);
        intent.putExtra(BookingKeys.EXTRA_CARGO_SELECTION, this.cargoSelection);
        intent.putExtra(BookingKeys.EXTRA_PICKUP, this.pickup);
        intent.putExtra(BookingKeys.EXTRA_DROPOFF, this.dropoff);
        intent.putExtra(BookingKeys.EXTRA_DISTANCE_KM, this.distanceKm);
        if (this.pickupLat != null) {
            intent.putExtra(BookingKeys.EXTRA_PICKUP_LAT, this.pickupLat);
        }
        if (this.pickupLng != null) {
            intent.putExtra(BookingKeys.EXTRA_PICKUP_LNG, this.pickupLng);
        }
        if (this.dropoffLat != null) {
            intent.putExtra(BookingKeys.EXTRA_DROPOFF_LAT, this.dropoffLat);
        }
        if (this.dropoffLng != null) {
            intent.putExtra(BookingKeys.EXTRA_DROPOFF_LNG, this.dropoffLng);
        }
        intent.putExtra(BookingKeys.EXTRA_ESTIMATED_FARE, this.currentEstimate.totalFare);
        intent.putExtra(BookingKeys.EXTRA_ESTIMATED_DURATION_MIN, this.currentEstimate.estimatedDurationMinutes);
        intent.putExtra(BookingKeys.EXTRA_RECOMMENDED_VEHICLE_ID, this.recommendation.vehicle.id);
        intent.putExtra(BookingKeys.EXTRA_RECOMMENDED_VEHICLE_NAME, this.recommendation.vehicle.name);
        startActivity(intent);
    }
}
