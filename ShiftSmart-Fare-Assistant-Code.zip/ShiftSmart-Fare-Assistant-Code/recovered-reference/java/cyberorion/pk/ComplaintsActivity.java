package cyberorion.pk;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class ComplaintsActivity extends AppCompatActivity implements AdminRecordAdapter.Listener {
    private AdminRecordAdapter adapter;
    private DatabaseReference ref;
    private final List<AdminRecordAdapter.Record> rows = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (AdminAccountManager.requireAdminAccess(this)) {
            RecyclerView rv = AdminListUi.setup(this, "Complaints", this.rows, this);
            this.adapter = (AdminRecordAdapter) rv.getAdapter();
            this.ref = FirebaseDatabase.getInstance().getReference("complaints");
            this.ref.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.ComplaintsActivity.1
                @Override // com.google.firebase.database.ValueEventListener
                public void onCancelled(DatabaseError e) {
                    Toast.makeText(ComplaintsActivity.this, e.getMessage(), 0).show();
                }

                @Override // com.google.firebase.database.ValueEventListener
                public void onDataChange(DataSnapshot s) {
                    ComplaintsActivity.this.rows.clear();
                    for (DataSnapshot c : s.getChildren()) {
                        Complaint x = (Complaint) c.getValue(Complaint.class);
                        if (x != null) {
                            String key = c.getKey();
                            String str = x.subject;
                            String str2 = "";
                            StringBuilder sbAppend = new StringBuilder().append(x.userEmail == null ? "" : x.userEmail);
                            if (x.bookingId != null && !x.bookingId.isEmpty()) {
                                str2 = " • Booking " + x.bookingId;
                            }
                            AdminRecordAdapter.Record r = new AdminRecordAdapter.Record(key, str, sbAppend.append(str2).append("\n").append(x.message).toString(), (x.status == null ? "open" : x.status).toUpperCase(Locale.ROOT));
                            r.primary = SosAlert.STATUS_RESOLVED.equalsIgnoreCase(x.status) ? "Reopen" : "Resolve";
                            r.payload = x;
                            ComplaintsActivity.this.rows.add(r);
                        }
                    }
                    Collections.reverse(ComplaintsActivity.this.rows);
                    ComplaintsActivity.this.adapter.notifyDataSetChanged();
                }
            });
        }
    }

    @Override // cyberorion.pk.AdminRecordAdapter.Listener
    public void onAction(AdminRecordAdapter.Record r, int a) {
        Complaint c = (Complaint) r.payload;
        DatabaseReference databaseReferenceChild = this.ref.child(r.id).child("status");
        String str = c.status;
        String str2 = SosAlert.STATUS_RESOLVED;
        if (SosAlert.STATUS_RESOLVED.equalsIgnoreCase(str)) {
            str2 = "open";
        }
        databaseReferenceChild.setValue(str2);
    }
}
