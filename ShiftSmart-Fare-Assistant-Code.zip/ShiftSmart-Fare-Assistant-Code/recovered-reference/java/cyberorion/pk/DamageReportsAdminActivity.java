package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class DamageReportsAdminActivity extends AppCompatActivity implements AdminRecordAdapter.Listener {
    private AdminRecordAdapter adapter;
    private final List<AdminRecordAdapter.Record> rows = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (AdminAccountManager.requireAdminAccess(this)) {
            RecyclerView rv = AdminListUi.setup(this, "Damage Reports", this.rows, this);
            this.adapter = (AdminRecordAdapter) rv.getAdapter();
            FirebaseDatabase.getInstance().getReference("bookings").addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.DamageReportsAdminActivity.1
                @Override // com.google.firebase.database.ValueEventListener
                public void onCancelled(DatabaseError e) {
                    Toast.makeText(DamageReportsAdminActivity.this, e.getMessage(), 0).show();
                }

                @Override // com.google.firebase.database.ValueEventListener
                public void onDataChange(DataSnapshot s) {
                    DamageReportsAdminActivity.this.rows.clear();
                    for (DataSnapshot c : s.getChildren()) {
                        DataSnapshot dr = c.child("damageReports");
                        if (dr.exists()) {
                            Booking booking = (Booking) c.getValue(Booking.class);
                            boolean p = dr.child(DamageReport.STAGE_PICKUP).exists();
                            boolean d = dr.child(DamageReport.STAGE_DELIVERY).exists();
                            AdminRecordAdapter.Record r = new AdminRecordAdapter.Record(c.getKey(), "Booking " + c.getKey(), booking == null ? "" : booking.pickup + " → " + booking.dropoff, (p ? "Pickup ✓" : "Pickup —") + " • " + (d ? "Delivery ✓" : "Delivery —") + " • Risk " + DamageRiskScorer.assess(booking).level);
                            r.primary = "Compare";
                            DamageReportsAdminActivity.this.rows.add(r);
                        }
                    }
                    DamageReportsAdminActivity.this.adapter.notifyDataSetChanged();
                }
            });
        }
    }

    @Override // cyberorion.pk.AdminRecordAdapter.Listener
    public void onAction(AdminRecordAdapter.Record r, int a) {
        Intent i = new Intent(this, (Class<?>) DamageComparisonActivity.class);
        i.putExtra(BookingKeys.EXTRA_BOOKING_ID, r.id);
        startActivity(i);
    }
}
