package cyberorion.pk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class AdminDashboardActivity extends AppCompatActivity implements AdminBookingAdapter.OnBookingClickListener, SosAlertAdapter.OnSosActionListener {
    private AdminBookingAdapter bookingAdapter;
    private DatabaseReference bookingsRef;
    private DatabaseReference driversRef;
    private FirebaseAuth mAuth;
    private RecyclerView rvSosAlerts;
    private SosAlertAdapter sosAdapter;
    private DatabaseReference sosRef;
    private TextView tvEmptyBookings;
    private TextView tvSosHeading;
    private DatabaseReference usersRef;
    private final List<Booking> allBookings = new ArrayList();
    private final List<SosAlert> activeAlerts = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);
        this.mAuth = FirebaseAuth.getInstance();
        if (this.mAuth.getCurrentUser() == null) {
            goToLogin();
        } else {
            if (!AdminAccountManager.isDefaultAdminEmail(this.mAuth.getCurrentUser().getEmail())) {
                Toast.makeText(this, "You don't have permission to access this. Admin sign-in required.", 1).show();
                this.mAuth.signOut();
                goToLogin();
                return;
            }
            AdminAccountManager.ensureAdminDatabaseRecord(this.mAuth.getCurrentUser(), new AdminAccountManager.Completion() { // from class: cyberorion.pk.AdminDashboardActivity.1
                @Override // cyberorion.pk.AdminAccountManager.Completion
                public void onSuccess(FirebaseUser user) {
                    AdminDashboardActivity.this.initDashboard();
                }

                @Override // cyberorion.pk.AdminAccountManager.Completion
                public void onError(Exception error) {
                    Toast.makeText(AdminDashboardActivity.this, "Could not initialize admin database access: " + error.getMessage(), 1).show();
                    AdminDashboardActivity.this.finish();
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void initDashboard() {
        TextView tvGreeting = (TextView) findViewById(R.id.tvAdminGreeting);
        tvGreeting.setText(this.mAuth.getCurrentUser().getEmail() != null ? "Signed in as " + this.mAuth.getCurrentUser().getEmail() : "Signed in");
        findViewById(R.id.tvAdminLogout).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m283lambda$initDashboard$0$cyberorionpkAdminDashboardActivity(view);
            }
        });
        findViewById(R.id.btnManageUsers).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m284lambda$initDashboard$1$cyberorionpkAdminDashboardActivity(view);
            }
        });
        findViewById(R.id.btnManageDrivers).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m285lambda$initDashboard$2$cyberorionpkAdminDashboardActivity(view);
            }
        });
        findViewById(R.id.btnDamageReports).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m286lambda$initDashboard$3$cyberorionpkAdminDashboardActivity(view);
            }
        });
        findViewById(R.id.btnComplaints).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m287lambda$initDashboard$4$cyberorionpkAdminDashboardActivity(view);
            }
        });
        this.tvSosHeading = (TextView) findViewById(R.id.tvSosSectionHeading);
        this.tvEmptyBookings = (TextView) findViewById(R.id.tvAdminEmptyBookings);
        RecyclerView rvBookings = (RecyclerView) findViewById(R.id.rvAdminBookings);
        rvBookings.setLayoutManager(new LinearLayoutManager(this));
        this.bookingAdapter = new AdminBookingAdapter(this.allBookings, this);
        rvBookings.setAdapter(this.bookingAdapter);
        this.rvSosAlerts = (RecyclerView) findViewById(R.id.rvSosAlerts);
        this.rvSosAlerts.setLayoutManager(new LinearLayoutManager(this));
        this.sosAdapter = new SosAlertAdapter(this.activeAlerts, this);
        this.rvSosAlerts.setAdapter(this.sosAdapter);
        final SwipeRefreshLayout swipe = (SwipeRefreshLayout) findViewById(R.id.swipeAdmin);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: cyberorion.pk.AdminDashboardActivity$$ExternalSyntheticLambda5
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                swipe.setRefreshing(false);
            }
        });
        this.bookingsRef = FirebaseDatabase.getInstance().getReference().child("bookings");
        this.driversRef = FirebaseDatabase.getInstance().getReference().child("drivers");
        this.usersRef = FirebaseDatabase.getInstance().getReference().child("users");
        this.sosRef = FirebaseDatabase.getInstance().getReference().child(AppNotification.TYPE_SOS);
        listenForBookings();
        listenForDrivers();
        listenForUsers();
        listenForSos();
    }

    /* JADX INFO: renamed from: lambda$initDashboard$0$cyberorion-pk-AdminDashboardActivity, reason: not valid java name */
    /* synthetic */ void m283lambda$initDashboard$0$cyberorionpkAdminDashboardActivity(View v) {
        this.mAuth.signOut();
        Toast.makeText(this, "Logged out successfully", 0).show();
        goToLogin();
    }

    /* JADX INFO: renamed from: lambda$initDashboard$1$cyberorion-pk-AdminDashboardActivity, reason: not valid java name */
    /* synthetic */ void m284lambda$initDashboard$1$cyberorionpkAdminDashboardActivity(View v) {
        startActivity(new Intent(this, (Class<?>) UserManagementActivity.class));
    }

    /* JADX INFO: renamed from: lambda$initDashboard$2$cyberorion-pk-AdminDashboardActivity, reason: not valid java name */
    /* synthetic */ void m285lambda$initDashboard$2$cyberorionpkAdminDashboardActivity(View v) {
        startActivity(new Intent(this, (Class<?>) DriverManagementActivity.class));
    }

    /* JADX INFO: renamed from: lambda$initDashboard$3$cyberorion-pk-AdminDashboardActivity, reason: not valid java name */
    /* synthetic */ void m286lambda$initDashboard$3$cyberorionpkAdminDashboardActivity(View v) {
        startActivity(new Intent(this, (Class<?>) DamageReportsAdminActivity.class));
    }

    /* JADX INFO: renamed from: lambda$initDashboard$4$cyberorion-pk-AdminDashboardActivity, reason: not valid java name */
    /* synthetic */ void m287lambda$initDashboard$4$cyberorionpkAdminDashboardActivity(View v) {
        startActivity(new Intent(this, (Class<?>) ComplaintsActivity.class));
    }

    /* JADX INFO: renamed from: cyberorion.pk.AdminDashboardActivity$2, reason: invalid class name */
    class AnonymousClass2 implements ValueEventListener {
        AnonymousClass2() {
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onDataChange(DataSnapshot snapshot) {
            AdminDashboardActivity.this.allBookings.clear();
            for (DataSnapshot child : snapshot.getChildren()) {
                Booking booking = (Booking) child.getValue(Booking.class);
                if (booking != null) {
                    booking.bookingId = child.getKey();
                    AdminDashboardActivity.this.allBookings.add(booking);
                }
            }
            Collections.sort(AdminDashboardActivity.this.allBookings, new Comparator() { // from class: cyberorion.pk.AdminDashboardActivity$2$$ExternalSyntheticLambda0
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return Long.compare(((Booking) obj2).timestamp, ((Booking) obj).timestamp);
                }
            });
            AdminDashboardActivity.this.bookingAdapter.notifyDataSetChanged();
            boolean empty = AdminDashboardActivity.this.allBookings.isEmpty();
            AdminDashboardActivity.this.tvEmptyBookings.setVisibility(empty ? 0 : 8);
            AdminDashboardActivity.this.updateBookingStats();
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onCancelled(DatabaseError error) {
            Toast.makeText(AdminDashboardActivity.this, "Could not load bookings: " + error.getMessage(), 0).show();
        }
    }

    private void listenForBookings() {
        this.bookingsRef.addValueEventListener(new AnonymousClass2());
    }

    private void listenForDrivers() {
        this.driversRef.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.AdminDashboardActivity.3
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                int onlineCount = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    Driver driver = (Driver) child.getValue(Driver.class);
                    if (driver != null && driver.available) {
                        onlineCount++;
                    }
                }
                AdminDashboardActivity.this.setStat(R.id.statDriversOnline, R.string.stat_drivers_online, String.valueOf(onlineCount));
                AdminDashboardActivity.this.setStat(R.id.statTotalDrivers, R.string.stat_total_drivers, String.valueOf(snapshot.getChildrenCount()));
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void listenForUsers() {
        this.usersRef.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.AdminDashboardActivity.4
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                AdminDashboardActivity.this.setStat(R.id.statTotalUsers, R.string.stat_total_users, String.valueOf(snapshot.getChildrenCount()));
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    /* JADX INFO: renamed from: cyberorion.pk.AdminDashboardActivity$5, reason: invalid class name */
    class AnonymousClass5 implements ValueEventListener {
        AnonymousClass5() {
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onDataChange(DataSnapshot snapshot) {
            AdminDashboardActivity.this.activeAlerts.clear();
            for (DataSnapshot child : snapshot.getChildren()) {
                SosAlert alert = (SosAlert) child.getValue(SosAlert.class);
                if (alert != null && SosAlert.STATUS_ACTIVE.equals(alert.status)) {
                    alert.alertId = child.getKey();
                    AdminDashboardActivity.this.activeAlerts.add(alert);
                }
            }
            Collections.sort(AdminDashboardActivity.this.activeAlerts, new Comparator() { // from class: cyberorion.pk.AdminDashboardActivity$5$$ExternalSyntheticLambda0
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return Long.compare(((SosAlert) obj2).timestamp, ((SosAlert) obj).timestamp);
                }
            });
            AdminDashboardActivity.this.sosAdapter.notifyDataSetChanged();
            boolean hasAlerts = !AdminDashboardActivity.this.activeAlerts.isEmpty();
            AdminDashboardActivity.this.tvSosHeading.setVisibility(hasAlerts ? 0 : 8);
            AdminDashboardActivity.this.rvSosAlerts.setVisibility(hasAlerts ? 0 : 8);
            AdminDashboardActivity.this.setStat(R.id.statOpenSos, R.string.stat_open_sos, String.valueOf(AdminDashboardActivity.this.activeAlerts.size()));
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onCancelled(DatabaseError error) {
        }
    }

    private void listenForSos() {
        this.sosRef.addValueEventListener(new AnonymousClass5());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateBookingStats() {
        double dDoubleValue;
        int active = 0;
        int completed = 0;
        double revenue = 0.0d;
        for (Booking b : this.allBookings) {
            BookingStatus status = BookingStatus.fromLabel(b.status);
            if (status.isActive()) {
                active++;
            }
            if (status == BookingStatus.DELIVERED || status == BookingStatus.COMPLETED) {
                completed++;
                if (b.finalFare != null) {
                    dDoubleValue = b.finalFare.doubleValue();
                } else {
                    dDoubleValue = b.negotiatedFare != null ? b.negotiatedFare.doubleValue() : b.estimatedFare;
                }
                revenue += dDoubleValue;
            }
        }
        setStat(R.id.statTotalBookings, R.string.stat_total_bookings, String.valueOf(this.allBookings.size()));
        setStat(R.id.statActiveTrips, R.string.stat_active_trips, String.valueOf(active));
        setStat(R.id.statCompleted, R.string.stat_completed, String.valueOf(completed));
        setStat(R.id.statRevenue, R.string.stat_revenue, String.format(Locale.getDefault(), "%,.0f", Double.valueOf(revenue)));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setStat(int includeId, int labelRes, String value) {
        View card = findViewById(includeId);
        if (card == null) {
            return;
        }
        ((TextView) card.findViewById(R.id.tvStatValue)).setText(value);
        ((TextView) card.findViewById(R.id.tvStatLabel)).setText(labelRes);
    }

    @Override // cyberorion.pk.AdminBookingAdapter.OnBookingClickListener
    public void onClick(Booking booking) {
        if (booking.bookingId == null) {
            return;
        }
        Intent intent = new Intent(this, (Class<?>) TrackingActivity.class);
        intent.putExtra(BookingKeys.EXTRA_BOOKING_ID, booking.bookingId);
        intent.putExtra(BookingKeys.EXTRA_ROLE, BookingKeys.ROLE_CUSTOMER);
        startActivity(intent);
    }

    @Override // cyberorion.pk.SosAlertAdapter.OnSosActionListener
    public void onResolve(SosAlert alert) {
        String uid = this.mAuth.getCurrentUser() != null ? this.mAuth.getCurrentUser().getUid() : null;
        SosHelper.resolve(alert, uid);
        Toast.makeText(this, "SOS alert resolved", 0).show();
    }

    @Override // cyberorion.pk.SosAlertAdapter.OnSosActionListener
    public void onViewLocation(SosAlert alert) {
        if (alert.lat == null || alert.lng == null) {
            return;
        }
        Uri uri = Uri.parse(String.format(Locale.US, "geo:%f,%f?q=%f,%f", alert.lat, alert.lng, alert.lat, alert.lng));
        Intent intent = new Intent("android.intent.action.VIEW", uri);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "No map app found to show this location", 0).show();
        }
    }

    private void goToLogin() {
        Intent intent = new Intent(this, (Class<?>) AdminLoginActivity.class);
        intent.addFlags(268468224);
        startActivity(intent);
        finish();
    }
}
