package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class User {
    public boolean disabled;
    public String email;
    public String name;
    public String phone;
    public String role;

    public User() {
    }

    public User(String name, String email) {
        this(name, email, "");
    }

    public User(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.disabled = false;
        this.role = BookingKeys.ROLE_CUSTOMER;
    }
}
