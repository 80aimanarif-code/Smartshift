package cyberorion.pk;

import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class NegotiationAdapter extends RecyclerView.Adapter<OfferViewHolder> {
    private final String myRole;
    private final List<NegotiationOffer> offers;

    public NegotiationAdapter(List<NegotiationOffer> offers, String myRole) {
        this.offers = offers;
        this.myRole = myRole;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public OfferViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_negotiation_message, parent, false);
        return new OfferViewHolder(view);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code duplicated, block: B:18:0x0049  */
    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(OfferViewHolder holder, int position) {
        String action;
        NegotiationOffer offer = this.offers.get(position);
        boolean mine = this.myRole.equals(offer.senderRole);
        String senderName = BookingKeys.ROLE_CUSTOMER.equals(offer.senderRole) ? "Customer" : "Driver";
        switch (offer.type) {
            case "accept":
                action = senderName + " accepted";
                break;
            case "reject":
                action = senderName + " rejected the offer";
                break;
            case "counter":
                action = senderName + " countered";
                break;
            default:
                action = senderName + " offered";
                break;
        }
        holder.tvSenderLabel.setText(action);
        holder.tvOfferAmount.setText(holder.itemView.getContext().getString(R.string.fare_amount_format, Double.valueOf(offer.amount)));
        holder.tvOfferTime.setText(DateFormat.format("h:mm a", offer.timestamp));
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.cardBubble.getLayoutParams();
        if (mine) {
            params.gravity = GravityCompat.END;
            params.leftMargin = dp(holder, 60);
            params.rightMargin = 0;
            holder.cardBubble.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.primaryColor));
            holder.tvSenderLabel.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.secondaryColor));
            holder.tvOfferAmount.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.white));
            holder.tvOfferTime.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.secondaryColor));
        } else {
            params.gravity = GravityCompat.START;
            params.leftMargin = 0;
            params.rightMargin = dp(holder, 60);
            holder.cardBubble.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.lightGray));
            holder.tvSenderLabel.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.gray));
            holder.tvOfferAmount.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.black));
            holder.tvOfferTime.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.gray));
        }
        holder.cardBubble.setLayoutParams(params);
        if (offer.type.equals("accept")) {
            holder.cardBubble.setStrokeWidth(2);
            holder.cardBubble.setStrokeColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.successColor));
        } else {
            holder.cardBubble.setStrokeWidth(0);
        }
    }

    private int dp(RecyclerView.ViewHolder holder, int value) {
        float density = holder.itemView.getResources().getDisplayMetrics().density;
        return (int) (value * density);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.offers.size();
    }

    static class OfferViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView cardBubble;
        TextView tvOfferAmount;
        TextView tvOfferTime;
        TextView tvSenderLabel;

        OfferViewHolder(View itemView) {
            super(itemView);
            this.cardBubble = (MaterialCardView) itemView.findViewById(R.id.cardBubble);
            this.tvSenderLabel = (TextView) itemView.findViewById(R.id.tvSenderLabel);
            this.tvOfferAmount = (TextView) itemView.findViewById(R.id.tvOfferAmount);
            this.tvOfferTime = (TextView) itemView.findViewById(R.id.tvOfferTime);
        }
    }
}
