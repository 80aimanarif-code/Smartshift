package cyberorion.pk;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/* JADX INFO: loaded from: classes3.dex */
public class SubmitComplaintActivity extends AppCompatActivity {
    private TextInputEditText booking;
    private TextInputEditText message;
    private TextInputEditText subject;

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-SubmitComplaintActivity, reason: not valid java name */
    /* synthetic */ void m460lambda$onCreate$0$cyberorionpkSubmitComplaintActivity(View v) {
        submit();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(40, 40, 40, 40);
        TextView h = new TextView(this);
        h.setText("Submit Complaint");
        h.setTextSize(24.0f);
        root.addView(h);
        this.subject = new TextInputEditText(this);
        this.subject.setHint("Subject");
        this.message = new TextInputEditText(this);
        this.message.setHint("Describe the issue");
        this.message.setMinLines(5);
        this.booking = new TextInputEditText(this);
        this.booking.setHint("Booking ID (optional)");
        root.addView(this.subject);
        root.addView(this.message);
        root.addView(this.booking);
        MaterialButton send = new MaterialButton(this);
        send.setText("Send Complaint");
        root.addView(send);
        setContentView(root);
        send.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.SubmitComplaintActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m460lambda$onCreate$0$cyberorionpkSubmitComplaintActivity(view);
            }
        });
    }

    private void submit() {
        String sub = text(this.subject);
        String msg = text(this.message);
        if (TextUtils.isEmpty(sub) || TextUtils.isEmpty(msg)) {
            Toast.makeText(this, "Subject and message are required", 0).show();
            return;
        }
        FirebaseAuth a = FirebaseAuth.getInstance();
        String uid = a.getCurrentUser() != null ? a.getCurrentUser().getUid() : "anonymous";
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("complaints").push();
        Complaint c = new Complaint();
        c.complaintId = ref.getKey();
        c.userId = uid;
        c.userEmail = a.getCurrentUser() != null ? a.getCurrentUser().getEmail() : "";
        c.bookingId = text(this.booking);
        c.subject = sub;
        c.message = msg;
        c.status = "open";
        c.timestamp = System.currentTimeMillis();
        ref.setValue(c).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.SubmitComplaintActivity$$ExternalSyntheticLambda1
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m461lambda$submit$1$cyberorionpkSubmitComplaintActivity(task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$submit$1$cyberorion-pk-SubmitComplaintActivity, reason: not valid java name */
    /* synthetic */ void m461lambda$submit$1$cyberorionpkSubmitComplaintActivity(Task t) {
        if (!t.isSuccessful()) {
            Toast.makeText(this, "Could not submit complaint", 0).show();
        } else {
            Toast.makeText(this, "Complaint submitted", 0).show();
            finish();
        }
    }

    private String text(TextInputEditText e) {
        return e.getText() != null ? e.getText().toString().trim() : "";
    }
}
