package cyberorion.pk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public final class DamageRiskScorer {
    private DamageRiskScorer() {
    }

    public static DamageRiskAssessment assess(Booking b) {
        if (b == null) {
            return build(0, new ArrayList());
        }
        List<String> reasons = new ArrayList<>();
        int score = 0;
        if (b.fragile) {
            score = 0 + 35;
            reasons.add("fragile cargo");
        }
        String text = ((b.cargoCategoryName == null ? "" : b.cargoCategoryName) + " " + (b.specialHandling != null ? b.specialHandling : "")).toLowerCase(Locale.ROOT);
        if (text.contains("glass")) {
            score += 25;
            reasons.add("glass items");
        }
        if (text.contains("electronic")) {
            score += 20;
            reasons.add("electronics");
        }
        if (text.contains("machinery") || text.contains("industrial")) {
            score += 15;
            reasons.add("industrial/machinery cargo");
        }
        if (b.weightKg >= 2000.0d) {
            score += 20;
            reasons.add("very heavy load");
        } else if (b.weightKg >= 500.0d) {
            score += 10;
            reasons.add("heavy load");
        }
        if (b.quantity >= 10) {
            score += 10;
            reasons.add("high item count");
        }
        if (b.loadingRequired || b.unloadingRequired) {
            score += 5;
            reasons.add("manual handling required");
        }
        return build(Math.min(100, score), reasons);
    }

    public static DamageRiskAssessment assess(CargoSelection c) {
        Booking b = new Booking();
        if (c != null) {
            b.fragile = c.fragile;
            b.cargoCategoryName = c.cargoCategoryName;
            b.specialHandling = c.specialHandling;
            b.weightKg = c.weightKg;
            b.quantity = c.quantity;
            b.loadingRequired = c.loadingRequired;
            b.unloadingRequired = c.unloadingRequired;
        }
        return assess(b);
    }

    private static DamageRiskAssessment build(int score, List<String> reasons) {
        String level;
        String rec;
        if (score >= 60) {
            level = "High";
        } else {
            level = score >= 30 ? "Medium" : "Low";
        }
        if (score >= 60) {
            rec = "Use extra padding, secure tie-downs, and photo verification at both ends.";
        } else {
            rec = score >= 30 ? "Use protective packing and verify condition at pickup and delivery." : "Standard handling is appropriate; keep the condition record for traceability.";
        }
        String reason = reasons.isEmpty() ? "No major damage-risk factors detected" : DamageRiskScorer$$ExternalSyntheticBackport0.m(", ", reasons);
        return new DamageRiskAssessment(score, level, rec, reason);
    }
}
