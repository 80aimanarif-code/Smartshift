package cyberorion.pk;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public class VehicleRecommendation implements Serializable {
    public final String reason;
    public final Vehicle vehicle;

    public VehicleRecommendation(Vehicle vehicle, String reason) {
        this.vehicle = vehicle;
        this.reason = reason;
    }
}
