package cyberorion.pk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

/* JADX INFO: loaded from: classes3.dex */
public class ShiftingTypeAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final OnTypeSelectedListener listener;
    private final ShiftingType[] types = ShiftingType.values();

    public interface OnTypeSelectedListener {
        void onTypeSelected(ShiftingType shiftingType);
    }

    public ShiftingTypeAdapter(OnTypeSelectedListener listener) {
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_shifting_type, parent, false);
        return new ViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        final ShiftingType type = this.types[position];
        holder.tvName.setText(type.title);
        holder.tvDesc.setText(type.description);
        holder.ivIcon.setImageResource(type.iconRes);
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.ShiftingTypeAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m453lambda$onBindViewHolder$0$cyberorionpkShiftingTypeAdapter(type, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-ShiftingTypeAdapter, reason: not valid java name */
    /* synthetic */ void m453lambda$onBindViewHolder$0$cyberorionpkShiftingTypeAdapter(ShiftingType type, View v) {
        this.listener.onTypeSelected(type);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.types.length;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        TextView tvDesc;
        TextView tvName;

        ViewHolder(View itemView) {
            super(itemView);
            this.ivIcon = (ImageView) itemView.findViewById(R.id.ivTypeIcon);
            this.tvName = (TextView) itemView.findViewById(R.id.tvTypeName);
            this.tvDesc = (TextView) itemView.findViewById(R.id.tvTypeDesc);
        }
    }
}
