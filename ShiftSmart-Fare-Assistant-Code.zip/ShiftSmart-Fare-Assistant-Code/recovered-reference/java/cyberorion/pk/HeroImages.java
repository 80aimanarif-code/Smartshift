package cyberorion.pk;

import android.widget.ImageView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

/* JADX INFO: loaded from: classes3.dex */
final class HeroImages {
    static final String TRUCK = "https://images.unsplash.com/photo-1768638687895-b5ee4a586c7f";
    static final String WAREHOUSE = "https://images.unsplash.com/photo-1684695749267-233af13276d0";

    private HeroImages() {
    }

    static void load(ImageView target, String baseUrl, int widthPx) {
        String sized = baseUrl + "?auto=format&fit=crop&q=70&w=" + widthPx;
        Glide.with(target.getContext()).load(sized).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC).centerCrop().into(target);
    }
}
