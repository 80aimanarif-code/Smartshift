package cyberorion.pk;

import android.app.Activity;
import android.widget.Toast;
import androidx.credentials.exceptions.publickeycredential.DomExceptionUtils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: classes3.dex */
public final class AdminAccountManager {
    public static final String ADMIN_EMAIL = "admin@smartshift.pk";
    public static final String ADMIN_PASSWORD = "admin";
    private static final String FIREBASE_AUTH_PASSWORD = "SmartShift@Admin2026#SecurePwd";

    public interface Completion {
        void onError(Exception exc);

        void onSuccess(FirebaseUser firebaseUser);
    }

    private AdminAccountManager() {
    }

    public static boolean isDefaultAdminEmail(String email) {
        return email != null && ADMIN_EMAIL.equals(email.trim().toLowerCase(Locale.ROOT));
    }

    public static boolean requireAdminAccess(Activity activity) {
        FirebaseUser current = FirebaseAuth.getInstance().getCurrentUser();
        if (current != null && isDefaultAdminEmail(current.getEmail())) {
            return true;
        }
        Toast.makeText(activity, "You don't have permission to access this. Admin sign-in required.", 1).show();
        activity.finish();
        return false;
    }

    public static void signInOrCreateDefaultAdmin(final FirebaseAuth auth, final Completion completion) {
        auth.signInWithEmailAndPassword(ADMIN_EMAIL, FIREBASE_AUTH_PASSWORD).addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                AdminAccountManager.lambda$signInOrCreateDefaultAdmin$0(completion, (AuthResult) obj);
            }
        }).addOnFailureListener(new OnFailureListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda1
            @Override // com.google.android.gms.tasks.OnFailureListener
            public final void onFailure(Exception exc) {
                FirebaseAuth firebaseAuth = auth;
                AdminAccountManager.Completion completion2 = completion;
                firebaseAuth.createUserWithEmailAndPassword(AdminAccountManager.ADMIN_EMAIL, AdminAccountManager.FIREBASE_AUTH_PASSWORD).addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda4
                    @Override // com.google.android.gms.tasks.OnSuccessListener
                    public final void onSuccess(Object obj) {
                        AdminAccountManager.lambda$signInOrCreateDefaultAdmin$1(completion2, (AuthResult) obj);
                    }
                }).addOnFailureListener(new OnFailureListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda5
                    @Override // com.google.android.gms.tasks.OnFailureListener
                    public final void onFailure(Exception exc2) {
                        completion2.onError(exc);
                    }
                });
            }
        });
    }

    static /* synthetic */ void lambda$signInOrCreateDefaultAdmin$0(Completion completion, AuthResult result) {
        FirebaseUser user = result.getUser();
        if (user == null) {
            completion.onError(new IllegalStateException("Firebase returned an empty admin user."));
        } else {
            ensureAdminDatabaseRecord(user, completion);
        }
    }

    static /* synthetic */ void lambda$signInOrCreateDefaultAdmin$1(Completion completion, AuthResult result) {
        FirebaseUser user = result.getUser();
        if (user == null) {
            completion.onError(new IllegalStateException("Firebase could not create the admin user."));
        } else {
            ensureAdminDatabaseRecord(user, completion);
        }
    }

    public static void ensureAdminDatabaseRecord(final FirebaseUser user, final Completion completion) {
        if (!isDefaultAdminEmail(user.getEmail())) {
            completion.onError(new SecurityException("This Firebase user is not the configured ShiftSmart admin."));
            return;
        }
        String uid = user.getUid();
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        Map<String, Object> updates = new HashMap<>();
        String adminPath = "admins/" + uid + DomExceptionUtils.SEPARATOR;
        updates.put(adminPath + "email", ADMIN_EMAIL);
        updates.put(adminPath + "role", ADMIN_PASSWORD);
        updates.put(adminPath + SosAlert.STATUS_ACTIVE, true);
        updates.put(adminPath + "updatedAt", ServerValue.TIMESTAMP);
        String userPath = "users/" + uid + DomExceptionUtils.SEPARATOR;
        updates.put(userPath + "name", "ShiftSmart Admin");
        updates.put(userPath + "email", ADMIN_EMAIL);
        updates.put(userPath + "phone", "");
        updates.put(userPath + "disabled", false);
        updates.put(userPath + "role", ADMIN_PASSWORD);
        Task<Void> taskAddOnSuccessListener = root.updateChildren(updates).addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda2
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                completion.onSuccess(user);
            }
        });
        Objects.requireNonNull(completion);
        taskAddOnSuccessListener.addOnFailureListener(new OnFailureListener() { // from class: cyberorion.pk.AdminAccountManager$$ExternalSyntheticLambda3
            @Override // com.google.android.gms.tasks.OnFailureListener
            public final void onFailure(Exception exc) {
                completion.onError(exc);
            }
        });
    }
}
