package cyberorion.pk;

import android.location.Location;

/* JADX INFO: loaded from: classes3.dex */
public final class GeoUtils {
    private GeoUtils() {
    }

    public static double distanceKm(double lat1, double lon1, double lat2, double lon2) {
        float[] results = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, results);
        return ((double) results[0]) / 1000.0d;
    }
}
