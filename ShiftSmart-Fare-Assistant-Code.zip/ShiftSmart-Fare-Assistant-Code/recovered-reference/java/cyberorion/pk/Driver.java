package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class Driver {
    public static final String STATUS_APPROVED = "approved";
    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_REJECTED = "rejected";
    public String approvalStatus;
    public boolean approved;
    public boolean available;
    public double capacity;
    public int completedTrips;
    public Double currentLat;
    public Double currentLng;
    public boolean disabled;
    public String driverId;
    public String email;
    public int experienceYears;
    public transient String matchReason;
    public transient double matchScore;
    public String name;
    public String phone;
    public String photoData;
    public String photoUrl;
    public float rating;
    public String vehicleNumber;
    public String vehicleType;

    public Driver() {
    }

    public Driver(String driverId, String name, String vehicleType, String vehicleNumber, double capacity, float rating, boolean available) {
        this.driverId = driverId;
        this.name = name;
        this.vehicleType = vehicleType;
        this.vehicleNumber = vehicleNumber;
        this.capacity = capacity;
        this.rating = rating;
        this.available = available;
        this.approved = true;
        this.approvalStatus = STATUS_APPROVED;
    }

    public boolean isApproved() {
        return this.approvalStatus == null || this.approvalStatus.trim().isEmpty() || STATUS_APPROVED.equalsIgnoreCase(this.approvalStatus) || this.approved;
    }
}
