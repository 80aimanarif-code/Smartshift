package cyberorion.pk;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.core.ServerValues;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class NegotiationActivity extends AppCompatActivity {
    private NegotiationAdapter adapter;
    private double aiFare;
    private String bookingId;
    private DatabaseReference bookingRef;
    private TextInputEditText etOfferAmount;
    private View layoutQuickActions;
    private String myRole;
    private DatabaseReference offersRef;
    private RecyclerView rvOffers;
    private TextView tvAiFareReference;
    private TextView tvNegotiationStatus;
    private final List<NegotiationOffer> offers = new ArrayList();
    private boolean negotiationClosed = false;
    private boolean sendInFlight = false;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_negotiation);
        this.bookingId = getIntent().getStringExtra(BookingKeys.EXTRA_BOOKING_ID);
        this.myRole = getIntent().getStringExtra(BookingKeys.EXTRA_ROLE);
        this.aiFare = getIntent().getDoubleExtra(BookingKeys.EXTRA_AI_FARE, 0.0d);
        if (this.myRole == null) {
            this.myRole = BookingKeys.ROLE_CUSTOMER;
        }
        if (this.bookingId == null) {
            Toast.makeText(this, "Missing booking reference", 0).show();
            finish();
            return;
        }
        this.rvOffers = (RecyclerView) findViewById(R.id.rvOffers);
        this.tvAiFareReference = (TextView) findViewById(R.id.tvAiFareReference);
        this.tvNegotiationStatus = (TextView) findViewById(R.id.tvNegotiationStatus);
        this.layoutQuickActions = findViewById(R.id.layoutQuickActions);
        this.etOfferAmount = (TextInputEditText) findViewById(R.id.etOfferAmount);
        this.tvAiFareReference.setText(getString(R.string.ai_fare_reference_format, new Object[]{Double.valueOf(this.aiFare)}));
        this.rvOffers.setLayoutManager(new LinearLayoutManager(this));
        this.adapter = new NegotiationAdapter(this.offers, this.myRole);
        this.rvOffers.setAdapter(this.adapter);
        findViewById(R.id.btnSendOffer).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m426lambda$onCreate$0$cyberorionpkNegotiationActivity(view);
            }
        });
        findViewById(R.id.btnAcceptOffer).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m427lambda$onCreate$1$cyberorionpkNegotiationActivity(view);
            }
        });
        findViewById(R.id.btnRejectOffer).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m428lambda$onCreate$2$cyberorionpkNegotiationActivity(view);
            }
        });
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        this.offersRef = root.child("negotiations").child(this.bookingId).child("offers");
        this.bookingRef = root.child("bookings").child(this.bookingId);
        listenForOffers();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m426lambda$onCreate$0$cyberorionpkNegotiationActivity(View v) {
        sendOffer("offer");
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m427lambda$onCreate$1$cyberorionpkNegotiationActivity(View v) {
        sendOffer("accept");
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m428lambda$onCreate$2$cyberorionpkNegotiationActivity(View v) {
        sendOffer("reject");
    }

    private void listenForOffers() {
        this.offersRef.orderByChild(ServerValues.NAME_OP_TIMESTAMP).addChildEventListener(new ChildEventListener() { // from class: cyberorion.pk.NegotiationActivity.1
            @Override // com.google.firebase.database.ChildEventListener
            public void onChildAdded(DataSnapshot snapshot, String previousChildName) {
                NegotiationOffer offer = (NegotiationOffer) snapshot.getValue(NegotiationOffer.class);
                if (offer == null) {
                    return;
                }
                NegotiationActivity.this.offers.add(offer);
                NegotiationActivity.this.adapter.notifyItemInserted(NegotiationActivity.this.offers.size() - 1);
                NegotiationActivity.this.rvOffers.scrollToPosition(NegotiationActivity.this.offers.size() - 1);
                NegotiationActivity.this.updateActionState(offer);
            }

            @Override // com.google.firebase.database.ChildEventListener
            public void onChildChanged(DataSnapshot snapshot, String previousChildName) {
            }

            @Override // com.google.firebase.database.ChildEventListener
            public void onChildRemoved(DataSnapshot snapshot) {
            }

            @Override // com.google.firebase.database.ChildEventListener
            public void onChildMoved(DataSnapshot snapshot, String previousChildName) {
            }

            @Override // com.google.firebase.database.ChildEventListener
            public void onCancelled(DatabaseError error) {
                Toast.makeText(NegotiationActivity.this, error.getMessage(), 0).show();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateActionState(NegotiationOffer latest) {
        if (this.negotiationClosed) {
            return;
        }
        if ("accept".equals(latest.type)) {
            this.negotiationClosed = true;
            this.layoutQuickActions.setVisibility(8);
            this.tvNegotiationStatus.setVisibility(0);
            this.tvNegotiationStatus.setText(getString(R.string.negotiation_completed_format, new Object[]{Double.valueOf(latest.amount)}));
            return;
        }
        if ("reject".equals(latest.type)) {
            this.layoutQuickActions.setVisibility(8);
        } else {
            boolean fromOtherParty = !this.myRole.equals(latest.senderRole);
            this.layoutQuickActions.setVisibility(fromOtherParty ? 0 : 8);
        }
    }

    private void sendOffer(String type) {
        double amount;
        if (this.sendInFlight) {
            return;
        }
        if ("offer".equals(type)) {
            String text = this.etOfferAmount.getText() != null ? this.etOfferAmount.getText().toString().trim() : "";
            if (TextUtils.isEmpty(text)) {
                Toast.makeText(this, "Enter an amount first", 0).show();
                return;
            }
            try {
                amount = Double.parseDouble(text);
                if (!this.offers.isEmpty()) {
                    type = "counter";
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid amount", 0).show();
                return;
            }
        } else {
            amount = this.offers.isEmpty() ? this.aiFare : this.offers.get(this.offers.size() - 1).amount;
        }
        final String finalType = type;
        final double finalAmount = amount;
        this.sendInFlight = true;
        setSendControlsEnabled(false);
        NegotiationOffer newOffer = new NegotiationOffer(this.myRole, finalAmount, finalType, System.currentTimeMillis());
        this.offersRef.push().setValue(newOffer).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda5
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m429lambda$sendOffer$3$cyberorionpkNegotiationActivity(finalType, finalAmount, task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendOffer$3$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m429lambda$sendOffer$3$cyberorionpkNegotiationActivity(String finalType, double finalAmount, Task task) {
        this.sendInFlight = false;
        setSendControlsEnabled(true);
        if (!task.isSuccessful()) {
            Toast.makeText(this, "Could not send. Try again.", 0).show();
            return;
        }
        this.etOfferAmount.setText("");
        if ("accept".equals(finalType)) {
            finalizeFare(finalAmount);
        }
        notifyOtherParty(finalType, finalAmount);
    }

    private void setSendControlsEnabled(boolean enabled) {
        findViewById(R.id.btnSendOffer).setEnabled(enabled);
        findViewById(R.id.btnAcceptOffer).setEnabled(enabled);
        findViewById(R.id.btnRejectOffer).setEnabled(enabled);
    }

    private void notifyOtherParty(final String type, final double amount) {
        this.bookingRef.get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                this.f$0.m425lambda$notifyOtherParty$4$cyberorionpkNegotiationActivity(type, amount, (DataSnapshot) obj);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyOtherParty$4$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m425lambda$notifyOtherParty$4$cyberorionpkNegotiationActivity(String type, double amount, DataSnapshot snapshot) {
        String title;
        String message;
        Booking booking = (Booking) snapshot.getValue(Booking.class);
        if (booking == null) {
            return;
        }
        String recipientId = BookingKeys.ROLE_CUSTOMER.equals(this.myRole) ? booking.driverId : booking.userId;
        if (recipientId == null || recipientId.isEmpty()) {
            return;
        }
        if ("accept".equals(type)) {
            title = "Fare agreed";
            message = String.format(Locale.getDefault(), "You agreed on Rs. %.0f for this job.", Double.valueOf(amount));
        } else if ("reject".equals(type)) {
            title = "Offer rejected";
            message = "Your negotiation offer was rejected.";
        } else {
            title = "New fare offer";
            message = String.format(Locale.getDefault(), "New offer: Rs. %.0f. Open to respond.", Double.valueOf(amount));
        }
        NotificationHelper.notify(recipientId, title, message, AppNotification.TYPE_NEGOTIATION, this.bookingId);
    }

    private void finalizeFare(double amount) {
        final Map<String, Object> updates = new HashMap<>();
        updates.put("negotiatedFare", Double.valueOf(amount));
        updates.put("finalFare", Double.valueOf(amount));
        updates.put("updatedAt", Long.valueOf(System.currentTimeMillis()));
        this.bookingRef.child("status").get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.NegotiationActivity$$ExternalSyntheticLambda4
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                this.f$0.m424lambda$finalizeFare$5$cyberorionpkNegotiationActivity(updates, (DataSnapshot) obj);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$finalizeFare$5$cyberorion-pk-NegotiationActivity, reason: not valid java name */
    /* synthetic */ void m424lambda$finalizeFare$5$cyberorionpkNegotiationActivity(Map updates, DataSnapshot snapshot) {
        String status = (String) snapshot.getValue(String.class);
        if (status != null && BookingStatus.fromLabel(status) == BookingStatus.PENDING) {
            updates.put("status", BookingStatus.ACCEPTED.label);
        }
        this.bookingRef.updateChildren(updates);
    }
}
