package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class DamageReport {
    public static final String CONDITION_DAMAGED = "damaged";
    public static final String CONDITION_GOOD = "good";
    public static final String STAGE_DELIVERY = "delivery";
    public static final String STAGE_PICKUP = "pickup";
    public String bookingId;
    public String condition;
    public String notes;
    public String photoUris;
    public String reportId;
    public String reportedBy;
    public String stage;
    public long timestamp;

    public DamageReport() {
    }

    public DamageReport(String bookingId, String stage, String condition, String notes, String photoUris, String reportedBy) {
        this.bookingId = bookingId;
        this.stage = stage;
        this.condition = condition;
        this.notes = notes;
        this.photoUris = photoUris;
        this.reportedBy = reportedBy;
        this.timestamp = System.currentTimeMillis();
    }

    public int photoCount() {
        if (this.photoUris == null || this.photoUris.trim().isEmpty()) {
            return 0;
        }
        return this.photoUris.split(",").length;
    }
}
