package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class DriverDashboardActivity extends AppCompatActivity implements DriverJobAdapter.OnJobActionListener {
    private DriverJobAdapter adapter;
    private DatabaseReference bookingsRef;
    private View dotDriverAvailability;
    private String driverId;
    private DatabaseReference driverRef;
    private View emptyState;
    private FirebaseAuth mAuth;
    private View pillDriverAvailability;
    private RecyclerView rvJobs;
    private TextView tvDriverAvailability;
    private TextView tvDriverAvatarInitial;
    private TextView tvDriverGreeting;
    private TextView tvEarningsSummary;
    private TextView tvEmptyMessage;
    private TextView tvStatRating;
    private TextView tvStatTrips;
    private TextView tvStatVehicle;
    private final List<Booking> allJobs = new ArrayList();
    private final List<Booking> visibleJobs = new ArrayList();
    private int selectedTab = 0;
    private boolean driverAvailable = false;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_driver_dashboard);
        this.mAuth = FirebaseAuth.getInstance();
        if (this.mAuth.getCurrentUser() == null) {
            goToLogin();
            return;
        }
        this.driverId = this.mAuth.getCurrentUser().getUid();
        this.rvJobs = (RecyclerView) findViewById(R.id.rvJobs);
        this.emptyState = findViewById(R.id.emptyState);
        this.tvEmptyMessage = (TextView) findViewById(R.id.tvEmptyMessage);
        this.tvDriverGreeting = (TextView) findViewById(R.id.tvDriverGreeting);
        this.tvEarningsSummary = (TextView) findViewById(R.id.tvEarningsSummary);
        this.tvDriverAvatarInitial = (TextView) findViewById(R.id.tvDriverAvatarInitial);
        this.tvDriverAvailability = (TextView) findViewById(R.id.tvDriverAvailability);
        this.dotDriverAvailability = findViewById(R.id.dotDriverAvailability);
        this.pillDriverAvailability = findViewById(R.id.pillDriverAvailability);
        this.tvStatRating = (TextView) findViewById(R.id.tvStatRating);
        this.tvStatTrips = (TextView) findViewById(R.id.tvStatTrips);
        this.tvStatVehicle = (TextView) findViewById(R.id.tvStatVehicle);
        this.rvJobs.setLayoutManager(new LinearLayoutManager(this));
        this.adapter = new DriverJobAdapter(this.visibleJobs, this);
        this.rvJobs.setAdapter(this.adapter);
        TabLayout tabs = (TabLayout) findViewById(R.id.tabLayout);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() { // from class: cyberorion.pk.DriverDashboardActivity.1
            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabReselected(TabLayout.Tab t) {
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabSelected(TabLayout.Tab t) {
                DriverDashboardActivity.this.selectedTab = t.getPosition();
                DriverDashboardActivity.this.refreshVisibleJobs();
            }

            @Override // com.google.android.material.tabs.TabLayout.BaseOnTabSelectedListener
            public void onTabUnselected(TabLayout.Tab t) {
            }
        });
        findViewById(R.id.tvDriverLogout).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m351lambda$onCreate$0$cyberorionpkDriverDashboardActivity(view);
            }
        });
        findViewById(R.id.btnDriverNotifications).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m352lambda$onCreate$1$cyberorionpkDriverDashboardActivity(view);
            }
        });
        NotificationHelper.attachUnreadBadge(this.driverId, findViewById(R.id.viewDriverNotifBadge));
        this.pillDriverAvailability.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m353lambda$onCreate$2$cyberorionpkDriverDashboardActivity(view);
            }
        });
        this.bookingsRef = FirebaseDatabase.getInstance().getReference("bookings");
        this.driverRef = FirebaseDatabase.getInstance().getReference("drivers").child(this.driverId);
        verifyAccessAndListen();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m351lambda$onCreate$0$cyberorionpkDriverDashboardActivity(View v) {
        this.mAuth.signOut();
        goToLogin();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m352lambda$onCreate$1$cyberorionpkDriverDashboardActivity(View v) {
        startActivity(new Intent(this, (Class<?>) NotificationsActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m353lambda$onCreate$2$cyberorionpkDriverDashboardActivity(View v) {
        toggleAvailability();
    }

    private void verifyAccessAndListen() {
        this.driverRef.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.DriverDashboardActivity.2
            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
                DriverDashboardActivity.this.goToLogin();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                Driver d = (Driver) s.getValue(Driver.class);
                if (d != null && !d.disabled && d.isApproved()) {
                    DriverDashboardActivity.this.bindDriverProfile(d);
                    DriverDashboardActivity.this.listenJobs();
                } else {
                    DriverDashboardActivity.this.mAuth.signOut();
                    Toast.makeText(DriverDashboardActivity.this, "Driver access is not active", 1).show();
                    DriverDashboardActivity.this.goToLogin();
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void bindDriverProfile(Driver d) {
        String name = (d.name == null || d.name.trim().isEmpty()) ? "Driver" : d.name;
        this.tvDriverGreeting.setText("Hi, " + name);
        this.tvDriverAvatarInitial.setText(String.valueOf(Character.toUpperCase(name.charAt(0))));
        this.tvStatRating.setText(d.rating > 0.0f ? String.format(Locale.getDefault(), "%.1f ★", Float.valueOf(d.rating)) : "New");
        this.tvStatTrips.setText(String.valueOf(d.completedTrips));
        this.tvStatVehicle.setText((d.vehicleType == null || d.vehicleType.trim().isEmpty()) ? "—" : d.vehicleType);
        this.driverAvailable = d.available;
        applyAvailabilityUi();
    }

    private void applyAvailabilityUi() {
        this.dotDriverAvailability.setBackgroundResource(this.driverAvailable ? R.drawable.bg_circle_success : R.drawable.bg_circle_error);
        this.tvDriverAvailability.setText(this.driverAvailable ? "Online · tap to go offline" : "Offline · tap to go online");
    }

    private void toggleAvailability() {
        final boolean next = !this.driverAvailable;
        this.driverRef.child("available").setValue(Boolean.valueOf(next)).addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda4
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                this.f$0.m354x4bddb2e1(next, (Void) obj);
            }
        }).addOnFailureListener(new OnFailureListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda5
            @Override // com.google.android.gms.tasks.OnFailureListener
            public final void onFailure(Exception exc) {
                this.f$0.m355x14deaa22(exc);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$toggleAvailability$3$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m354x4bddb2e1(boolean next, Void v) {
        this.driverAvailable = next;
        applyAvailabilityUi();
    }

    /* JADX INFO: renamed from: lambda$toggleAvailability$4$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m355x14deaa22(Exception e) {
        Toast.makeText(this, "Could not update status: " + e.getMessage(), 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void listenJobs() {
        this.bookingsRef.orderByChild("driverId").equalTo(this.driverId).addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.DriverDashboardActivity.3
            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
                Toast.makeText(DriverDashboardActivity.this, "Could not load jobs: " + e.getMessage(), 0).show();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                DriverDashboardActivity.this.allJobs.clear();
                for (DataSnapshot c : s.getChildren()) {
                    Booking b = (Booking) c.getValue(Booking.class);
                    if (b != null) {
                        b.bookingId = c.getKey();
                        DriverDashboardActivity.this.allJobs.add(b);
                    }
                }
                DriverDashboardActivity.this.refreshVisibleJobs();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Code duplicated, block: B:15:0x003b  */
    public void refreshVisibleJobs() {
        this.visibleJobs.clear();
        double earnings = 0.0d;
        int paidTrips = 0;
        Iterator<Booking> it = this.allJobs.iterator();
        while (true) {
            boolean match = true;
            if (!it.hasNext()) {
                break;
            }
            Booking b = it.next();
            BookingStatus st = BookingStatus.fromLabel(b.status);
            if (st == BookingStatus.DELIVERED || st == BookingStatus.COMPLETED) {
                earnings += fare(b);
                paidTrips++;
            }
            if (this.selectedTab == 0) {
                if (st != BookingStatus.PENDING) {
                    match = false;
                }
            } else if (this.selectedTab == 1) {
                match = st.isActive();
            } else if (this.selectedTab < 2 || (st != BookingStatus.DELIVERED && st != BookingStatus.COMPLETED && (this.selectedTab != 2 || (st != BookingStatus.CANCELLED && st != BookingStatus.REJECTED)))) {
                match = false;
            }
            if (match) {
                this.visibleJobs.add(b);
            }
        }
        this.adapter.notifyDataSetChanged();
        boolean earning = this.selectedTab == 3;
        this.tvEarningsSummary.setVisibility(earning ? 0 : 8);
        this.tvEarningsSummary.setText(String.format(Locale.getDefault(), "Total earnings: Rs. %,.0f\nCompleted paid trips: %d", Double.valueOf(earnings), Integer.valueOf(paidTrips)));
        boolean empty = this.visibleJobs.isEmpty();
        this.emptyState.setVisibility(empty ? 0 : 8);
        this.rvJobs.setVisibility(empty ? 8 : 0);
        if (empty) {
            String[] m = {"No available jobs right now", "No active trips right now", "No completed jobs yet", "No paid trips yet"};
            this.tvEmptyMessage.setText(m[Math.min(this.selectedTab, 3)]);
        }
    }

    private double fare(Booking b) {
        Double d;
        if (b.finalFare != null) {
            d = b.finalFare;
        } else {
            if (b.negotiatedFare == null) {
                return b.estimatedFare;
            }
            d = b.negotiatedFare;
        }
        return d.doubleValue();
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onAccept(Booking b) {
        updateStatus(b, BookingStatus.ACCEPTED);
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onAdvanceStatus(Booking b, BookingStatus s) {
        updateStatus(b, s);
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onNegotiate(Booking b) {
        Intent i = new Intent(this, (Class<?>) NegotiationActivity.class);
        i.putExtra(BookingKeys.EXTRA_BOOKING_ID, b.bookingId);
        i.putExtra(BookingKeys.EXTRA_ROLE, BookingKeys.ROLE_DRIVER);
        i.putExtra(BookingKeys.EXTRA_AI_FARE, b.estimatedFare);
        startActivity(i);
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onOpenTracking(Booking b) {
        Intent i = new Intent(this, (Class<?>) TrackingActivity.class);
        i.putExtra(BookingKeys.EXTRA_BOOKING_ID, b.bookingId);
        i.putExtra(BookingKeys.EXTRA_ROLE, BookingKeys.ROLE_DRIVER);
        startActivity(i);
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onReject(Booking b) {
        updateStatus(b, BookingStatus.REJECTED);
    }

    @Override // cyberorion.pk.DriverJobAdapter.OnJobActionListener
    public void onVerifyDamage(Booking b, String stage) {
        Intent i = new Intent(this, (Class<?>) DamageVerificationActivity.class);
        i.putExtra(BookingKeys.EXTRA_BOOKING_ID, b.bookingId);
        i.putExtra(BookingKeys.EXTRA_DAMAGE_STAGE, stage);
        startActivity(i);
    }

    private void updateStatus(final Booking b, final BookingStatus st) {
        if (b.bookingId == null) {
            return;
        }
        Map<String, Object> u = new HashMap<>();
        u.put("status", st.label);
        u.put("updatedAt", Long.valueOf(System.currentTimeMillis()));
        this.bookingsRef.child(b.bookingId).updateChildren(u).addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.DriverDashboardActivity$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                this.f$0.m356lambda$updateStatus$5$cyberorionpkDriverDashboardActivity(b, st, (Void) obj);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$updateStatus$5$cyberorion-pk-DriverDashboardActivity, reason: not valid java name */
    /* synthetic */ void m356lambda$updateStatus$5$cyberorionpkDriverDashboardActivity(Booking b, BookingStatus st, Void v) {
        NotificationHelper.notifyStatusChange(b.userId, b, st);
        if (st == BookingStatus.ACCEPTED) {
            this.driverRef.child("available").setValue(false);
        }
        if (st == BookingStatus.REJECTED || st == BookingStatus.DELIVERED || st == BookingStatus.COMPLETED || st == BookingStatus.CANCELLED) {
            this.driverRef.child("available").setValue(true);
        }
        if (st == BookingStatus.DELIVERED || st == BookingStatus.COMPLETED) {
            countTripOnce(b.bookingId);
        }
    }

    private void countTripOnce(String bookingId) {
        DatabaseReference flag = this.bookingsRef.child(bookingId).child("driverTripCounted");
        flag.runTransaction(new Transaction.Handler() { // from class: cyberorion.pk.DriverDashboardActivity.4
            @Override // com.google.firebase.database.Transaction.Handler
            public Transaction.Result doTransaction(MutableData d) {
                Boolean counted = (Boolean) d.getValue(Boolean.class);
                if (Boolean.TRUE.equals(counted)) {
                    return Transaction.abort();
                }
                d.setValue(true);
                return Transaction.success(d);
            }

            @Override // com.google.firebase.database.Transaction.Handler
            public void onComplete(DatabaseError e, boolean committed, DataSnapshot s) {
                if (committed) {
                    DriverDashboardActivity.this.driverRef.child("completedTrips").runTransaction(new Transaction.Handler() { // from class: cyberorion.pk.DriverDashboardActivity.4.1
                        @Override // com.google.firebase.database.Transaction.Handler
                        public Transaction.Result doTransaction(MutableData d) {
                            Integer n = (Integer) d.getValue(Integer.class);
                            d.setValue(Integer.valueOf((n == null ? 0 : n.intValue()) + 1));
                            return Transaction.success(d);
                        }

                        @Override // com.google.firebase.database.Transaction.Handler
                        public void onComplete(DatabaseError e2, boolean c, DataSnapshot s2) {
                        }
                    });
                }
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void goToLogin() {
        Intent i = new Intent(this, (Class<?>) DriverLoginActivity.class);
        i.addFlags(268468224);
        startActivity(i);
        finish();
    }
}
