package cyberorion.pk;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public class CargoCategory implements Serializable {
    public final double approxCapacityKg;
    public final String description;
    public final boolean fragile;
    public final ShiftingType.CargoGroup group;
    public final int iconRes;
    public final String id;
    public final String name;

    public CargoCategory(String id, String name, String description, int iconRes, double approxCapacityKg, boolean fragile, ShiftingType.CargoGroup group) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.iconRes = iconRes;
        this.approxCapacityKg = approxCapacityKg;
        this.fragile = fragile;
        this.group = group;
    }
}
