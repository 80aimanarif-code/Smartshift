package cyberorion.pk;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class BookingReviewActivity extends AppCompatActivity {
    private static final int PICK_PDF_REQUEST = 101;
    private String bookingId;
    private Button btnConfirmBooking;
    private MaterialButton btnDeleteNOC;
    private MaterialButton btnNegotiate;
    private MaterialButton btnPreviewNOC;
    private MaterialButton btnReplaceNOC;
    private MaterialButton btnUploadNOC;
    private CargoSelection cargoSelection;
    private Double distanceKm;
    private String driverId;
    private String driverName;
    private String dropoff;
    private int estimatedDurationMin;
    private double estimatedFare;
    private TextInputEditText etInstructions;
    private Double finalFare;
    private View layoutNocActions;
    private View layoutNocNotice;
    private String luggageType;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private Uri nocFileUri;
    private NocPolicy.NocRequirement nocRequirement;
    private String pickup;
    private TextView tvDamageRiskPreview;
    private TextView tvNOCStatus;
    private TextView tvNocNoticeReason;
    private TextView tvNocNoticeTitle;
    private TextView tvReviewFare;
    private TextView tvReviewFinalFare;
    private TextView tvSummaryDriver;
    private TextView tvSummaryLuggage;
    private TextView tvSummaryRoute;
    private double vehicleCapacity;
    private String vehicleNumber;
    private String vehicleType;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        Double dValueOf;
        String string;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_review);
        this.mAuth = FirebaseAuth.getInstance();
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
        this.bookingId = getIntent().getStringExtra(BookingKeys.EXTRA_BOOKING_ID);
        this.pickup = getIntent().getStringExtra(BookingKeys.EXTRA_PICKUP);
        this.dropoff = getIntent().getStringExtra(BookingKeys.EXTRA_DROPOFF);
        this.luggageType = getIntent().getStringExtra(BookingKeys.EXTRA_LUGGAGE_TYPE);
        this.driverId = getIntent().getStringExtra(BookingKeys.EXTRA_DRIVER_ID);
        this.driverName = getIntent().getStringExtra(BookingKeys.EXTRA_DRIVER_NAME);
        this.vehicleType = getIntent().getStringExtra(BookingKeys.EXTRA_VEHICLE_TYPE);
        this.vehicleNumber = getIntent().getStringExtra(BookingKeys.EXTRA_VEHICLE_NUMBER);
        this.vehicleCapacity = getIntent().getDoubleExtra(BookingKeys.EXTRA_VEHICLE_CAPACITY, 0.0d);
        this.cargoSelection = (CargoSelection) getIntent().getSerializableExtra(BookingKeys.EXTRA_CARGO_SELECTION);
        if (getIntent().hasExtra(BookingKeys.EXTRA_DISTANCE_KM)) {
            dValueOf = Double.valueOf(getIntent().getDoubleExtra(BookingKeys.EXTRA_DISTANCE_KM, 0.0d));
        } else {
            dValueOf = null;
        }
        this.distanceKm = dValueOf;
        this.estimatedFare = getIntent().getDoubleExtra(BookingKeys.EXTRA_ESTIMATED_FARE, 0.0d);
        this.estimatedDurationMin = getIntent().getIntExtra(BookingKeys.EXTRA_ESTIMATED_DURATION_MIN, 0);
        this.tvSummaryRoute = (TextView) findViewById(R.id.tvSummaryRoute);
        this.tvSummaryLuggage = (TextView) findViewById(R.id.tvSummaryLuggage);
        this.tvSummaryDriver = (TextView) findViewById(R.id.tvSummaryDriver);
        this.tvReviewFare = (TextView) findViewById(R.id.tvReviewFare);
        this.tvReviewFinalFare = (TextView) findViewById(R.id.tvReviewFinalFare);
        this.tvDamageRiskPreview = (TextView) findViewById(R.id.tvDamageRiskPreview);
        this.btnNegotiate = (MaterialButton) findViewById(R.id.btnNegotiate);
        this.etInstructions = (TextInputEditText) findViewById(R.id.etInstructions);
        this.btnUploadNOC = (MaterialButton) findViewById(R.id.btnUploadNOC);
        this.btnConfirmBooking = (Button) findViewById(R.id.btnConfirmBooking);
        this.tvNOCStatus = (TextView) findViewById(R.id.tvNOCStatus);
        this.layoutNocNotice = findViewById(R.id.layoutNocNotice);
        this.tvNocNoticeTitle = (TextView) findViewById(R.id.tvNocNoticeTitle);
        this.tvNocNoticeReason = (TextView) findViewById(R.id.tvNocNoticeReason);
        this.layoutNocActions = findViewById(R.id.layoutNocActions);
        this.btnPreviewNOC = (MaterialButton) findViewById(R.id.btnPreviewNOC);
        this.btnReplaceNOC = (MaterialButton) findViewById(R.id.btnReplaceNOC);
        this.btnDeleteNOC = (MaterialButton) findViewById(R.id.btnDeleteNOC);
        this.tvReviewFare.setText(getString(R.string.fare_amount_format, new Object[]{Double.valueOf(this.estimatedFare)}));
        this.btnNegotiate.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m309lambda$onCreate$0$cyberorionpkBookingReviewActivity(view);
            }
        });
        listenForFinalFare();
        TextView textView = this.tvSummaryRoute;
        if (this.distanceKm != null) {
            string = getString(R.string.route_with_distance_format, new Object[]{this.pickup, this.dropoff, this.distanceKm});
        } else {
            string = getString(R.string.route_format, new Object[]{this.pickup, this.dropoff});
        }
        textView.setText(string);
        this.tvSummaryLuggage.setText(this.cargoSelection != null ? this.cargoSelection.summaryLine() : this.luggageType);
        this.tvSummaryDriver.setText(getString(R.string.summary_driver_format, new Object[]{this.driverName, this.vehicleType, this.vehicleNumber}));
        DamageRiskAssessment damageRisk = DamageRiskScorer.assess(this.cargoSelection);
        this.tvDamageRiskPreview.setText("Damage Risk: " + damageRisk.level + " (" + damageRisk.score + "/100) • " + damageRisk.recommendation);
        this.nocRequirement = NocPolicy.evaluate(this.cargoSelection, this.distanceKm);
        applyNocRequirementToUi();
        this.btnUploadNOC.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m310lambda$onCreate$1$cyberorionpkBookingReviewActivity(view);
            }
        });
        this.btnReplaceNOC.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m311lambda$onCreate$2$cyberorionpkBookingReviewActivity(view);
            }
        });
        this.btnPreviewNOC.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m312lambda$onCreate$3$cyberorionpkBookingReviewActivity(view);
            }
        });
        this.btnDeleteNOC.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m313lambda$onCreate$4$cyberorionpkBookingReviewActivity(view);
            }
        });
        this.btnConfirmBooking.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m314lambda$onCreate$5$cyberorionpkBookingReviewActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m309lambda$onCreate$0$cyberorionpkBookingReviewActivity(View v) {
        openNegotiation();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m310lambda$onCreate$1$cyberorionpkBookingReviewActivity(View v) {
        openFilePicker();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m311lambda$onCreate$2$cyberorionpkBookingReviewActivity(View v) {
        openFilePicker();
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m312lambda$onCreate$3$cyberorionpkBookingReviewActivity(View v) {
        previewNoc();
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m313lambda$onCreate$4$cyberorionpkBookingReviewActivity(View v) {
        removeNoc();
    }

    /* JADX INFO: renamed from: lambda$onCreate$5$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m314lambda$onCreate$5$cyberorionpkBookingReviewActivity(View v) {
        confirmBooking();
    }

    private void applyNocRequirementToUi() {
        boolean z = this.nocRequirement.required;
        View view = this.layoutNocNotice;
        if (z) {
            view.setVisibility(0);
            this.tvNocNoticeTitle.setText(R.string.noc_required_title);
            this.tvNocNoticeReason.setText(getString(R.string.noc_required_reason_format, new Object[]{this.nocRequirement.reasonSummary()}));
        } else {
            view.setVisibility(0);
            this.tvNocNoticeTitle.setText(R.string.noc_not_required_title);
            this.tvNocNoticeReason.setText(R.string.noc_not_required_message);
        }
        refreshNocFileUi();
    }

    private void refreshNocFileUi() {
        Uri uri = this.nocFileUri;
        TextView textView = this.tvNOCStatus;
        if (uri != null) {
            textView.setText(getString(R.string.noc_selected_format, new Object[]{displayNameForUri(this.nocFileUri)}));
            this.btnUploadNOC.setVisibility(8);
            this.layoutNocActions.setVisibility(0);
        } else {
            textView.setText(R.string.no_file_selected);
            this.btnUploadNOC.setVisibility(0);
            this.btnUploadNOC.setText(R.string.upload_noc);
            this.layoutNocActions.setVisibility(8);
        }
    }

    private String displayNameForUri(Uri uri) {
        String segment = uri.getLastPathSegment();
        return segment != null ? segment : uri.toString();
    }

    private void openFilePicker() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("application/pdf");
        intent.addCategory("android.intent.category.OPENABLE");
        startActivityForResult(Intent.createChooser(intent, "Select NOC Document"), 101);
    }

    private void previewNoc() {
        if (this.nocFileUri == null) {
            return;
        }
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(this.nocFileUri, "application/pdf");
            intent.addFlags(1);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.noc_no_viewer_message, 0).show();
        }
    }

    private void removeNoc() {
        this.nocFileUri = null;
        refreshNocFileUi();
        Toast.makeText(this, R.string.noc_removed_message, 0).show();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == -1 && data != null && data.getData() != null) {
            this.nocFileUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(this.nocFileUri, 1);
            } catch (SecurityException e) {
            }
            refreshNocFileUi();
            Toast.makeText(this, R.string.noc_linked_message, 0).show();
        }
    }

    private void openNegotiation() {
        if (this.bookingId == null) {
            return;
        }
        Intent intent = new Intent(this, (Class<?>) NegotiationActivity.class);
        intent.putExtra(BookingKeys.EXTRA_BOOKING_ID, this.bookingId);
        intent.putExtra(BookingKeys.EXTRA_ROLE, BookingKeys.ROLE_CUSTOMER);
        intent.putExtra(BookingKeys.EXTRA_AI_FARE, this.estimatedFare);
        startActivity(intent);
    }

    private void listenForFinalFare() {
        if (this.bookingId == null) {
            return;
        }
        this.mDatabase.child("bookings").child(this.bookingId).addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.BookingReviewActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                Double fare = (Double) snapshot.child("finalFare").getValue(Double.class);
                if (fare != null) {
                    BookingReviewActivity.this.finalFare = fare;
                    BookingReviewActivity.this.tvReviewFinalFare.setVisibility(0);
                    BookingReviewActivity.this.tvReviewFinalFare.setText(BookingReviewActivity.this.getString(R.string.negotiated_fare_format, new Object[]{fare}));
                }
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void confirmBooking() {
        if (this.nocRequirement.required && this.nocFileUri == null) {
            Toast.makeText(this, R.string.noc_missing_toast, 1).show();
            return;
        }
        if (this.bookingId == null) {
            Toast.makeText(this, "Booking reference missing. Please go back and try again.", 0).show();
            return;
        }
        if (this.btnConfirmBooking.isEnabled()) {
            this.btnConfirmBooking.setEnabled(false);
            this.btnConfirmBooking.setText(R.string.confirming_booking);
            Map<String, Object> bookingUpdates = new HashMap<>();
            bookingUpdates.put("specialInstructions", this.etInstructions.getText().toString().trim());
            bookingUpdates.put("nocRequired", Boolean.valueOf(this.nocRequirement.required));
            bookingUpdates.put("nocReasons", this.nocRequirement.reasonSummary());
            bookingUpdates.put("nocUri", this.nocFileUri != null ? this.nocFileUri.toString() : "");
            bookingUpdates.put("status", BookingStatus.PENDING.label);
            bookingUpdates.put("updatedAt", Long.valueOf(System.currentTimeMillis()));
            if (this.finalFare != null) {
                bookingUpdates.put("finalFare", this.finalFare);
            }
            this.mDatabase.child("bookings").child(this.bookingId).updateChildren(bookingUpdates).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda7
                @Override // com.google.android.gms.tasks.OnCompleteListener
                public final void onComplete(Task task) {
                    this.f$0.m308lambda$confirmBooking$6$cyberorionpkBookingReviewActivity(task);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$confirmBooking$6$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m308lambda$confirmBooking$6$cyberorionpkBookingReviewActivity(Task task) {
        if (task.isSuccessful()) {
            showConfirmationDialog();
            return;
        }
        this.btnConfirmBooking.setEnabled(true);
        this.btnConfirmBooking.setText(R.string.confirm_booking);
        Toast.makeText(this, "Booking failed. Please try again.", 0).show();
    }

    private void showConfirmationDialog() {
        new AlertDialog.Builder(this).setIcon(R.drawable.ic_check_circle).setTitle(R.string.booking_confirmed_title).setMessage(R.string.booking_confirmed_msg).setPositiveButton("Track Order", new DialogInterface.OnClickListener() { // from class: cyberorion.pk.BookingReviewActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m315xb9e1e955(dialogInterface, i);
            }
        }).setCancelable(false).show();
    }

    /* JADX INFO: renamed from: lambda$showConfirmationDialog$7$cyberorion-pk-BookingReviewActivity, reason: not valid java name */
    /* synthetic */ void m315xb9e1e955(DialogInterface dialog, int which) {
        Intent intent = new Intent(this, (Class<?>) TrackOrderActivity.class);
        intent.addFlags(268468224);
        startActivity(intent);
    }
}
