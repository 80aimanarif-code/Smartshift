package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public enum ShiftingType {
    HOME_FURNITURE("home_furniture", "Home / Furniture Shifting", "Move furniture and household items between homes", CargoGroup.PERSONAL, R.drawable.ic_warehouse),
    PARCEL_DELIVERY("parcel_delivery", "Parcel Delivery", "Send small parcels and documents quickly", CargoGroup.PERSONAL, R.drawable.ic_package),
    LOGISTICS_CARGO("logistics_cargo", "Logistics Cargo", "Bulk, palletized, or raw-material cargo transport", CargoGroup.LOGISTICS, R.drawable.ic_box_heavy),
    FACTORY_MATERIAL("factory_material", "Factory Material Transport", "Factory, warehouse, and industrial equipment moves", CargoGroup.LOGISTICS, R.drawable.ic_vehicle_truck);

    public final String description;
    public final CargoGroup group;
    public final int iconRes;
    public final String id;
    public final String title;

    public enum CargoGroup {
        PERSONAL,
        LOGISTICS
    }

    ShiftingType(String id, String title, String description, CargoGroup group, int iconRes) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.group = group;
        this.iconRes = iconRes;
    }

    public static ShiftingType fromId(String id) {
        if (id == null) {
            return HOME_FURNITURE;
        }
        for (ShiftingType type : values()) {
            if (type.id.equals(id)) {
                return type;
            }
        }
        return HOME_FURNITURE;
    }
}
