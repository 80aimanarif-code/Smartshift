package cyberorion.pk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class DriverJobAdapter extends RecyclerView.Adapter<JobViewHolder> {
    private final List<Booking> jobs;
    private final OnJobActionListener listener;

    public interface OnJobActionListener {
        void onAccept(Booking booking);

        void onAdvanceStatus(Booking booking, BookingStatus bookingStatus);

        void onNegotiate(Booking booking);

        void onOpenTracking(Booking booking);

        void onReject(Booking booking);

        void onVerifyDamage(Booking booking, String str);
    }

    public DriverJobAdapter(List<Booking> jobs, OnJobActionListener listener) {
        this.jobs = jobs;
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public JobViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_driver_job, parent, false);
        return new JobViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(JobViewHolder holder, int position) {
        double displayFare;
        final Booking booking = this.jobs.get(position);
        BookingStatus status = BookingStatus.fromLabel(booking.status);
        holder.tvRoute.setText(String.format("%s → %s", booking.pickup, booking.dropoff));
        String cargoLabel = (booking.cargoCategoryName == null || booking.cargoCategoryName.isEmpty()) ? booking.luggageType : booking.cargoCategoryName;
        StringBuilder cargoLine = new StringBuilder(cargoLabel != null ? cargoLabel : "Cargo");
        if (booking.quantity > 1) {
            cargoLine.append(" x").append(booking.quantity);
        }
        if (booking.weightKg > 0.0d) {
            cargoLine.append(String.format(Locale.getDefault(), " • ~%.0fkg", Double.valueOf(booking.weightKg)));
        }
        if (booking.fragile) {
            cargoLine.append(" • Fragile");
        }
        holder.tvCargo.setText(cargoLine.toString());
        holder.tvDistance.setText(String.format(Locale.getDefault(), "Distance: %.1f km • NOC: %s", Double.valueOf(booking.distanceKm), booking.nocRequired ? "Required" : "Not required"));
        if (booking.specialInstructions != null && !booking.specialInstructions.trim().isEmpty()) {
            holder.tvInstructions.setVisibility(0);
            holder.tvInstructions.setText("Note: " + booking.specialInstructions);
        } else {
            holder.tvInstructions.setVisibility(8);
        }
        if (booking.finalFare != null) {
            displayFare = booking.finalFare.doubleValue();
        } else {
            displayFare = booking.negotiatedFare != null ? booking.negotiatedFare.doubleValue() : booking.estimatedFare;
        }
        holder.tvFare.setText(holder.itemView.getContext().getString(R.string.fare_amount_format, Double.valueOf(displayFare)));
        holder.tvStatus.setText(status.label);
        holder.btnNegotiate.setVisibility(8);
        holder.btnReject.setVisibility(8);
        holder.btnDamage.setVisibility(8);
        holder.btnPrimaryAction.setVisibility(0);
        holder.itemView.setOnClickListener(null);
        switch (status) {
            case PENDING:
                holder.btnNegotiate.setVisibility(0);
                holder.btnReject.setVisibility(0);
                holder.btnPrimaryAction.setText("Accept");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda0
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m357lambda$onBindViewHolder$0$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.btnNegotiate.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda13
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m358lambda$onBindViewHolder$1$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.btnReject.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda14
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m365lambda$onBindViewHolder$2$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            case ACCEPTED:
                holder.btnPrimaryAction.setText("Start Trip");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda15
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m366lambda$onBindViewHolder$3$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda1
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m367lambda$onBindViewHolder$4$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            case EN_ROUTE_PICKUP:
                holder.btnPrimaryAction.setText("Arrived at Pickup");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda2
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m368lambda$onBindViewHolder$5$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda3
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m369lambda$onBindViewHolder$6$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            case ARRIVED_PICKUP:
                holder.btnPrimaryAction.setText("Pickup Completed");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda4
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m370lambda$onBindViewHolder$7$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.btnDamage.setVisibility(0);
                holder.btnDamage.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda5
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m371lambda$onBindViewHolder$8$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda6
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m372lambda$onBindViewHolder$9$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            case PICKED_UP:
                holder.btnPrimaryAction.setText("Start Delivery");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda7
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m359lambda$onBindViewHolder$10$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda8
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m360lambda$onBindViewHolder$11$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            case DELIVERING:
                holder.btnPrimaryAction.setText("Mark Delivered");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda9
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m361lambda$onBindViewHolder$12$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.btnDamage.setVisibility(0);
                holder.btnDamage.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda10
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m362lambda$onBindViewHolder$13$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda11
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m363lambda$onBindViewHolder$14$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
            default:
                holder.btnPrimaryAction.setText("View");
                holder.btnPrimaryAction.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverJobAdapter$$ExternalSyntheticLambda12
                    @Override // android.view.View.OnClickListener
                    public final void onClick(View view) {
                        this.f$0.m364lambda$onBindViewHolder$15$cyberorionpkDriverJobAdapter(booking, view);
                    }
                });
                break;
        }
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m357lambda$onBindViewHolder$0$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAccept(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$1$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m358lambda$onBindViewHolder$1$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onNegotiate(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$2$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m365lambda$onBindViewHolder$2$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onReject(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$3$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m366lambda$onBindViewHolder$3$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAdvanceStatus(booking, BookingStatus.EN_ROUTE_PICKUP);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$4$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m367lambda$onBindViewHolder$4$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$5$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m368lambda$onBindViewHolder$5$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAdvanceStatus(booking, BookingStatus.ARRIVED_PICKUP);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$6$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m369lambda$onBindViewHolder$6$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$7$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m370lambda$onBindViewHolder$7$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAdvanceStatus(booking, BookingStatus.PICKED_UP);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$8$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m371lambda$onBindViewHolder$8$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onVerifyDamage(booking, DamageReport.STAGE_PICKUP);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$9$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m372lambda$onBindViewHolder$9$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$10$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m359lambda$onBindViewHolder$10$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAdvanceStatus(booking, BookingStatus.DELIVERING);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$11$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m360lambda$onBindViewHolder$11$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$12$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m361lambda$onBindViewHolder$12$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onAdvanceStatus(booking, BookingStatus.DELIVERED);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$13$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m362lambda$onBindViewHolder$13$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onVerifyDamage(booking, DamageReport.STAGE_DELIVERY);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$14$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m363lambda$onBindViewHolder$14$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$15$cyberorion-pk-DriverJobAdapter, reason: not valid java name */
    /* synthetic */ void m364lambda$onBindViewHolder$15$cyberorionpkDriverJobAdapter(Booking booking, View v) {
        this.listener.onOpenTracking(booking);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.jobs.size();
    }

    static class JobViewHolder extends RecyclerView.ViewHolder {
        MaterialButton btnDamage;
        MaterialButton btnNegotiate;
        MaterialButton btnPrimaryAction;
        MaterialButton btnReject;
        TextView tvCargo;
        TextView tvDistance;
        TextView tvFare;
        TextView tvInstructions;
        TextView tvRoute;
        TextView tvStatus;

        JobViewHolder(View itemView) {
            super(itemView);
            this.tvRoute = (TextView) itemView.findViewById(R.id.tvJobRoute);
            this.tvCargo = (TextView) itemView.findViewById(R.id.tvJobCargo);
            this.tvDistance = (TextView) itemView.findViewById(R.id.tvJobDistance);
            this.tvInstructions = (TextView) itemView.findViewById(R.id.tvJobInstructions);
            this.tvFare = (TextView) itemView.findViewById(R.id.tvJobFare);
            this.tvStatus = (TextView) itemView.findViewById(R.id.tvJobStatus);
            this.btnNegotiate = (MaterialButton) itemView.findViewById(R.id.btnJobNegotiate);
            this.btnReject = (MaterialButton) itemView.findViewById(R.id.btnJobReject);
            this.btnPrimaryAction = (MaterialButton) itemView.findViewById(R.id.btnJobPrimaryAction);
            this.btnDamage = (MaterialButton) itemView.findViewById(R.id.btnJobDamage);
        }
    }
}
