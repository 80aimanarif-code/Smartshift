package cyberorion.pk;

import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public final class VehicleRecommender {
    private static final double CAPACITY_SAFETY_MARGIN = 1.15d;

    private VehicleRecommender() {
    }

    public static VehicleRecommendation recommend(CargoSelection cargo, double distanceKm) {
        boolean fragile;
        double weight = cargo != null ? cargo.weightKg : 0.0d;
        int quantity = cargo != null ? Math.max(1, cargo.quantity) : 1;
        boolean logistics = false;
        if (cargo != null && cargo.fragile) {
            fragile = true;
        } else {
            fragile = false;
        }
        CargoCategory category = cargo != null ? CargoCatalog.findById(cargo.cargoCategoryId) : null;
        if (category != null && category.group == ShiftingType.CargoGroup.LOGISTICS) {
            logistics = true;
        }
        double requiredCapacity = (quantity > 1 ? Math.max(1.0d, ((double) quantity) * 0.6d) : 1.0d) * weight * CAPACITY_SAFETY_MARGIN;
        List<Vehicle> vehicles = VehicleCatalog.all();
        Vehicle chosen = vehicles.get(vehicles.size() - 1);
        for (Vehicle v : vehicles) {
            if (!fragile || v.suitableForFragile) {
                if (v.capacityKg >= requiredCapacity) {
                    chosen = v;
                    break;
                }
            }
        }
        if (logistics && distanceKm > 300.0d && chosen.capacityKg < 1500.0d) {
            chosen = VehicleCatalog.findById("shehzore");
        }
        StringBuilder reason = new StringBuilder();
        reason.append(String.format(Locale.getDefault(), "Recommended because your cargo requires approximately %.0f kg capacity", Double.valueOf(requiredCapacity)));
        if (fragile) {
            reason.append(", careful loading for fragile items");
        }
        if (distanceKm > 300.0d) {
            reason.append(String.format(Locale.getDefault(), ", and a %.0f km route", Double.valueOf(distanceKm)));
        }
        reason.append(".");
        return new VehicleRecommendation(chosen, reason.toString());
    }
}
