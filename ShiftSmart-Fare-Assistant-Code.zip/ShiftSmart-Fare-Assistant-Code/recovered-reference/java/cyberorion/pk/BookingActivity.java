package cyberorion.pk;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes3.dex */
public class BookingActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private MaterialButton btnCalculateRoute;
    private Button btnNext;
    private CargoSelection cargoSelection;
    private Double distanceKm;
    private Double dropoffLat;
    private Double dropoffLng;
    private TextInputEditText etDropoff;
    private TextInputEditText etPickup;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Geocoder geocoder;
    private GoogleMap googleMap;
    private String luggageType;
    private MapView mapView;
    private Double pickupLat;
    private Double pickupLng;
    private TextView tvDistanceResult;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
        this.luggageType = getIntent().getStringExtra(BookingKeys.EXTRA_LUGGAGE_TYPE);
        this.cargoSelection = (CargoSelection) getIntent().getSerializableExtra(BookingKeys.EXTRA_CARGO_SELECTION);
        this.etPickup = (TextInputEditText) findViewById(R.id.etPickup);
        this.etDropoff = (TextInputEditText) findViewById(R.id.etDropoff);
        this.btnCalculateRoute = (MaterialButton) findViewById(R.id.btnCalculateRoute);
        this.tvDistanceResult = (TextView) findViewById(R.id.tvDistanceResult);
        this.btnNext = (Button) findViewById(R.id.btnNextRoute);
        this.mapView = (MapView) findViewById(R.id.mapRoute);
        this.geocoder = new Geocoder(this, Locale.getDefault());
        Bundle mapViewBundle = savedInstanceState != null ? savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY) : null;
        this.mapView.onCreate(mapViewBundle);
        this.mapView.getMapAsync(this);
        RouteInvalidationWatcher invalidateOnEdit = new RouteInvalidationWatcher();
        this.etPickup.addTextChangedListener(invalidateOnEdit);
        this.etDropoff.addTextChangedListener(invalidateOnEdit);
        this.btnCalculateRoute.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m304lambda$onCreate$0$cyberorionpkBookingActivity(view);
            }
        });
        this.btnNext.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m305lambda$onCreate$1$cyberorionpkBookingActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-BookingActivity, reason: not valid java name */
    /* synthetic */ void m304lambda$onCreate$0$cyberorionpkBookingActivity(View v) {
        calculateRoute();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-BookingActivity, reason: not valid java name */
    /* synthetic */ void m305lambda$onCreate$1$cyberorionpkBookingActivity(View v) {
        goToFareEstimate();
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap map) {
        this.googleMap = map;
        this.googleMap.getUiSettings().setZoomControlsEnabled(true);
        if (this.distanceKm != null) {
            drawRoute();
        }
    }

    private void calculateRoute() {
        final String pickupText = this.etPickup.getText() != null ? this.etPickup.getText().toString().trim() : "";
        final String dropoffText = this.etDropoff.getText() != null ? this.etDropoff.getText().toString().trim() : "";
        if (TextUtils.isEmpty(pickupText) || TextUtils.isEmpty(dropoffText)) {
            Toast.makeText(this, "Please fill in both pickup and drop-off locations", 0).show();
            return;
        }
        this.btnCalculateRoute.setEnabled(false);
        this.tvDistanceResult.setText(R.string.locating_route);
        this.executor.execute(new Runnable() { // from class: cyberorion.pk.BookingActivity$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m302lambda$calculateRoute$3$cyberorionpkBookingActivity(pickupText, dropoffText);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$calculateRoute$3$cyberorion-pk-BookingActivity, reason: not valid java name */
    /* synthetic */ void m302lambda$calculateRoute$3$cyberorionpkBookingActivity(String pickupText, String dropoffText) {
        final Address resolvedPickup = geocodeFirst(pickupText);
        final Address resolvedDropoff = geocodeFirst(dropoffText);
        runOnUiThread(new Runnable() { // from class: cyberorion.pk.BookingActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m301lambda$calculateRoute$2$cyberorionpkBookingActivity(resolvedPickup, resolvedDropoff);
            }
        });
    }

    private Address geocodeFirst(String query) {
        if (!Geocoder.isPresent()) {
            return null;
        }
        try {
            List<Address> results = this.geocoder.getFromLocationName(query, 1);
            if (results == null || results.isEmpty()) {
                return null;
            }
            return results.get(0);
        } catch (IOException e) {
            return null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: renamed from: handleGeocodeResult, reason: merged with bridge method [inline-methods] */
    public void m301lambda$calculateRoute$2$cyberorionpkBookingActivity(Address pickupAddress, Address dropoffAddress) {
        if (isFinishing() || isDestroyed()) {
            return;
        }
        this.btnCalculateRoute.setEnabled(true);
        if (!Geocoder.isPresent()) {
            this.tvDistanceResult.setText(R.string.geocode_service_unavailable);
            return;
        }
        if (pickupAddress == null) {
            this.tvDistanceResult.setText(R.string.geocode_pickup_failed);
            return;
        }
        if (dropoffAddress == null) {
            this.tvDistanceResult.setText(R.string.geocode_dropoff_failed);
            return;
        }
        this.pickupLat = Double.valueOf(pickupAddress.getLatitude());
        this.pickupLng = Double.valueOf(pickupAddress.getLongitude());
        this.dropoffLat = Double.valueOf(dropoffAddress.getLatitude());
        this.dropoffLng = Double.valueOf(dropoffAddress.getLongitude());
        this.distanceKm = Double.valueOf(GeoUtils.distanceKm(this.pickupLat.doubleValue(), this.pickupLng.doubleValue(), this.dropoffLat.doubleValue(), this.dropoffLng.doubleValue()));
        this.tvDistanceResult.setText(getString(R.string.distance_result_format, new Object[]{this.distanceKm}));
        drawRoute();
    }

    private void drawRoute() {
        if (this.googleMap == null || this.pickupLat == null || this.dropoffLat == null) {
            return;
        }
        this.googleMap.clear();
        LatLng pickupLatLng = new LatLng(this.pickupLat.doubleValue(), this.pickupLng.doubleValue());
        LatLng dropoffLatLng = new LatLng(this.dropoffLat.doubleValue(), this.dropoffLng.doubleValue());
        this.googleMap.addMarker(new MarkerOptions().position(pickupLatLng).title("Pickup").icon(BitmapDescriptorFactory.defaultMarker(210.0f)));
        this.googleMap.addMarker(new MarkerOptions().position(dropoffLatLng).title("Drop-off").icon(BitmapDescriptorFactory.defaultMarker(30.0f)));
        this.googleMap.addPolyline(new PolylineOptions().add(pickupLatLng, dropoffLatLng).width(6.0f).color(getColor(R.color.primaryColor)).geodesic(true));
        final LatLngBounds bounds = new LatLngBounds.Builder().include(pickupLatLng).include(dropoffLatLng).build();
        this.mapView.post(new Runnable() { // from class: cyberorion.pk.BookingActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m303lambda$drawRoute$4$cyberorionpkBookingActivity(bounds);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$drawRoute$4$cyberorion-pk-BookingActivity, reason: not valid java name */
    /* synthetic */ void m303lambda$drawRoute$4$cyberorionpkBookingActivity(LatLngBounds bounds) {
        if (this.googleMap != null) {
            this.googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 96));
        }
    }

    private void goToFareEstimate() {
        String pickup = this.etPickup.getText().toString().trim();
        String dropoff = this.etDropoff.getText().toString().trim();
        if (TextUtils.isEmpty(pickup) || TextUtils.isEmpty(dropoff)) {
            Toast.makeText(this, "Please fill in both pickup and drop-off locations", 0).show();
            return;
        }
        if (this.distanceKm == null) {
            Toast.makeText(this, R.string.please_locate_route_first, 0).show();
            return;
        }
        Intent intent = new Intent(this, (Class<?>) FareEstimateActivity.class);
        intent.putExtra(BookingKeys.EXTRA_LUGGAGE_TYPE, this.luggageType);
        intent.putExtra(BookingKeys.EXTRA_CARGO_SELECTION, this.cargoSelection);
        intent.putExtra(BookingKeys.EXTRA_PICKUP, pickup);
        intent.putExtra(BookingKeys.EXTRA_DROPOFF, dropoff);
        intent.putExtra(BookingKeys.EXTRA_PICKUP_LAT, this.pickupLat);
        intent.putExtra(BookingKeys.EXTRA_PICKUP_LNG, this.pickupLng);
        intent.putExtra(BookingKeys.EXTRA_DROPOFF_LAT, this.dropoffLat);
        intent.putExtra(BookingKeys.EXTRA_DROPOFF_LNG, this.dropoffLng);
        intent.putExtra(BookingKeys.EXTRA_DISTANCE_KM, this.distanceKm);
        startActivity(intent);
    }

    private class RouteInvalidationWatcher implements TextWatcher {
        private RouteInvalidationWatcher() {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable s) {
            if (BookingActivity.this.distanceKm == null) {
                return;
            }
            BookingActivity.this.distanceKm = null;
            BookingActivity bookingActivity = BookingActivity.this;
            BookingActivity bookingActivity2 = BookingActivity.this;
            BookingActivity bookingActivity3 = BookingActivity.this;
            BookingActivity.this.dropoffLng = null;
            bookingActivity3.dropoffLat = null;
            bookingActivity2.pickupLng = null;
            bookingActivity.pickupLat = null;
            BookingActivity.this.tvDistanceResult.setText(R.string.distance_placeholder);
            if (BookingActivity.this.googleMap != null) {
                BookingActivity.this.googleMap.clear();
            }
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStart() {
        super.onStart();
        this.mapView.onStart();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        this.mapView.onResume();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        this.mapView.onPause();
        super.onPause();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStop() {
        this.mapView.onStop();
        super.onStop();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        this.mapView.onDestroy();
        this.executor.shutdown();
        super.onDestroy();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        this.mapView.onLowMemory();
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }
        this.mapView.onSaveInstanceState(mapViewBundle);
    }
}
