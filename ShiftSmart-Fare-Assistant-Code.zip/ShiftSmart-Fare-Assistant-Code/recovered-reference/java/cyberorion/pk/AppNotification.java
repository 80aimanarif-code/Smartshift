package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class AppNotification {
    public static final String TYPE_GENERAL = "general";
    public static final String TYPE_NEGOTIATION = "negotiation";
    public static final String TYPE_SOS = "sos";
    public static final String TYPE_STATUS = "status";
    public String bookingId;
    public String message;
    public String notificationId;
    public boolean read;
    public long timestamp;
    public String title;
    public String type;
    public String userId;

    public AppNotification() {
    }

    public AppNotification(String userId, String title, String message, String type, String bookingId) {
        this.userId = userId;
        this.title = title;
        this.message = message;
        this.type = type;
        this.bookingId = bookingId;
        this.read = false;
        this.timestamp = System.currentTimeMillis();
    }
}
