package cyberorion.pk;

import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class NotificationsActivity extends AppCompatActivity {
    private NotificationAdapter adapter;
    private View emptyState;
    private DatabaseReference notifRef;
    private final List<AppNotification> notifications = new ArrayList();
    private RecyclerView rvNotifications;
    private SwipeRefreshLayout swipeRefresh;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.NotificationsActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m436lambda$onCreate$0$cyberorionpkNotificationsActivity(view);
            }
        });
        this.rvNotifications = (RecyclerView) findViewById(R.id.rvNotifications);
        this.emptyState = findViewById(R.id.emptyNotifState);
        this.rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        this.adapter = new NotificationAdapter(this.notifications, new NotificationAdapter.OnNotificationClickListener() { // from class: cyberorion.pk.NotificationsActivity$$ExternalSyntheticLambda1
            @Override // cyberorion.pk.NotificationAdapter.OnNotificationClickListener
            public final void onClick(AppNotification appNotification) {
                this.f$0.onNotificationClick(appNotification);
            }
        });
        this.rvNotifications.setAdapter(this.adapter);
        this.swipeRefresh = (SwipeRefreshLayout) findViewById(R.id.swipeNotifications);
        this.swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() { // from class: cyberorion.pk.NotificationsActivity$$ExternalSyntheticLambda2
            @Override // androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
            public final void onRefresh() {
                this.f$0.m437lambda$onCreate$1$cyberorionpkNotificationsActivity();
            }
        });
        String uid = FirebaseAuth.getInstance().getCurrentUser() != null ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        if (uid == null) {
            this.emptyState.setVisibility(0);
        } else {
            this.notifRef = FirebaseDatabase.getInstance().getReference().child("notifications").child(uid);
            this.notifRef.addValueEventListener(new AnonymousClass1());
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-NotificationsActivity, reason: not valid java name */
    /* synthetic */ void m436lambda$onCreate$0$cyberorionpkNotificationsActivity(View v) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-NotificationsActivity, reason: not valid java name */
    /* synthetic */ void m437lambda$onCreate$1$cyberorionpkNotificationsActivity() {
        this.swipeRefresh.setRefreshing(false);
    }

    /* JADX INFO: renamed from: cyberorion.pk.NotificationsActivity$1, reason: invalid class name */
    class AnonymousClass1 implements ValueEventListener {
        AnonymousClass1() {
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onDataChange(DataSnapshot snapshot) {
            NotificationsActivity.this.notifications.clear();
            for (DataSnapshot child : snapshot.getChildren()) {
                AppNotification n = (AppNotification) child.getValue(AppNotification.class);
                if (n != null) {
                    n.notificationId = child.getKey();
                    NotificationsActivity.this.notifications.add(n);
                }
            }
            Collections.sort(NotificationsActivity.this.notifications, new Comparator() { // from class: cyberorion.pk.NotificationsActivity$1$$ExternalSyntheticLambda0
                @Override // java.util.Comparator
                public final int compare(Object obj, Object obj2) {
                    return Long.compare(((AppNotification) obj2).timestamp, ((AppNotification) obj).timestamp);
                }
            });
            NotificationsActivity.this.adapter.notifyDataSetChanged();
            NotificationsActivity.this.emptyState.setVisibility(NotificationsActivity.this.notifications.isEmpty() ? 0 : 8);
            NotificationsActivity.this.rvNotifications.setVisibility(NotificationsActivity.this.notifications.isEmpty() ? 8 : 0);
        }

        @Override // com.google.firebase.database.ValueEventListener
        public void onCancelled(DatabaseError error) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onNotificationClick(AppNotification notification) {
        if (this.notifRef != null && notification.notificationId != null && !notification.read) {
            this.notifRef.child(notification.notificationId).child("read").setValue(true);
        }
    }
}
