package cyberorion.pk;

import android.view.View;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/* JADX INFO: loaded from: classes3.dex */
public final class NotificationHelper {
    private NotificationHelper() {
    }

    public static void notify(String userId, String title, String message, String type, String bookingId) {
        if (userId != null && !userId.isEmpty()) {
            AppNotification notification = new AppNotification(userId, title, message, type, bookingId);
            FirebaseDatabase.getInstance().getReference().child("notifications").child(userId).push().setValue(notification);
        }
    }

    public static void notifyStatusChange(String userId, Booking booking, BookingStatus newStatus) {
        if (userId == null || booking == null) {
            return;
        }
        String route = (booking.pickup != null ? booking.pickup : "Pickup") + " → " + (booking.dropoff != null ? booking.dropoff : "Drop-off");
        notify(userId, newStatus.label, route + ": " + newStatus.customerMessage, "status", booking.bookingId);
    }

    public static void attachUnreadBadge(String userId, final View badgeView) {
        if (userId == null || userId.isEmpty() || badgeView == null) {
            return;
        }
        FirebaseDatabase.getInstance().getReference().child("notifications").child(userId).addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.NotificationHelper.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                boolean hasUnread = false;
                for (DataSnapshot child : snapshot.getChildren()) {
                    AppNotification n = (AppNotification) child.getValue(AppNotification.class);
                    if (n != null && !n.read) {
                        hasUnread = true;
                        break;
                    }
                }
                badgeView.setVisibility(hasUnread ? 0 : 8);
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }
}
