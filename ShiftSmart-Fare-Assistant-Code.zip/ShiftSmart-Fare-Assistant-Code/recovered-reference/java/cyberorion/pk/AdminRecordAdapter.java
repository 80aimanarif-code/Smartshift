package cyberorion.pk;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class AdminRecordAdapter extends RecyclerView.Adapter<Holder> {
    private final Listener listener;
    private final List<Record> rows;

    public interface Listener {
        void onAction(Record record, int i);
    }

    public static class Record {
        public String id;
        public Object payload;
        public String photoData;
        public String primary;
        public String secondary;
        public String status;
        public String subtitle;
        public String tertiary;
        public String title;

        public Record(String id, String title, String subtitle, String status) {
            this.id = id;
            this.title = title;
            this.subtitle = subtitle;
            this.status = status;
        }
    }

    public AdminRecordAdapter(List<Record> rows, Listener l) {
        this.rows = rows;
        this.listener = l;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_record, parent, false);
        return new Holder(v);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(Holder h, int position) {
        Record r = this.rows.get(position);
        h.title.setText(r.title);
        h.subtitle.setText(r.subtitle);
        h.status.setText(r.status);
        bindStatusColor(h, r.status);
        bindAvatar(h, r);
        bind(h.primary, r.primary, r, 1);
        bind(h.secondary, r.secondary, r, 2);
        bind(h.tertiary, r.tertiary, r, 3);
    }

    private void bindAvatar(Holder h, Record r) {
        boolean hasPhoto = false;
        if (r.photoData != null && !r.photoData.isEmpty()) {
            try {
                byte[] bytes = Base64.decode(r.photoData, 0);
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bmp != null) {
                    h.avatarPhoto.setImageBitmap(bmp);
                    hasPhoto = true;
                }
            } catch (Exception e) {
            }
        }
        h.avatarPhoto.setVisibility(hasPhoto ? 0 : 8);
        h.avatarInitial.setVisibility(hasPhoto ? 8 : 0);
        if (!hasPhoto) {
            String title = r.title == null ? "" : r.title.trim();
            h.avatarInitial.setText(title.isEmpty() ? "?" : title.substring(0, 1).toUpperCase(Locale.ROOT));
        }
    }

    private void bindStatusColor(Holder h, String status) {
        int bg;
        int fg;
        String s = status == null ? "" : status.toUpperCase(Locale.ROOT);
        Context c = h.itemView.getContext();
        if (s.contains("DISABLED") || s.contains("REJECTED")) {
            bg = R.drawable.bg_status_pill_error;
            fg = c.getColor(R.color.errorColor);
        } else if (s.contains("PENDING")) {
            bg = R.drawable.bg_notice_warning;
            fg = c.getColor(R.color.black);
        } else {
            bg = R.drawable.bg_status_pill;
            fg = c.getColor(R.color.successColor);
        }
        h.status.setBackgroundResource(bg);
        h.status.setTextColor(fg);
    }

    private void bind(MaterialButton b, String label, final Record r, final int action) {
        if (label == null || label.isEmpty()) {
            b.setVisibility(8);
            return;
        }
        b.setVisibility(0);
        b.setText(label);
        b.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminRecordAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m292lambda$bind$0$cyberorionpkAdminRecordAdapter(r, action, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$bind$0$cyberorion-pk-AdminRecordAdapter, reason: not valid java name */
    /* synthetic */ void m292lambda$bind$0$cyberorionpkAdminRecordAdapter(Record r, int action, View v) {
        this.listener.onAction(r, action);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.rows.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView avatarInitial;
        ImageView avatarPhoto;
        MaterialButton primary;
        MaterialButton secondary;
        TextView status;
        TextView subtitle;
        MaterialButton tertiary;
        TextView title;

        Holder(View v) {
            super(v);
            this.title = (TextView) v.findViewById(R.id.tvRecordTitle);
            this.subtitle = (TextView) v.findViewById(R.id.tvRecordSubtitle);
            this.status = (TextView) v.findViewById(R.id.tvRecordStatus);
            this.avatarInitial = (TextView) v.findViewById(R.id.tvRecordAvatarInitial);
            this.avatarPhoto = (ImageView) v.findViewById(R.id.ivRecordAvatarPhoto);
            this.primary = (MaterialButton) v.findViewById(R.id.btnRecordPrimary);
            this.secondary = (MaterialButton) v.findViewById(R.id.btnRecordSecondary);
            this.tertiary = (MaterialButton) v.findViewById(R.id.btnRecordTertiary);
        }
    }
}
