package cyberorion.pk;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.DateFormat;
import java.util.Date;

/* JADX INFO: loaded from: classes3.dex */
public class DamageComparisonActivity extends AppCompatActivity {
    private String bookingId;
    private ImageView ivAfter;
    private ImageView ivBefore;
    private TextView tvAfterCondition;
    private TextView tvAfterNotes;
    private TextView tvAfterTime;
    private TextView tvBeforeCondition;
    private TextView tvBeforeNotes;
    private TextView tvBeforeTime;
    private TextView tvRisk;
    private TextView tvRiskReason;

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DamageComparisonActivity, reason: not valid java name */
    /* synthetic */ void m331lambda$onCreate$0$cyberorionpkDamageComparisonActivity(View v) {
        finish();
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_damage_comparison);
        this.bookingId = getIntent().getStringExtra(BookingKeys.EXTRA_BOOKING_ID);
        if (this.bookingId == null) {
            finish();
            return;
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageComparisonActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m331lambda$onCreate$0$cyberorionpkDamageComparisonActivity(view);
            }
        });
        this.tvRisk = (TextView) findViewById(R.id.tvDamageRisk);
        this.tvRiskReason = (TextView) findViewById(R.id.tvDamageRiskReason);
        this.tvBeforeCondition = (TextView) findViewById(R.id.tvBeforeCondition);
        this.tvBeforeNotes = (TextView) findViewById(R.id.tvBeforeNotes);
        this.tvBeforeTime = (TextView) findViewById(R.id.tvBeforeTime);
        this.tvAfterCondition = (TextView) findViewById(R.id.tvAfterCondition);
        this.tvAfterNotes = (TextView) findViewById(R.id.tvAfterNotes);
        this.tvAfterTime = (TextView) findViewById(R.id.tvAfterTime);
        this.ivBefore = (ImageView) findViewById(R.id.ivBefore);
        this.ivAfter = (ImageView) findViewById(R.id.ivAfter);
        load();
    }

    private void load() {
        FirebaseDatabase.getInstance().getReference("bookings").child(this.bookingId).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.DamageComparisonActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
                Toast.makeText(DamageComparisonActivity.this, e.getMessage(), 0).show();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                Booking booking = (Booking) s.getValue(Booking.class);
                DamageRiskAssessment r = DamageRiskScorer.assess(booking);
                DamageComparisonActivity.this.tvRisk.setText("Damage Risk: " + r.level + " (" + r.score + "/100)");
                DamageComparisonActivity.this.tvRiskReason.setText(r.reason + "\nRecommendation: " + r.recommendation);
                DamageComparisonActivity.this.render((DamageReport) s.child("damageReports").child(DamageReport.STAGE_PICKUP).getValue(DamageReport.class), true);
                DamageComparisonActivity.this.render((DamageReport) s.child("damageReports").child(DamageReport.STAGE_DELIVERY).getValue(DamageReport.class), false);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void render(DamageReport r, boolean before) {
        TextView cond = before ? this.tvBeforeCondition : this.tvAfterCondition;
        TextView notes = before ? this.tvBeforeNotes : this.tvAfterNotes;
        TextView time = before ? this.tvBeforeTime : this.tvAfterTime;
        ImageView image = before ? this.ivBefore : this.ivAfter;
        if (r == null) {
            cond.setText("Not recorded");
            notes.setText("No condition report yet");
            time.setText("");
            image.setVisibility(8);
            return;
        }
        cond.setText(DamageReport.CONDITION_DAMAGED.equals(r.condition) ? "Damage noted" : "Good condition");
        notes.setText((r.notes == null || r.notes.isEmpty()) ? "No notes" : r.notes);
        time.setText(DateFormat.getDateTimeInstance().format(new Date(r.timestamp)));
        if (r.photoUris == null || r.photoUris.isEmpty()) {
            image.setVisibility(8);
            return;
        }
        String first = r.photoUris.split(",")[0];
        try {
            image.setImageURI(Uri.parse(first));
            image.setVisibility(0);
        } catch (Exception e) {
            image.setVisibility(8);
        }
    }
}
