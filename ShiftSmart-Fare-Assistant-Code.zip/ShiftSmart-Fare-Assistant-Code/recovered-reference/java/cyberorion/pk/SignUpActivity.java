package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/* JADX INFO: loaded from: classes3.dex */
public class SignUpActivity extends AppCompatActivity {
    private Button btnSignUp;
    private TextInputEditText etEmail;
    private TextInputEditText etName;
    private TextInputEditText etPassword;
    private TextInputEditText etPhone;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private ProgressBar progressBar;
    private TextView tvLogin;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1768638687895-b5ee4a586c7f", getResources().getDisplayMetrics().widthPixels);
        this.mAuth = FirebaseAuth.getInstance();
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
        this.etName = (TextInputEditText) findViewById(R.id.etName);
        this.etEmail = (TextInputEditText) findViewById(R.id.etEmail);
        this.etPhone = (TextInputEditText) findViewById(R.id.etPhone);
        this.etPassword = (TextInputEditText) findViewById(R.id.etPassword);
        this.btnSignUp = (Button) findViewById(R.id.btnSignUp);
        this.tvLogin = (TextView) findViewById(R.id.tvLogin);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.btnSignUp.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.SignUpActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m454lambda$onCreate$0$cyberorionpkSignUpActivity(view);
            }
        });
        this.tvLogin.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.SignUpActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m455lambda$onCreate$1$cyberorionpkSignUpActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-SignUpActivity, reason: not valid java name */
    /* synthetic */ void m454lambda$onCreate$0$cyberorionpkSignUpActivity(View v) {
        registerUser();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-SignUpActivity, reason: not valid java name */
    /* synthetic */ void m455lambda$onCreate$1$cyberorionpkSignUpActivity(View v) {
        finish();
    }

    private void registerUser() {
        final String name = this.etName.getText().toString().trim();
        final String email = this.etEmail.getText().toString().trim();
        final String phone = this.etPhone.getText().toString().trim();
        String password = this.etPassword.getText().toString().trim();
        if (TextUtils.isEmpty(name)) {
            this.etName.setError(getString(R.string.name_hint) + " is required");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            this.etEmail.setError(getString(R.string.email_hint) + " is required");
            return;
        }
        if (TextUtils.isEmpty(phone)) {
            this.etPhone.setError("Phone number is required");
        } else {
            if (TextUtils.isEmpty(password)) {
                this.etPassword.setError(getString(R.string.password_hint) + " is required");
                return;
            }
            this.progressBar.setVisibility(0);
            this.btnSignUp.setEnabled(false);
            this.mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.SignUpActivity$$ExternalSyntheticLambda2
                @Override // com.google.android.gms.tasks.OnCompleteListener
                public final void onComplete(Task task) {
                    this.f$0.m456lambda$registerUser$2$cyberorionpkSignUpActivity(name, email, phone, task);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$registerUser$2$cyberorion-pk-SignUpActivity, reason: not valid java name */
    /* synthetic */ void m456lambda$registerUser$2$cyberorionpkSignUpActivity(String name, String email, String phone, Task task) {
        this.progressBar.setVisibility(8);
        this.btnSignUp.setEnabled(true);
        if (task.isSuccessful()) {
            String userId = this.mAuth.getCurrentUser().getUid();
            User user = new User(name, email, phone);
            this.mDatabase.child("users").child(userId).setValue(user);
            Toast.makeText(this, "Account created successfully!", 0).show();
            Intent intent = new Intent(this, (Class<?>) MainActivity.class);
            intent.addFlags(268468224);
            startActivity(intent);
            finish();
            return;
        }
        Toast.makeText(this, "Sign up failed: " + task.getException().getMessage(), 1).show();
    }
}
