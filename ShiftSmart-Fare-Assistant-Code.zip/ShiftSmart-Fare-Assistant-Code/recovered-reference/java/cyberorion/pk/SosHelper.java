package cyberorion.pk;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public final class SosHelper {
    private SosHelper() {
    }

    public static void raise(Booking booking, String raisedByUid, String role, String message, Double lat, Double lng) {
        if (booking != null && booking.bookingId != null) {
            DatabaseReference root = FirebaseDatabase.getInstance().getReference();
            SosAlert alert = new SosAlert(booking.bookingId, raisedByUid, role, message, lat, lng);
            String alertId = root.child(AppNotification.TYPE_SOS).push().getKey();
            if (alertId == null) {
                return;
            }
            alert.alertId = alertId;
            root.child(AppNotification.TYPE_SOS).child(alertId).setValue(alert);
            root.child("bookings").child(booking.bookingId).child("hasActiveSos").setValue(true);
            String str = BookingKeys.ROLE_DRIVER;
            boolean raisedByDriver = BookingKeys.ROLE_DRIVER.equals(role);
            String notifyUserId = raisedByDriver ? booking.userId : booking.driverId;
            String route = (booking.pickup != null ? booking.pickup : "Pickup") + " → " + (booking.dropoff != null ? booking.dropoff : "Drop-off");
            StringBuilder sbAppend = new StringBuilder().append(route).append(": the ");
            if (!raisedByDriver) {
                str = BookingKeys.ROLE_CUSTOMER;
            }
            NotificationHelper.notify(notifyUserId, "Emergency SOS raised", sbAppend.append(str).append(" triggered an SOS alert.").toString(), AppNotification.TYPE_SOS, booking.bookingId);
        }
    }

    public static void resolve(final SosAlert alert, String resolvedByUid) {
        if (alert == null || alert.alertId == null) {
            return;
        }
        final DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        Map<String, Object> updates = new HashMap<>();
        updates.put("status", SosAlert.STATUS_RESOLVED);
        updates.put("resolvedBy", resolvedByUid);
        updates.put("resolvedAt", Long.valueOf(System.currentTimeMillis()));
        root.child(AppNotification.TYPE_SOS).child(alert.alertId).updateChildren(updates);
        if (alert.bookingId != null) {
            root.child(AppNotification.TYPE_SOS).orderByChild("bookingId").equalTo(alert.bookingId).get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.SosHelper$$ExternalSyntheticLambda0
                @Override // com.google.android.gms.tasks.OnSuccessListener
                public final void onSuccess(Object obj) {
                    SosHelper.lambda$resolve$0(alert, root, (DataSnapshot) obj);
                }
            });
        }
    }

    static /* synthetic */ void lambda$resolve$0(SosAlert alert, DatabaseReference root, DataSnapshot snapshot) {
        SosAlert other;
        boolean stillActive = false;
        for (DataSnapshot child : snapshot.getChildren()) {
            if (!alert.alertId.equals(child.getKey()) && (other = (SosAlert) child.getValue(SosAlert.class)) != null && SosAlert.STATUS_ACTIVE.equals(other.status)) {
                stillActive = true;
                break;
            }
        }
        if (!stillActive) {
            root.child("bookings").child(alert.bookingId).child("hasActiveSos").setValue(false);
        }
    }
}
