package cyberorion.pk;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public class CargoSelection implements Serializable {
    public double approxCapacityKg;
    public String cargoCategoryId;
    public String cargoCategoryName;
    public String dimensions;
    public boolean fragile;
    public boolean loadingRequired;
    public String routeType;
    public String shiftingTypeId;
    public String specialHandling;
    public boolean unloadingRequired;
    public double weightKg;
    public int quantity = 1;
    public int laborCount = 1;

    public static CargoSelection from(ShiftingType shiftingType, CargoCategory category) {
        CargoSelection selection = new CargoSelection();
        selection.shiftingTypeId = shiftingType.id;
        selection.cargoCategoryId = category.id;
        selection.cargoCategoryName = category.name;
        selection.fragile = category.fragile;
        selection.approxCapacityKg = category.approxCapacityKg;
        return selection;
    }

    public String summaryLine() {
        StringBuilder sb = new StringBuilder(this.cargoCategoryName != null ? this.cargoCategoryName : "Cargo");
        if (this.quantity > 1) {
            sb.append(" x").append(this.quantity);
        }
        if (this.weightKg > 0.0d) {
            sb.append(" • ~").append(formatWeight(this.weightKg));
        }
        if (this.fragile) {
            sb.append(" • Fragile");
        }
        return sb.toString();
    }

    private String formatWeight(double kg) {
        return kg == Math.floor(kg) ? ((long) kg) + "kg" : kg + "kg";
    }
}
