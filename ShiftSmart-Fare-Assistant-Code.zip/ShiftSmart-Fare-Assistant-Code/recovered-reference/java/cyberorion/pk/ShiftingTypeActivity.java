package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/* JADX INFO: loaded from: classes3.dex */
public class ShiftingTypeActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shifting_type);
        RecyclerView rvShiftingTypes = (RecyclerView) findViewById(R.id.rvShiftingTypes);
        rvShiftingTypes.setLayoutManager(new LinearLayoutManager(this));
        rvShiftingTypes.setAdapter(new ShiftingTypeAdapter(new ShiftingTypeAdapter.OnTypeSelectedListener() { // from class: cyberorion.pk.ShiftingTypeActivity$$ExternalSyntheticLambda0
            @Override // cyberorion.pk.ShiftingTypeAdapter.OnTypeSelectedListener
            public final void onTypeSelected(ShiftingType shiftingType) {
                this.f$0.goToCargoCategory(shiftingType);
            }
        }));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void goToCargoCategory(ShiftingType type) {
        Intent intent = new Intent(this, (Class<?>) CargoCategoryActivity.class);
        intent.putExtra(BookingKeys.EXTRA_SHIFTING_TYPE, type.id);
        startActivity(intent);
    }
}
