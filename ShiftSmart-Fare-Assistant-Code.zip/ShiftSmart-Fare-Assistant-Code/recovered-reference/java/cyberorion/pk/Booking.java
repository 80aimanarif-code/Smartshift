package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class Booking {
    public String bookingId;
    public String cargoCategoryId;
    public String cargoCategoryName;
    public String dimensions;
    public double distanceKm;
    public String driverId;
    public String driverName;
    public boolean driverTripCounted;
    public String dropoff;
    public Double dropoffLat;
    public Double dropoffLng;
    public int estimatedDurationMinutes;
    public double estimatedFare;
    public Double finalFare;
    public boolean fragile;
    public boolean hasActiveSos;
    public int laborCount;
    public boolean loadingRequired;
    public String luggageType;
    public Double negotiatedFare;
    public String nocReasons;
    public boolean nocRequired;
    public String nocUri;
    public String pickup;
    public Double pickupLat;
    public Double pickupLng;
    public int quantity;
    public String recommendedVehicleId;
    public String recommendedVehicleName;
    public String routeType;
    public String shiftingType;
    public String specialHandling;
    public String specialInstructions;
    public String status;
    public long timestamp;
    public boolean unloadingRequired;
    public long updatedAt;
    public String userId;
    public double vehicleCapacity;
    public String vehicleNumber;
    public String vehicleType;
    public double weightKg;

    public Booking() {
    }

    public Booking(String bookingId, String userId, String pickup, String dropoff, String luggageType, String vehicleType, String driverName, String status) {
        this.bookingId = bookingId;
        this.userId = userId;
        this.pickup = pickup;
        this.dropoff = dropoff;
        this.luggageType = luggageType;
        this.vehicleType = vehicleType;
        this.driverName = driverName;
        this.status = status;
    }
}
