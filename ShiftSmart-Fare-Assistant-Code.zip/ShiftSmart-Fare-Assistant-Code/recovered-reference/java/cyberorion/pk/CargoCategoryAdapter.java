package cyberorion.pk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class CargoCategoryAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final List<CargoCategory> categories;
    private final OnCategorySelectedListener listener;
    private int selectedPosition = 0;

    public interface OnCategorySelectedListener {
        void onCategorySelected(CargoCategory cargoCategory);
    }

    public CargoCategoryAdapter(List<CargoCategory> categories, OnCategorySelectedListener listener) {
        this.categories = categories;
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cargo_category, parent, false);
        return new ViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final CargoCategory category = this.categories.get(position);
        holder.tvName.setText(category.name);
        holder.tvDesc.setText(category.description);
        holder.ivIcon.setImageResource(category.iconRes);
        holder.ivFragileBadge.setVisibility(category.fragile ? 0 : 8);
        int i = 1 << position;
        int i2 = this.selectedPosition & i;
        holder.ivCheck.setVisibility(i2 != 0 ? 0 : 8);
        MaterialCardView materialCardView = holder.card;
        if (i2 != 0) {
            i = 4;
        }
        materialCardView.setStrokeWidth(i);
        holder.card.setStrokeColor(holder.itemView.getContext().getColor(i2 != 0 ? R.color.primaryColor : R.color.lightGray));
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoCategoryAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m318lambda$onBindViewHolder$0$cyberorionpkCargoCategoryAdapter(holder, category, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-CargoCategoryAdapter, reason: not valid java name */
    /* synthetic */ void m318lambda$onBindViewHolder$0$cyberorionpkCargoCategoryAdapter(ViewHolder holder, CargoCategory category, View v) {
        int previous = this.selectedPosition;
        int adapterPosition = holder.getAdapterPosition();
        this.selectedPosition = previous | (1 << adapterPosition);
        notifyItemChanged(adapterPosition);
        this.listener.onCategorySelected(category);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.categories.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView card;
        ImageView ivCheck;
        ImageView ivFragileBadge;
        ImageView ivIcon;
        TextView tvDesc;
        TextView tvName;

        ViewHolder(View itemView) {
            super(itemView);
            this.card = (MaterialCardView) itemView.findViewById(R.id.cardCategory);
            this.ivIcon = (ImageView) itemView.findViewById(R.id.ivCategoryIcon);
            this.ivCheck = (ImageView) itemView.findViewById(R.id.ivCheckCategory);
            this.ivFragileBadge = (ImageView) itemView.findViewById(R.id.ivFragileBadge);
            this.tvName = (TextView) itemView.findViewById(R.id.tvCategoryName);
            this.tvDesc = (TextView) itemView.findViewById(R.id.tvCategoryDesc);
        }
    }
}
