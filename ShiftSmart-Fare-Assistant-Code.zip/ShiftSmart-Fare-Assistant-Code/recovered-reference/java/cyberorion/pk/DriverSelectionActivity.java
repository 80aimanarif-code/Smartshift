package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.ServerValues;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class DriverSelectionActivity extends AppCompatActivity {
    private DriverAdapter adapter;
    private DatabaseReference bookingsRef;
    private Button btnNext;
    private CargoSelection cargoSelection;
    private double distanceKm;
    private final List<Driver> driverList = new ArrayList();
    private DatabaseReference driversRef;
    private String dropoff;
    private Double dropoffLat;
    private Double dropoffLng;
    private int estimatedDurationMin;
    private double estimatedFare;
    private boolean hasDistance;
    private String luggageType;
    private FirebaseAuth mAuth;
    private String pickup;
    private Double pickupLat;
    private Double pickupLng;
    private String recommendedVehicleId;
    private String recommendedVehicleName;
    private RecyclerView rvDrivers;
    private Driver selectedDriver;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_selection);
        Intent in = getIntent();
        this.pickup = in.getStringExtra(BookingKeys.EXTRA_PICKUP);
        this.dropoff = in.getStringExtra(BookingKeys.EXTRA_DROPOFF);
        this.luggageType = in.getStringExtra(BookingKeys.EXTRA_LUGGAGE_TYPE);
        this.cargoSelection = (CargoSelection) in.getSerializableExtra(BookingKeys.EXTRA_CARGO_SELECTION);
        this.hasDistance = in.hasExtra(BookingKeys.EXTRA_DISTANCE_KM);
        this.distanceKm = in.getDoubleExtra(BookingKeys.EXTRA_DISTANCE_KM, 0.0d);
        if (in.hasExtra(BookingKeys.EXTRA_PICKUP_LAT)) {
            this.pickupLat = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_PICKUP_LAT, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_PICKUP_LNG)) {
            this.pickupLng = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_PICKUP_LNG, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_DROPOFF_LAT)) {
            this.dropoffLat = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_DROPOFF_LAT, 0.0d));
        }
        if (in.hasExtra(BookingKeys.EXTRA_DROPOFF_LNG)) {
            this.dropoffLng = Double.valueOf(in.getDoubleExtra(BookingKeys.EXTRA_DROPOFF_LNG, 0.0d));
        }
        this.estimatedFare = in.getDoubleExtra(BookingKeys.EXTRA_ESTIMATED_FARE, 0.0d);
        this.estimatedDurationMin = in.getIntExtra(BookingKeys.EXTRA_ESTIMATED_DURATION_MIN, 0);
        this.recommendedVehicleId = in.getStringExtra(BookingKeys.EXTRA_RECOMMENDED_VEHICLE_ID);
        this.recommendedVehicleName = in.getStringExtra(BookingKeys.EXTRA_RECOMMENDED_VEHICLE_NAME);
        this.rvDrivers = (RecyclerView) findViewById(R.id.rvDrivers);
        this.rvDrivers.setLayoutManager(new LinearLayoutManager(this));
        this.adapter = new DriverAdapter(this.driverList, new DriverAdapter.OnDriverSelectedListener() { // from class: cyberorion.pk.DriverSelectionActivity$$ExternalSyntheticLambda1
            @Override // cyberorion.pk.DriverAdapter.OnDriverSelectedListener
            public final void onDriverSelected(Driver driver) {
                this.f$0.onDriverSelected(driver);
            }
        }, this.recommendedVehicleName);
        this.rvDrivers.setAdapter(this.adapter);
        this.btnNext = (Button) findViewById(R.id.btnNextDriver);
        this.btnNext.setEnabled(false);
        this.btnNext.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverSelectionActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m386lambda$onCreate$0$cyberorionpkDriverSelectionActivity(view);
            }
        });
        this.mAuth = FirebaseAuth.getInstance();
        this.driversRef = FirebaseDatabase.getInstance().getReference().child("drivers");
        this.bookingsRef = FirebaseDatabase.getInstance().getReference().child("bookings");
        loadDrivers();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DriverSelectionActivity, reason: not valid java name */
    /* synthetic */ void m386lambda$onCreate$0$cyberorionpkDriverSelectionActivity(View v) {
        createBookingAndContinue();
    }

    private void loadDrivers() {
        this.driversRef.addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.DriverSelectionActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists() && snapshot.getChildrenCount() > 0) {
                    DriverSelectionActivity.this.populateFromSnapshot(snapshot);
                } else {
                    DriverSelectionActivity.this.seedDemoDrivers();
                }
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
                Toast.makeText(DriverSelectionActivity.this, "Could not load drivers: " + error.getMessage(), 0).show();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void populateFromSnapshot(DataSnapshot snapshot) {
        List<Driver> candidates = new ArrayList<>();
        for (DataSnapshot child : snapshot.getChildren()) {
            Driver driver = (Driver) child.getValue(Driver.class);
            if (driver != null) {
                driver.driverId = child.getKey();
                candidates.add(driver);
            }
        }
        double requiredWeight = this.cargoSelection != null ? this.cargoSelection.weightKg : 0.0d;
        this.driverList.clear();
        this.driverList.addAll(DriverMatcher.rank(candidates, requiredWeight, this.recommendedVehicleName, this.pickupLat, this.pickupLng));
        this.adapter.notifyDataSetChanged();
        if (this.driverList.isEmpty()) {
            Toast.makeText(this, "No approved drivers match this request right now", 1).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void seedDemoDrivers() {
        List<Driver> demoDrivers = new ArrayList<>();
        demoDrivers.add(new Driver("demo1", "Ahmed Raza", "Mini Van", "LEA-2031", 800.0d, 4.8f, true));
        demoDrivers.add(new Driver("demo2", "Bilal Hussain", "Mazda Truck", "KHI-7710", 4000.0d, 4.6f, true));
        demoDrivers.add(new Driver("demo3", "Sana Tariq", "Suzuki Pickup", "ISB-4420", 400.0d, 4.9f, true));
        demoDrivers.add(new Driver("demo4", "Usman Khalid", "Shehzore", "LHR-9081", 1500.0d, 4.5f, true));
        demoDrivers.add(new Driver("demo5", "Fahad Iqbal", "Container Truck", "MUL-5541", 10000.0d, 4.7f, true));
        for (Driver driver : demoDrivers) {
            this.driversRef.child(driver.driverId).setValue(driver);
        }
        this.driverList.clear();
        this.driverList.addAll(DriverMatcher.rank(demoDrivers, this.cargoSelection != null ? this.cargoSelection.weightKg : 0.0d, this.recommendedVehicleName, this.pickupLat, this.pickupLng));
        this.adapter.notifyDataSetChanged();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onDriverSelected(Driver driver) {
        this.selectedDriver = driver;
        this.btnNext.setEnabled(true);
    }

    private void createBookingAndContinue() {
        if (this.selectedDriver == null) {
            return;
        }
        this.btnNext.setEnabled(false);
        String userId = this.mAuth.getCurrentUser() != null ? this.mAuth.getCurrentUser().getUid() : "anonymous";
        final String bookingId = this.bookingsRef.push().getKey();
        if (bookingId == null) {
            this.btnNext.setEnabled(true);
            Toast.makeText(this, "Could not create booking. Try again.", 0).show();
            return;
        }
        NocPolicy.NocRequirement nocRequirement = NocPolicy.evaluate(this.cargoSelection, this.hasDistance ? Double.valueOf(this.distanceKm) : null);
        Map<String, Object> bookingData = new HashMap<>();
        bookingData.put("userId", userId);
        bookingData.put(DamageReport.STAGE_PICKUP, this.pickup);
        bookingData.put("dropoff", this.dropoff);
        bookingData.put("luggageType", this.luggageType);
        bookingData.put("driverId", this.selectedDriver.driverId);
        bookingData.put("driverName", this.selectedDriver.name);
        bookingData.put("vehicleType", this.selectedDriver.vehicleType);
        bookingData.put("vehicleNumber", this.selectedDriver.vehicleNumber);
        bookingData.put("vehicleCapacity", Double.valueOf(this.selectedDriver.capacity));
        if (this.hasDistance) {
            bookingData.put("distanceKm", Double.valueOf(this.distanceKm));
        }
        if (this.pickupLat != null) {
            bookingData.put("pickupLat", this.pickupLat);
        }
        if (this.pickupLng != null) {
            bookingData.put("pickupLng", this.pickupLng);
        }
        if (this.dropoffLat != null) {
            bookingData.put("dropoffLat", this.dropoffLat);
        }
        if (this.dropoffLng != null) {
            bookingData.put("dropoffLng", this.dropoffLng);
        }
        bookingData.put("estimatedFare", Double.valueOf(this.estimatedFare));
        bookingData.put("estimatedDurationMinutes", Integer.valueOf(this.estimatedDurationMin));
        bookingData.put("recommendedVehicleId", this.recommendedVehicleId);
        bookingData.put("recommendedVehicleName", this.recommendedVehicleName);
        bookingData.put("nocRequired", Boolean.valueOf(nocRequirement.required));
        bookingData.put("nocReasons", nocRequirement.reasonSummary());
        bookingData.put("status", BookingStatus.PENDING.label);
        bookingData.put(ServerValues.NAME_OP_TIMESTAMP, Long.valueOf(System.currentTimeMillis()));
        bookingData.put("updatedAt", Long.valueOf(System.currentTimeMillis()));
        if (this.cargoSelection != null) {
            bookingData.put("shiftingType", this.cargoSelection.shiftingTypeId);
            bookingData.put("cargoCategoryId", this.cargoSelection.cargoCategoryId);
            bookingData.put("cargoCategoryName", this.cargoSelection.cargoCategoryName);
            bookingData.put("fragile", Boolean.valueOf(this.cargoSelection.fragile));
            bookingData.put("quantity", Integer.valueOf(this.cargoSelection.quantity));
            bookingData.put("weightKg", Double.valueOf(this.cargoSelection.weightKg));
            bookingData.put("dimensions", this.cargoSelection.dimensions);
            bookingData.put("specialHandling", this.cargoSelection.specialHandling);
            bookingData.put("routeType", this.cargoSelection.routeType);
            bookingData.put("loadingRequired", Boolean.valueOf(this.cargoSelection.loadingRequired));
            bookingData.put("unloadingRequired", Boolean.valueOf(this.cargoSelection.unloadingRequired));
            bookingData.put("laborCount", Integer.valueOf(this.cargoSelection.laborCount));
        }
        this.bookingsRef.child(bookingId).setValue(bookingData).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.DriverSelectionActivity$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m385x6aab5869(bookingId, task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$createBookingAndContinue$1$cyberorion-pk-DriverSelectionActivity, reason: not valid java name */
    /* synthetic */ void m385x6aab5869(String bookingId, Task task) {
        this.btnNext.setEnabled(true);
        if (task.isSuccessful()) {
            goToBookingReview(bookingId);
        } else {
            Toast.makeText(this, "Could not create booking. Try again.", 0).show();
        }
    }

    private void goToBookingReview(String bookingId) {
        Intent intent = new Intent(this, (Class<?>) BookingReviewActivity.class);
        intent.putExtra(BookingKeys.EXTRA_BOOKING_ID, bookingId);
        intent.putExtra(BookingKeys.EXTRA_PICKUP, this.pickup);
        intent.putExtra(BookingKeys.EXTRA_DROPOFF, this.dropoff);
        intent.putExtra(BookingKeys.EXTRA_LUGGAGE_TYPE, this.luggageType);
        intent.putExtra(BookingKeys.EXTRA_CARGO_SELECTION, this.cargoSelection);
        if (this.hasDistance) {
            intent.putExtra(BookingKeys.EXTRA_DISTANCE_KM, this.distanceKm);
        }
        intent.putExtra(BookingKeys.EXTRA_DRIVER_ID, this.selectedDriver.driverId);
        intent.putExtra(BookingKeys.EXTRA_DRIVER_NAME, this.selectedDriver.name);
        intent.putExtra(BookingKeys.EXTRA_VEHICLE_TYPE, this.selectedDriver.vehicleType);
        intent.putExtra(BookingKeys.EXTRA_VEHICLE_NUMBER, this.selectedDriver.vehicleNumber);
        intent.putExtra(BookingKeys.EXTRA_VEHICLE_CAPACITY, this.selectedDriver.capacity);
        intent.putExtra(BookingKeys.EXTRA_ESTIMATED_FARE, this.estimatedFare);
        intent.putExtra(BookingKeys.EXTRA_ESTIMATED_DURATION_MIN, this.estimatedDurationMin);
        startActivity(intent);
    }
}
