package cyberorion.pk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class AdminBookingAdapter extends RecyclerView.Adapter<ViewHolder> {
    private final List<Booking> bookings;
    private final OnBookingClickListener listener;

    public interface OnBookingClickListener {
        void onClick(Booking booking);
    }

    public AdminBookingAdapter(List<Booking> bookings, OnBookingClickListener listener) {
        this.bookings = bookings;
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_admin_booking, parent, false);
        return new ViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(ViewHolder holder, int position) {
        double displayFare;
        final Booking booking = this.bookings.get(position);
        BookingStatus status = BookingStatus.fromLabel(booking.status);
        holder.tvRoute.setText(String.format("%s → %s", booking.pickup, booking.dropoff));
        String driverPart = (booking.driverName == null || booking.driverName.isEmpty()) ? "No driver yet" : booking.driverName;
        holder.tvMeta.setText(String.format(Locale.getDefault(), "Driver: %s • %.1f km", driverPart, Double.valueOf(booking.distanceKm)));
        if (booking.finalFare != null) {
            displayFare = booking.finalFare.doubleValue();
        } else {
            displayFare = booking.negotiatedFare != null ? booking.negotiatedFare.doubleValue() : booking.estimatedFare;
        }
        holder.tvFare.setText(holder.itemView.getContext().getString(R.string.fare_amount_format, Double.valueOf(displayFare)));
        holder.tvStatus.setText(status.label);
        holder.tvStatus.setBackgroundResource((!status.isFinal() || status == BookingStatus.DELIVERED || status == BookingStatus.COMPLETED) ? R.drawable.bg_status_pill : R.drawable.bg_status_pill_error);
        holder.tvStatus.setTextColor(holder.itemView.getContext().getColor((!status.isFinal() || status == BookingStatus.DELIVERED || status == BookingStatus.COMPLETED) ? R.color.successColor : R.color.errorColor));
        holder.tvSosBadge.setVisibility(booking.hasActiveSos ? 0 : 8);
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminBookingAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m272lambda$onBindViewHolder$0$cyberorionpkAdminBookingAdapter(booking, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-AdminBookingAdapter, reason: not valid java name */
    /* synthetic */ void m272lambda$onBindViewHolder$0$cyberorionpkAdminBookingAdapter(Booking booking, View v) {
        this.listener.onClick(booking);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.bookings.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFare;
        TextView tvMeta;
        TextView tvRoute;
        TextView tvSosBadge;
        TextView tvStatus;

        ViewHolder(View itemView) {
            super(itemView);
            this.tvRoute = (TextView) itemView.findViewById(R.id.tvAdminBookingRoute);
            this.tvMeta = (TextView) itemView.findViewById(R.id.tvAdminBookingMeta);
            this.tvFare = (TextView) itemView.findViewById(R.id.tvAdminBookingFare);
            this.tvStatus = (TextView) itemView.findViewById(R.id.tvAdminBookingStatus);
            this.tvSosBadge = (TextView) itemView.findViewById(R.id.tvAdminBookingSosBadge);
        }
    }
}
