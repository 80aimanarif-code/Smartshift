package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class CargoCategoryActivity extends AppCompatActivity {
    private Button btnNext;
    private CargoCategory selectedCategory;
    private ShiftingType shiftingType;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cargo_category);
        String shiftingTypeId = getIntent().getStringExtra(BookingKeys.EXTRA_SHIFTING_TYPE);
        this.shiftingType = ShiftingType.fromId(shiftingTypeId);
        List<CargoCategory> categories = CargoCatalog.forGroup(this.shiftingType.group);
        RecyclerView rvCategories = (RecyclerView) findViewById(R.id.rvCategories);
        rvCategories.setLayoutManager(new GridLayoutManager(this, 2));
        rvCategories.setAdapter(new CargoCategoryAdapter(categories, new CargoCategoryAdapter.OnCategorySelectedListener() { // from class: cyberorion.pk.CargoCategoryActivity$$ExternalSyntheticLambda0
            @Override // cyberorion.pk.CargoCategoryAdapter.OnCategorySelectedListener
            public final void onCategorySelected(CargoCategory cargoCategory) {
                this.f$0.onCategorySelected(cargoCategory);
            }
        }));
        this.btnNext = (Button) findViewById(R.id.btnNextCategory);
        this.btnNext.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.CargoCategoryActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m317lambda$onCreate$0$cyberorionpkCargoCategoryActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-CargoCategoryActivity, reason: not valid java name */
    /* synthetic */ void m317lambda$onCreate$0$cyberorionpkCargoCategoryActivity(View v) {
        goToCargoDetails();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void onCategorySelected(CargoCategory category) {
        this.selectedCategory = category;
        this.btnNext.setEnabled(true);
    }

    private void goToCargoDetails() {
        if (this.selectedCategory == null) {
            return;
        }
        CargoSelection selection = CargoSelection.from(this.shiftingType, this.selectedCategory);
        Intent intent = new Intent(this, (Class<?>) CargoDetailsActivity.class);
        intent.putExtra(BookingKeys.EXTRA_CARGO_SELECTION, selection);
        startActivity(intent);
    }
}
