package cyberorion.pk;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class UserManagementActivity extends AppCompatActivity implements AdminRecordAdapter.Listener {
    private AdminRecordAdapter adapter;
    private DatabaseReference ref;
    private final List<AdminRecordAdapter.Record> rows = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (AdminAccountManager.requireAdminAccess(this)) {
            RecyclerView rv = AdminListUi.setup(this, "User Management", this.rows, this);
            this.adapter = (AdminRecordAdapter) rv.getAdapter();
            this.ref = FirebaseDatabase.getInstance().getReference("users");
            listen();
        }
    }

    private void listen() {
        this.ref.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.UserManagementActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                UserManagementActivity.this.rows.clear();
                for (DataSnapshot c : s.getChildren()) {
                    User u = (User) c.getValue(User.class);
                    if (u != null) {
                        StringBuilder credentials = new StringBuilder();
                        String str = "—";
                        credentials.append("Email: ").append((u.email == null || u.email.isEmpty()) ? "—" : u.email);
                        StringBuilder sbAppend = credentials.append("\nPhone: ");
                        if (u.phone != null && !u.phone.isEmpty()) {
                            str = u.phone;
                        }
                        sbAppend.append(str);
                        AdminRecordAdapter.Record r = new AdminRecordAdapter.Record(c.getKey(), (u.name == null || u.name.isEmpty()) ? "User" : u.name, credentials.toString(), u.disabled ? "DISABLED" : "ACTIVE");
                        r.primary = u.disabled ? "Enable" : "Disable";
                        r.payload = u;
                        UserManagementActivity.this.rows.add(r);
                    }
                }
                UserManagementActivity.this.adapter.notifyDataSetChanged();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
                Toast.makeText(UserManagementActivity.this, e.getMessage(), 0).show();
            }
        });
    }

    @Override // cyberorion.pk.AdminRecordAdapter.Listener
    public void onAction(AdminRecordAdapter.Record r, int action) {
        User u = (User) r.payload;
        this.ref.child(r.id).child("disabled").setValue(Boolean.valueOf(!u.disabled));
    }
}
