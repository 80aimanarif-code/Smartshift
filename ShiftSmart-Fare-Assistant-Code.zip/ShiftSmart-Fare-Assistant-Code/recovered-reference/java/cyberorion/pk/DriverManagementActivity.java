package cyberorion.pk;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class DriverManagementActivity extends AppCompatActivity implements AdminRecordAdapter.Listener {
    private AdminRecordAdapter adapter;
    private DatabaseReference ref;
    private final List<AdminRecordAdapter.Record> rows = new ArrayList();

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (AdminAccountManager.requireAdminAccess(this)) {
            RecyclerView rv = AdminListUi.setup(this, "Driver Management", this.rows, this);
            this.adapter = (AdminRecordAdapter) rv.getAdapter();
            this.ref = FirebaseDatabase.getInstance().getReference("drivers");
            listen();
        }
    }

    private void listen() {
        this.ref.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.DriverManagementActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot s) {
                String status;
                DriverManagementActivity.this.rows.clear();
                for (DataSnapshot c : s.getChildren()) {
                    Driver d = (Driver) c.getValue(Driver.class);
                    if (d != null) {
                        d.driverId = c.getKey();
                        if (d.disabled) {
                            status = "DISABLED";
                        } else {
                            status = d.approvalStatus == null ? "LEGACY APPROVED" : d.approvalStatus.toUpperCase(Locale.ROOT);
                        }
                        StringBuilder credentials = new StringBuilder();
                        credentials.append("Email: ").append((d.email == null || d.email.isEmpty()) ? "—" : d.email);
                        credentials.append("\n").append(d.vehicleType == null ? "" : d.vehicleType).append(" • ").append(d.vehicleNumber != null ? d.vehicleNumber : "");
                        credentials.append(String.format(Locale.getDefault(), "\n%.1f★ • %d trips • %d yrs experience", Float.valueOf(d.rating), Integer.valueOf(d.completedTrips), Integer.valueOf(d.experienceYears)));
                        AdminRecordAdapter.Record r = new AdminRecordAdapter.Record(c.getKey(), (d.name == null || d.name.isEmpty()) ? "Driver" : d.name, credentials.toString(), status);
                        r.primary = "Approve";
                        r.secondary = "Reject";
                        r.tertiary = d.disabled ? "Enable" : "Disable";
                        r.photoData = d.photoData;
                        r.payload = d;
                        DriverManagementActivity.this.rows.add(r);
                    }
                }
                DriverManagementActivity.this.adapter.notifyDataSetChanged();
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError e) {
                Toast.makeText(DriverManagementActivity.this, e.getMessage(), 0).show();
            }
        });
    }

    @Override // cyberorion.pk.AdminRecordAdapter.Listener
    public void onAction(AdminRecordAdapter.Record r, int action) {
        Map<String, Object> u = new HashMap<>();
        Driver d = (Driver) r.payload;
        if (action == 1) {
            u.put(Driver.STATUS_APPROVED, true);
            u.put("approvalStatus", Driver.STATUS_APPROVED);
            u.put("available", true);
        } else if (action == 2) {
            u.put(Driver.STATUS_APPROVED, false);
            u.put("approvalStatus", Driver.STATUS_REJECTED);
            u.put("available", false);
        } else {
            u.put("disabled", Boolean.valueOf(!d.disabled));
            if (!d.disabled) {
                u.put("available", false);
            }
        }
        this.ref.child(r.id).updateChildren(u);
    }
}
