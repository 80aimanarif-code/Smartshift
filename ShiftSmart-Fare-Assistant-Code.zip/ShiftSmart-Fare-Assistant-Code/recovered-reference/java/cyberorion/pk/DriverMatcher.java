package cyberorion.pk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;

/* JADX INFO: loaded from: classes3.dex */
public final class DriverMatcher {
    private DriverMatcher() {
    }

    public static List<Driver> rank(List<Driver> source, double requiredWeightKg, String recommendedVehicle, Double pickupLat, Double pickupLng) {
        double score;
        List<Driver> ranked = new ArrayList<>();
        if (source == null) {
            return ranked;
        }
        for (Driver d : source) {
            if (d != null && d.available && !d.disabled && d.isApproved()) {
                List<String> reasons = new ArrayList<>();
                if (requiredWeightKg <= 0.0d || d.capacity >= requiredWeightKg) {
                    score = 0.0d + 35.0d;
                    reasons.add("capacity fits");
                    if (requiredWeightKg > 0.0d && d.capacity <= 1.8d * requiredWeightKg) {
                        score += 8.0d;
                    }
                } else {
                    score = 0.0d - 50.0d;
                    reasons.add("capacity below load");
                }
                if (recommendedVehicle != null && d.vehicleType != null && recommendedVehicle.equalsIgnoreCase(d.vehicleType)) {
                    score += 25.0d;
                    reasons.add("recommended vehicle");
                }
                double score2 = score + ((double) (Math.max(0.0f, Math.min(5.0f, d.rating)) * 5.0f));
                if (d.rating >= 4.7f) {
                    reasons.add("high rating");
                }
                double score3 = score2 + ((double) Math.min(10, Math.max(0, d.experienceYears))) + Math.min(10.0d, ((double) Math.max(0, d.completedTrips)) / 10.0d);
                if (pickupLat != null && pickupLng != null && d.currentLat != null && d.currentLng != null) {
                    double km = GeoUtils.distanceKm(pickupLat.doubleValue(), pickupLng.doubleValue(), d.currentLat.doubleValue(), d.currentLng.doubleValue());
                    if (km <= 5.0d) {
                        score3 += 15.0d;
                        reasons.add("very close to pickup");
                    } else if (km <= 15.0d) {
                        score3 += 8.0d;
                        reasons.add("near pickup");
                    } else if (km > 40.0d) {
                        score3 -= 5.0d;
                    }
                }
                d.matchScore = score3;
                d.matchReason = reasons.isEmpty() ? "available" : DamageRiskScorer$$ExternalSyntheticBackport0.m(" • ", reasons);
                ranked.add(d);
            }
        }
        ranked.sort(Comparator.comparingDouble(new ToDoubleFunction() { // from class: cyberorion.pk.DriverMatcher$$ExternalSyntheticLambda0
            @Override // java.util.function.ToDoubleFunction
            public final double applyAsDouble(Object obj) {
                return ((Driver) obj).matchScore;
            }
        }).reversed().thenComparing(new Function() { // from class: cyberorion.pk.DriverMatcher$$ExternalSyntheticLambda1
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return Float.valueOf(((Driver) obj).rating);
            }
        }, Comparator.reverseOrder()));
        return ranked;
    }
}
