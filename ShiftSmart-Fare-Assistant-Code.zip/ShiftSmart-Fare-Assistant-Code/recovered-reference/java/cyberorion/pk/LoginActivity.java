package cyberorion.pk;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

/* JADX INFO: loaded from: classes3.dex */
public class LoginActivity extends AppCompatActivity {
    private Button btnLogin;
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private TextView tvForgotPassword;
    private TextView tvSignUp;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.mAuth = FirebaseAuth.getInstance();
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1768638687895-b5ee4a586c7f", getResources().getDisplayMetrics().widthPixels);
        this.etEmail = (TextInputEditText) findViewById(R.id.etEmail);
        this.etPassword = (TextInputEditText) findViewById(R.id.etPassword);
        this.btnLogin = (Button) findViewById(R.id.btnLogin);
        this.tvSignUp = (TextView) findViewById(R.id.tvSignUp);
        this.tvForgotPassword = (TextView) findViewById(R.id.tvForgotPassword);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.btnLogin.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m400lambda$onCreate$0$cyberorionpkLoginActivity(view);
            }
        });
        this.tvSignUp.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda6
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m401lambda$onCreate$1$cyberorionpkLoginActivity(view);
            }
        });
        findViewById(R.id.tvDriverLoginLink).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda7
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m402lambda$onCreate$2$cyberorionpkLoginActivity(view);
            }
        });
        findViewById(R.id.tvAdminLoginLink).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda8
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m403lambda$onCreate$3$cyberorionpkLoginActivity(view);
            }
        });
        this.tvForgotPassword.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda9
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m404lambda$onCreate$4$cyberorionpkLoginActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m400lambda$onCreate$0$cyberorionpkLoginActivity(View v) {
        loginUser();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m401lambda$onCreate$1$cyberorionpkLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) SignUpActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m402lambda$onCreate$2$cyberorionpkLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) DriverLoginActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m403lambda$onCreate$3$cyberorionpkLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) AdminLoginActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m404lambda$onCreate$4$cyberorionpkLoginActivity(View v) {
        showForgotPasswordDialog();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStart() {
        super.onStart();
        if (this.mAuth.getCurrentUser() != null) {
            routeAuthenticatedUser();
        }
    }

    private void loginUser() {
        String email = this.etEmail.getText() != null ? this.etEmail.getText().toString().trim() : "";
        String password = this.etPassword.getText() != null ? this.etPassword.getText().toString().trim() : "";
        if (TextUtils.isEmpty(email)) {
            this.etEmail.setError(getString(R.string.email_hint) + " is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            this.etPassword.setError(getString(R.string.password_hint) + " is required");
            return;
        }
        setLoading(true);
        if (AdminAccountManager.isDefaultAdminEmail(email)) {
            if (!AdminAccountManager.ADMIN_PASSWORD.equals(password)) {
                setLoading(false);
                Toast.makeText(this, "Invalid administrator credentials", 1).show();
                return;
            } else {
                AdminAccountManager.signInOrCreateDefaultAdmin(this.mAuth, new AdminAccountManager.Completion() { // from class: cyberorion.pk.LoginActivity.1
                    @Override // cyberorion.pk.AdminAccountManager.Completion
                    public void onSuccess(FirebaseUser user) {
                        LoginActivity.this.openAndClearTask(AdminDashboardActivity.class);
                    }

                    @Override // cyberorion.pk.AdminAccountManager.Completion
                    public void onError(Exception error) {
                        LoginActivity.this.setLoading(false);
                        Toast.makeText(LoginActivity.this, error.getMessage() != null ? error.getMessage() : "Administrator login failed", 1).show();
                    }
                });
                return;
            }
        }
        this.mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda1
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m399lambda$loginUser$5$cyberorionpkLoginActivity(task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$loginUser$5$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m399lambda$loginUser$5$cyberorionpkLoginActivity(Task task) {
        if (task.isSuccessful()) {
            routeAuthenticatedUser();
            return;
        }
        setLoading(false);
        String message = task.getException() != null ? task.getException().getMessage() : "Login failed";
        Toast.makeText(this, message, 1).show();
    }

    private void routeAuthenticatedUser() {
        FirebaseUser current = this.mAuth.getCurrentUser();
        if (current == null) {
            setLoading(false);
            return;
        }
        setLoading(true);
        if (AdminAccountManager.isDefaultAdminEmail(current.getEmail())) {
            AdminAccountManager.ensureAdminDatabaseRecord(current, new AdminAccountManager.Completion() { // from class: cyberorion.pk.LoginActivity.2
                @Override // cyberorion.pk.AdminAccountManager.Completion
                public void onSuccess(FirebaseUser user) {
                    LoginActivity.this.openAndClearTask(AdminDashboardActivity.class);
                }

                @Override // cyberorion.pk.AdminAccountManager.Completion
                public void onError(Exception error) {
                    LoginActivity.this.setLoading(false);
                    String message = error.getMessage() != null ? error.getMessage() : "Could not initialize administrator access";
                    Toast.makeText(LoginActivity.this, message, 1).show();
                }
            });
        } else {
            FirebaseDatabase.getInstance().getReference("users").child(current.getUid()).get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda3
                @Override // com.google.android.gms.tasks.OnSuccessListener
                public final void onSuccess(Object obj) {
                    this.f$0.m405lambda$routeAuthenticatedUser$6$cyberorionpkLoginActivity((DataSnapshot) obj);
                }
            }).addOnFailureListener(new OnFailureListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda4
                @Override // com.google.android.gms.tasks.OnFailureListener
                public final void onFailure(Exception exc) {
                    this.f$0.m406lambda$routeAuthenticatedUser$7$cyberorionpkLoginActivity(exc);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$routeAuthenticatedUser$6$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m405lambda$routeAuthenticatedUser$6$cyberorionpkLoginActivity(DataSnapshot snapshot) {
        User user = (User) snapshot.getValue(User.class);
        if (user != null && user.disabled) {
            this.mAuth.signOut();
            setLoading(false);
            Toast.makeText(this, "This account is disabled. Contact support.", 1).show();
            return;
        }
        openAndClearTask(MainActivity.class);
    }

    /* JADX INFO: renamed from: lambda$routeAuthenticatedUser$7$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m406lambda$routeAuthenticatedUser$7$cyberorionpkLoginActivity(Exception error) {
        setLoading(false);
        Toast.makeText(this, "Could not verify account: " + error.getMessage(), 1).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void openAndClearTask(Class<?> destination) {
        Intent intent = new Intent(this, destination);
        intent.addFlags(268468224);
        startActivity(intent);
        finish();
    }

    private void showForgotPasswordDialog() {
        final TextInputEditText input = new TextInputEditText(this);
        input.setHint(R.string.email_hint);
        String prefill = this.etEmail.getText() != null ? this.etEmail.getText().toString().trim() : "";
        if (!TextUtils.isEmpty(prefill)) {
            input.setText(prefill);
        }
        int padding = (int) (getResources().getDisplayMetrics().density * 20.0f);
        input.setPadding(padding, padding, padding, padding);
        new AlertDialog.Builder(this).setTitle(R.string.forgot_password).setMessage(R.string.forgot_password_message).setView(input).setPositiveButton(R.string.send_reset_link, new DialogInterface.OnClickListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda2
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m408lambda$showForgotPasswordDialog$8$cyberorionpkLoginActivity(input, dialogInterface, i);
            }
        }).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: renamed from: lambda$showForgotPasswordDialog$8$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m408lambda$showForgotPasswordDialog$8$cyberorionpkLoginActivity(TextInputEditText input, DialogInterface dialog, int which) {
        String email = input.getText() != null ? input.getText().toString().trim() : "";
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, R.string.email_required_message, 0).show();
        } else {
            sendPasswordReset(email);
        }
    }

    private void sendPasswordReset(String email) {
        this.mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.LoginActivity$$ExternalSyntheticLambda0
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m407lambda$sendPasswordReset$9$cyberorionpkLoginActivity(task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$sendPasswordReset$9$cyberorion-pk-LoginActivity, reason: not valid java name */
    /* synthetic */ void m407lambda$sendPasswordReset$9$cyberorionpkLoginActivity(Task task) {
        if (task.isSuccessful()) {
            Toast.makeText(this, R.string.reset_link_sent_message, 1).show();
        } else {
            String message = task.getException() != null ? task.getException().getMessage() : "Could not send reset email";
            Toast.makeText(this, message, 1).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setLoading(boolean loading) {
        this.progressBar.setVisibility(loading ? 0 : 8);
        this.btnLogin.setEnabled(!loading);
    }
}
