package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/* JADX INFO: loaded from: classes3.dex */
public class AdminLoginActivity extends AppCompatActivity {
    private FirebaseAuth auth;
    private Button btnLogin;
    private final AdminAccountManager.Completion completion = new AdminAccountManager.Completion() { // from class: cyberorion.pk.AdminLoginActivity.1
        @Override // cyberorion.pk.AdminAccountManager.Completion
        public void onSuccess(FirebaseUser user) {
            AdminLoginActivity.this.setLoading(false);
            Intent intent = new Intent(AdminLoginActivity.this, (Class<?>) AdminDashboardActivity.class);
            intent.addFlags(268468224);
            AdminLoginActivity.this.startActivity(intent);
            AdminLoginActivity.this.finish();
        }

        @Override // cyberorion.pk.AdminAccountManager.Completion
        public void onError(Exception error) {
            AdminLoginActivity.this.setLoading(false);
            String message = error.getMessage() != null ? error.getMessage() : "Administrator login failed";
            Toast.makeText(AdminLoginActivity.this, message, 1).show();
        }
    };
    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private ProgressBar progressBar;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1684695749267-233af13276d0", getResources().getDisplayMetrics().widthPixels);
        this.auth = FirebaseAuth.getInstance();
        this.etEmail = (TextInputEditText) findViewById(R.id.etAdminEmail);
        this.etPassword = (TextInputEditText) findViewById(R.id.etAdminPassword);
        this.btnLogin = (Button) findViewById(R.id.btnAdminLogin);
        this.progressBar = (ProgressBar) findViewById(R.id.progressAdminLogin);
        TextView backToUser = (TextView) findViewById(R.id.tvBackToUserLogin);
        this.etEmail.setText(AdminAccountManager.ADMIN_EMAIL);
        this.etPassword.setText(AdminAccountManager.ADMIN_PASSWORD);
        this.btnLogin.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminLoginActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m290lambda$onCreate$0$cyberorionpkAdminLoginActivity(view);
            }
        });
        backToUser.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminLoginActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m291lambda$onCreate$1$cyberorionpkAdminLoginActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-AdminLoginActivity, reason: not valid java name */
    /* synthetic */ void m290lambda$onCreate$0$cyberorionpkAdminLoginActivity(View v) {
        loginAdmin();
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-AdminLoginActivity, reason: not valid java name */
    /* synthetic */ void m291lambda$onCreate$1$cyberorionpkAdminLoginActivity(View v) {
        startActivity(new Intent(this, (Class<?>) LoginActivity.class));
        finish();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStart() {
        super.onStart();
        FirebaseUser current = this.auth.getCurrentUser();
        if (current != null && AdminAccountManager.isDefaultAdminEmail(current.getEmail())) {
            setLoading(true);
            AdminAccountManager.ensureAdminDatabaseRecord(current, this.completion);
        }
    }

    private void loginAdmin() {
        String email = textOf(this.etEmail);
        String password = textOf(this.etPassword);
        if (TextUtils.isEmpty(email)) {
            this.etEmail.setError("Admin email is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            this.etPassword.setError("Admin password is required");
        } else if (!AdminAccountManager.isDefaultAdminEmail(email) || !AdminAccountManager.ADMIN_PASSWORD.equals(password)) {
            Toast.makeText(this, "Invalid administrator credentials", 1).show();
        } else {
            setLoading(true);
            AdminAccountManager.signInOrCreateDefaultAdmin(this.auth, this.completion);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setLoading(boolean loading) {
        this.progressBar.setVisibility(loading ? 0 : 8);
        this.btnLogin.setEnabled(!loading);
        this.etEmail.setEnabled(!loading);
        this.etPassword.setEnabled(!loading);
    }

    private static String textOf(TextInputEditText input) {
        return input.getText() != null ? input.getText().toString().trim() : "";
    }
}
