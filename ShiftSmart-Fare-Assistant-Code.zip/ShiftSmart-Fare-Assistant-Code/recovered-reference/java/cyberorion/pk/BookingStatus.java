package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public enum BookingStatus {
    PENDING("Pending", "Waiting for a driver to accept"),
    ACCEPTED("Accepted", "Driver accepted your booking"),
    REJECTED("Rejected", "Driver declined this booking"),
    EN_ROUTE_PICKUP("Driver En Route", "Driver is on the way to pickup"),
    ARRIVED_PICKUP("Arrived at Pickup", "Driver has arrived at the pickup location"),
    PICKED_UP("Picked Up", "Your shipment has been picked up"),
    DELIVERING("Out for Delivery", "Your shipment is on its way to drop-off"),
    DELIVERED("Delivered", "Your shipment has been delivered"),
    COMPLETED("Completed", "Booking completed"),
    CANCELLED("Cancelled", "Booking was cancelled");

    public final String customerMessage;
    public final String label;

    BookingStatus(String label, String customerMessage) {
        this.label = label;
        this.customerMessage = customerMessage;
    }

    public static BookingStatus fromLabel(String label) {
        if (label == null) {
            return PENDING;
        }
        for (BookingStatus s : values()) {
            if (s.label.equalsIgnoreCase(label) || s.name().equalsIgnoreCase(label)) {
                return s;
            }
        }
        return PENDING;
    }

    public boolean isActive() {
        return this == ACCEPTED || this == EN_ROUTE_PICKUP || this == ARRIVED_PICKUP || this == PICKED_UP || this == DELIVERING;
    }

    public boolean isFinal() {
        return this == DELIVERED || this == COMPLETED || this == CANCELLED || this == REJECTED;
    }
}
