package cyberorion.pk;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public class Vehicle implements Serializable {
    public final double baseSurcharge;
    public final double capacityKg;
    public final int iconRes;
    public final String id;
    public final String name;
    public final boolean suitableForFragile;

    public Vehicle(String id, String name, double capacityKg, double baseSurcharge, int iconRes, boolean suitableForFragile) {
        this.id = id;
        this.name = name;
        this.capacityKg = capacityKg;
        this.baseSurcharge = baseSurcharge;
        this.iconRes = iconRes;
        this.suitableForFragile = suitableForFragile;
    }
}
