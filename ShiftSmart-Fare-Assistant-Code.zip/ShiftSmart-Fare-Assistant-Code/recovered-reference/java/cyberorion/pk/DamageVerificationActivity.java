package cyberorion.pk;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.os.EnvironmentCompat;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class DamageVerificationActivity extends AppCompatActivity {
    private String bookingId;
    private MaterialCardView cardDamaged;
    private MaterialCardView cardGood;
    private TextInputEditText etNotes;
    private LinearLayout layoutPhotos;
    private ActivityResultLauncher<String[]> pickImages;
    private String stage;
    private final List<Uri> attachedPhotos = new ArrayList();
    private String condition = DamageReport.CONDITION_GOOD;
    private boolean submitInFlight = false;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_damage_verification);
        this.bookingId = getIntent().getStringExtra(BookingKeys.EXTRA_BOOKING_ID);
        this.stage = getIntent().getStringExtra(BookingKeys.EXTRA_DAMAGE_STAGE);
        if (this.stage == null) {
            this.stage = DamageReport.STAGE_PICKUP;
        }
        if (this.bookingId == null) {
            Toast.makeText(this, "Missing booking reference", 0).show();
            finish();
            return;
        }
        TextView tvStage = (TextView) findViewById(R.id.tvDamageStage);
        tvStage.setText(DamageReport.STAGE_PICKUP.equals(this.stage) ? "Pickup condition" : "Delivery condition");
        this.cardGood = (MaterialCardView) findViewById(R.id.cardConditionGood);
        this.cardDamaged = (MaterialCardView) findViewById(R.id.cardConditionDamaged);
        this.etNotes = (TextInputEditText) findViewById(R.id.etDamageNotes);
        this.layoutPhotos = (LinearLayout) findViewById(R.id.layoutPhotoThumbs);
        this.cardGood.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m335lambda$onCreate$0$cyberorionpkDamageVerificationActivity(view);
            }
        });
        this.cardDamaged.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m336lambda$onCreate$1$cyberorionpkDamageVerificationActivity(view);
            }
        });
        selectCondition(DamageReport.CONDITION_GOOD);
        this.pickImages = registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), new ActivityResultCallback() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda2
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                this.f$0.m337lambda$onCreate$2$cyberorionpkDamageVerificationActivity((List) obj);
            }
        });
        findViewById(R.id.btnAddPhoto).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m338lambda$onCreate$3$cyberorionpkDamageVerificationActivity(view);
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m339lambda$onCreate$4$cyberorionpkDamageVerificationActivity(view);
            }
        });
        findViewById(R.id.btnSubmitDamageReport).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m340lambda$onCreate$5$cyberorionpkDamageVerificationActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m335lambda$onCreate$0$cyberorionpkDamageVerificationActivity(View v) {
        selectCondition(DamageReport.CONDITION_GOOD);
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m336lambda$onCreate$1$cyberorionpkDamageVerificationActivity(View v) {
        selectCondition(DamageReport.CONDITION_DAMAGED);
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m337lambda$onCreate$2$cyberorionpkDamageVerificationActivity(List uris) {
        if (uris != null) {
            Iterator it = uris.iterator();
            while (it.hasNext()) {
                Uri uri = (Uri) it.next();
                try {
                    getContentResolver().takePersistableUriPermission(uri, 1);
                } catch (Exception e) {
                }
                this.attachedPhotos.add(uri);
            }
            renderThumbnails();
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m338lambda$onCreate$3$cyberorionpkDamageVerificationActivity(View v) {
        this.pickImages.launch(new String[]{"image/*"});
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m339lambda$onCreate$4$cyberorionpkDamageVerificationActivity(View v) {
        finish();
    }

    /* JADX INFO: renamed from: lambda$onCreate$5$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m340lambda$onCreate$5$cyberorionpkDamageVerificationActivity(View v) {
        submitReport();
    }

    private void selectCondition(String newCondition) {
        this.condition = newCondition;
        boolean good = DamageReport.CONDITION_GOOD.equals(newCondition);
        this.cardGood.setStrokeWidth(good ? 4 : 0);
        this.cardDamaged.setStrokeWidth(good ? 0 : 4);
        this.cardGood.setStrokeColor(getColor(R.color.successColor));
        this.cardDamaged.setStrokeColor(getColor(R.color.errorColor));
    }

    private void renderThumbnails() {
        this.layoutPhotos.removeAllViews();
        for (Uri uri : this.attachedPhotos) {
            ImageView iv = new ImageView(this);
            int size = (int) (getResources().getDisplayMetrics().density * 72.0f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMarginEnd((int) (getResources().getDisplayMetrics().density * 8.0f));
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageURI(uri);
            this.layoutPhotos.addView(iv);
        }
    }

    private void submitReport() {
        if (this.submitInFlight) {
            return;
        }
        String driverId = FirebaseAuth.getInstance().getCurrentUser() != null ? FirebaseAuth.getInstance().getCurrentUser().getUid() : EnvironmentCompat.MEDIA_UNKNOWN;
        String notes = this.etNotes.getText() != null ? this.etNotes.getText().toString().trim() : "";
        StringBuilder photoCsv = new StringBuilder();
        for (int i = 0; i < this.attachedPhotos.size(); i++) {
            if (i > 0) {
                photoCsv.append(",");
            }
            photoCsv.append(this.attachedPhotos.get(i).toString());
        }
        DamageReport report = new DamageReport(this.bookingId, this.stage, this.condition, notes, photoCsv.toString(), driverId);
        this.submitInFlight = true;
        findViewById(R.id.btnSubmitDamageReport).setEnabled(false);
        FirebaseDatabase.getInstance().getReference().child("bookings").child(this.bookingId).child("damageReports").child(this.stage).setValue(report).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda6
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task) {
                this.f$0.m341lambda$submitReport$6$cyberorionpkDamageVerificationActivity(task);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$submitReport$6$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m341lambda$submitReport$6$cyberorionpkDamageVerificationActivity(Task task) {
        if (task.isSuccessful()) {
            Toast.makeText(this, R.string.damage_report_saved, 0).show();
            notifyCustomer();
            finish();
        } else {
            this.submitInFlight = false;
            findViewById(R.id.btnSubmitDamageReport).setEnabled(true);
            Toast.makeText(this, "Could not save report. Try again.", 0).show();
        }
    }

    private void notifyCustomer() {
        FirebaseDatabase.getInstance().getReference().child("bookings").child(this.bookingId).get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.DamageVerificationActivity$$ExternalSyntheticLambda7
            @Override // com.google.android.gms.tasks.OnSuccessListener
            public final void onSuccess(Object obj) {
                this.f$0.m334lambda$notifyCustomer$7$cyberorionpkDamageVerificationActivity((DataSnapshot) obj);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$notifyCustomer$7$cyberorion-pk-DamageVerificationActivity, reason: not valid java name */
    /* synthetic */ void m334lambda$notifyCustomer$7$cyberorionpkDamageVerificationActivity(DataSnapshot snapshot) {
        Booking booking = (Booking) snapshot.getValue(Booking.class);
        if (booking == null || booking.userId == null) {
            return;
        }
        String str = this.stage;
        String stageLabel = DamageReport.STAGE_PICKUP;
        if (!DamageReport.STAGE_PICKUP.equals(str)) {
            stageLabel = DamageReport.STAGE_DELIVERY;
        }
        String conditionLabel = DamageReport.CONDITION_GOOD.equals(this.condition) ? "good condition" : "some damage noted";
        NotificationHelper.notify(booking.userId, "Cargo condition recorded", "Driver logged " + stageLabel + " condition: " + conditionLabel + ".", AppNotification.TYPE_GENERAL, this.bookingId);
    }
}
