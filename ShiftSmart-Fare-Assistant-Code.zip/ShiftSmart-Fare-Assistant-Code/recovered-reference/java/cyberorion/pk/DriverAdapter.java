package cyberorion.pk;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes3.dex */
public class DriverAdapter extends RecyclerView.Adapter<DriverViewHolder> {
    private final List<Driver> driverList;
    private final OnDriverSelectedListener listener;
    private final String recommendedVehicleName;
    private int selectedPosition;

    public interface OnDriverSelectedListener {
        void onDriverSelected(Driver driver);
    }

    public DriverAdapter(List<Driver> l, OnDriverSelectedListener x) {
        this(l, x, null);
    }

    public DriverAdapter(List<Driver> l, OnDriverSelectedListener x, String r) {
        this.selectedPosition = -1;
        this.driverList = l;
        this.listener = x;
        this.recommendedVehicleName = r;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public DriverViewHolder onCreateViewHolder(ViewGroup p, int v) {
        return new DriverViewHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_driver, p, false));
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(final DriverViewHolder h, int pos) {
        final Driver d = this.driverList.get(pos);
        Context c = h.itemView.getContext();
        h.name.setText(d.name);
        h.vehicle.setText(c.getString(R.string.driver_vehicle_format, d.vehicleType, d.vehicleNumber));
        h.capacity.setText(c.getString(R.string.driver_capacity_format, Double.valueOf(d.capacity)));
        h.rating.setText(String.format(Locale.getDefault(), "★ %.1f", Float.valueOf(d.rating)));
        h.meta.setText(String.format(Locale.getDefault(), "%d trips • %d yrs experience", Integer.valueOf(d.completedTrips), Integer.valueOf(d.experienceYears)));
        h.match.setText(d.matchReason != null ? String.format(Locale.getDefault(), "Smart match %.0f • %s", Double.valueOf(d.matchScore), d.matchReason) : "Available now");
        h.icon.setImageResource(vehicleIconFor(d.vehicleType));
        if (d.photoData != null && !d.photoData.isEmpty()) {
            try {
                byte[] bytes = Base64.decode(d.photoData, 0);
                h.icon.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length));
                h.icon.setPadding(0, 0, 0, 0);
            } catch (Exception e) {
            }
        } else if (d.photoUrl != null && (d.photoUrl.startsWith("content:") || d.photoUrl.startsWith("file:"))) {
            try {
                h.icon.setImageURI(Uri.parse(d.photoUrl));
                h.icon.setPadding(0, 0, 0, 0);
            } catch (Exception e2) {
            }
        }
        h.badge.setVisibility((this.recommendedVehicleName == null || !this.recommendedVehicleName.equalsIgnoreCase(d.vehicleType)) ? 8 : 0);
        boolean selected = pos == this.selectedPosition;
        h.card.setStrokeWidth(selected ? 4 : 1);
        h.card.setStrokeColor(c.getColor(selected ? R.color.primaryColor : R.color.lightGray));
        h.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m342lambda$onBindViewHolder$0$cyberorionpkDriverAdapter(h, d, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-DriverAdapter, reason: not valid java name */
    /* synthetic */ void m342lambda$onBindViewHolder$0$cyberorionpkDriverAdapter(DriverViewHolder h, Driver d, View v) {
        int old = this.selectedPosition;
        this.selectedPosition = h.getBindingAdapterPosition();
        if (old >= 0) {
            notifyItemChanged(old);
        }
        if (this.selectedPosition >= 0) {
            notifyItemChanged(this.selectedPosition);
        }
        this.listener.onDriverSelected(d);
    }

    private int vehicleIconFor(String t) {
        if (t == null) {
            return R.drawable.ic_vehicle_car;
        }
        String s = t.toLowerCase(Locale.ROOT);
        if (s.contains("bike")) {
            return R.drawable.ic_vehicle_bike;
        }
        if (s.contains("van")) {
            return R.drawable.ic_vehicle_van;
        }
        return s.contains("truck") ? R.drawable.ic_vehicle_truck : R.drawable.ic_vehicle_car;
    }

    static class DriverViewHolder extends RecyclerView.ViewHolder {
        TextView badge;
        TextView capacity;
        MaterialCardView card;
        ImageView icon;
        TextView match;
        TextView meta;
        TextView name;
        TextView rating;
        TextView vehicle;

        DriverViewHolder(View v) {
            super(v);
            this.card = (MaterialCardView) v.findViewById(R.id.cardDriver);
            this.icon = (ImageView) v.findViewById(R.id.ivVehicleIcon);
            this.name = (TextView) v.findViewById(R.id.tvDriverName);
            this.vehicle = (TextView) v.findViewById(R.id.tvDriverVehicle);
            this.capacity = (TextView) v.findViewById(R.id.tvDriverCapacity);
            this.rating = (TextView) v.findViewById(R.id.tvDriverRating);
            this.badge = (TextView) v.findViewById(R.id.tvAiBadge);
            this.meta = (TextView) v.findViewById(R.id.tvDriverMeta);
            this.match = (TextView) v.findViewById(R.id.tvDriverMatchReason);
        }
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.driverList.size();
    }
}
