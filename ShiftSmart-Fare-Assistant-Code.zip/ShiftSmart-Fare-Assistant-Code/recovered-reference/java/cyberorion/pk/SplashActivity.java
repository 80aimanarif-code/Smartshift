package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/* JADX INFO: loaded from: classes3.dex */
public class SplashActivity extends AppCompatActivity {
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        int screenWidthPx = getResources().getDisplayMetrics().widthPixels;
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1684695749267-233af13276d0", screenWidthPx);
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() { // from class: cyberorion.pk.SplashActivity$$ExternalSyntheticLambda0
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.route();
            }
        }, 2000L);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void route() {
        FirebaseUser current = FirebaseAuth.getInstance().getCurrentUser();
        if (current == null) {
            go(LoginActivity.class);
        } else if (AdminAccountManager.isDefaultAdminEmail(current.getEmail())) {
            go(AdminDashboardActivity.class);
        } else {
            String uid = current.getUid();
            FirebaseDatabase.getInstance().getReference("drivers").child(uid).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.SplashActivity.1
                @Override // com.google.firebase.database.ValueEventListener
                public void onDataChange(DataSnapshot snapshot) {
                    String reason;
                    if (!snapshot.exists()) {
                        SplashActivity.this.go(MainActivity.class);
                        return;
                    }
                    Driver driver = (Driver) snapshot.getValue(Driver.class);
                    if (driver == null || driver.disabled || !driver.isApproved()) {
                        FirebaseAuth.getInstance().signOut();
                        if (driver != null && driver.disabled) {
                            reason = "This driver account is disabled. Contact support.";
                        } else if (driver != null && Driver.STATUS_REJECTED.equals(driver.approvalStatus)) {
                            reason = "Your driver application was rejected. Contact support for review.";
                        } else {
                            reason = "Your driver application is still pending admin approval.";
                        }
                        Toast.makeText(SplashActivity.this, reason, 1).show();
                        SplashActivity.this.go(DriverLoginActivity.class);
                        return;
                    }
                    SplashActivity.this.go(DriverDashboardActivity.class);
                }

                @Override // com.google.firebase.database.ValueEventListener
                public void onCancelled(DatabaseError error) {
                    SplashActivity.this.go(MainActivity.class);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void go(Class<?> destination) {
        startActivity(new Intent(this, destination));
        finish();
    }
}
