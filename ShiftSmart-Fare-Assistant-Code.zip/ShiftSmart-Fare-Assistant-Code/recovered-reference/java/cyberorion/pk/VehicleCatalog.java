package cyberorion.pk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class VehicleCatalog {
    private static final List<Vehicle> VEHICLES = Collections.unmodifiableList(new ArrayList<Vehicle>() { // from class: cyberorion.pk.VehicleCatalog.1
        {
            add(new Vehicle("bike", "Bike Courier", 15.0d, 0.0d, R.drawable.ic_vehicle_bike, false));
            add(new Vehicle("suzuki_pickup", "Suzuki Pickup", 400.0d, 300.0d, R.drawable.ic_vehicle_car, true));
            add(new Vehicle("mini_van", "Mini Van", 800.0d, 500.0d, R.drawable.ic_vehicle_van, true));
            add(new Vehicle("shehzore", "Shehzore", 1500.0d, 900.0d, R.drawable.ic_vehicle_truck, true));
            add(new Vehicle("mazda_truck", "Mazda Truck", 4000.0d, 1600.0d, R.drawable.ic_vehicle_truck, false));
            add(new Vehicle("container_truck", "Container Truck", 10000.0d, 3000.0d, R.drawable.ic_vehicle_truck, false));
        }
    });

    private VehicleCatalog() {
    }

    public static List<Vehicle> all() {
        return VEHICLES;
    }

    public static Vehicle findById(String id) {
        if (id == null) {
            return VEHICLES.get(0);
        }
        for (Vehicle v : VEHICLES) {
            if (v.id.equals(id)) {
                return v;
            }
        }
        return VEHICLES.get(0);
    }
}
