package cyberorion.pk;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/* JADX INFO: loaded from: classes3.dex */
public class DriverSignUpActivity extends AppCompatActivity {
    private AutoCompleteTextView actVehicleType;
    private Button btnSignUp;
    private TextInputEditText etCapacity;
    private TextInputEditText etEmail;
    private TextInputEditText etExperience;
    private TextInputEditText etName;
    private TextInputEditText etPassword;
    private TextInputEditText etVehicleNumber;
    private ImageView ivDriverPhotoPreview;
    private FirebaseAuth mAuth;
    private ActivityResultLauncher<String[]> pickPhoto;
    private ProgressBar progressBar;
    private String selectedPhotoUri = "";

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_signup);
        HeroImages.load((ImageView) findViewById(R.id.ivHeroPhoto), "https://images.unsplash.com/photo-1684695749267-233af13276d0", getResources().getDisplayMetrics().widthPixels);
        this.mAuth = FirebaseAuth.getInstance();
        this.etName = (TextInputEditText) findViewById(R.id.etName);
        this.etEmail = (TextInputEditText) findViewById(R.id.etEmail);
        this.etPassword = (TextInputEditText) findViewById(R.id.etPassword);
        this.etVehicleNumber = (TextInputEditText) findViewById(R.id.etVehicleNumber);
        this.etCapacity = (TextInputEditText) findViewById(R.id.etCapacity);
        this.etExperience = (TextInputEditText) findViewById(R.id.etExperience);
        this.actVehicleType = (AutoCompleteTextView) findViewById(R.id.actVehicleType);
        this.btnSignUp = (Button) findViewById(R.id.btnDriverSignUp);
        this.progressBar = (ProgressBar) findViewById(R.id.progressBar);
        this.ivDriverPhotoPreview = (ImageView) findViewById(R.id.ivDriverPhotoPreview);
        this.pickPhoto = registerForActivityResult(new ActivityResultContracts.OpenDocument(), new ActivityResultCallback() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda0
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                this.f$0.m387lambda$onCreate$0$cyberorionpkDriverSignUpActivity((Uri) obj);
            }
        });
        findViewById(R.id.btnChooseDriverPhoto).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m388lambda$onCreate$1$cyberorionpkDriverSignUpActivity(view);
            }
        });
        List<String> names = (List) VehicleCatalog.all().stream().map(new Function() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda2
            @Override // java.util.function.Function
            public final Object apply(Object obj) {
                return ((Vehicle) obj).name;
            }
        }).collect(Collectors.toList());
        this.actVehicleType.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, names));
        this.btnSignUp.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m389lambda$onCreate$3$cyberorionpkDriverSignUpActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-DriverSignUpActivity, reason: not valid java name */
    /* synthetic */ void m387lambda$onCreate$0$cyberorionpkDriverSignUpActivity(Uri uri) {
        if (uri != null) {
            try {
                getContentResolver().takePersistableUriPermission(uri, 1);
            } catch (Exception e) {
            }
            this.selectedPhotoUri = uri.toString();
            this.ivDriverPhotoPreview.setImageURI(uri);
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-DriverSignUpActivity, reason: not valid java name */
    /* synthetic */ void m388lambda$onCreate$1$cyberorionpkDriverSignUpActivity(View v) {
        this.pickPhoto.launch(new String[]{"image/*"});
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-DriverSignUpActivity, reason: not valid java name */
    /* synthetic */ void m389lambda$onCreate$3$cyberorionpkDriverSignUpActivity(View v) {
        registerDriver();
    }

    private void registerDriver() {
        final String name = textOf(this.etName);
        final String email = textOf(this.etEmail);
        String password = textOf(this.etPassword);
        final String vehicleType = this.actVehicleType.getText() != null ? this.actVehicleType.getText().toString().trim() : "";
        final String vehicleNumber = textOf(this.etVehicleNumber);
        String capacityText = textOf(this.etCapacity);
        String experienceText = textOf(this.etExperience);
        final String photoUrl = this.selectedPhotoUri;
        final String photoData = encodeSelectedPhoto();
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(vehicleType) || TextUtils.isEmpty(vehicleNumber) || TextUtils.isEmpty(capacityText) || TextUtils.isEmpty(experienceText)) {
            Toast.makeText(this, "Please fill in all fields", 0).show();
            return;
        }
        try {
            final double capacity = Double.parseDouble(capacityText);
            final int experienceYears = Integer.parseInt(experienceText);
            setLoading(true);
            this.mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda4
                @Override // com.google.android.gms.tasks.OnCompleteListener
                public final void onComplete(Task task) {
                    this.f$0.m391lambda$registerDriver$5$cyberorionpkDriverSignUpActivity(name, email, vehicleType, vehicleNumber, capacity, photoUrl, photoData, experienceYears, task);
                }
            });
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid capacity", 0).show();
        }
    }

    /* JADX INFO: renamed from: lambda$registerDriver$5$cyberorion-pk-DriverSignUpActivity, reason: not valid java name */
    /* synthetic */ void m391lambda$registerDriver$5$cyberorionpkDriverSignUpActivity(String name, String email, String vehicleType, String vehicleNumber, double capacity, String photoUrl, String photoData, int experienceYears, Task task) {
        if (!task.isSuccessful()) {
            setLoading(false);
            String message = task.getException() != null ? task.getException().getMessage() : "Sign up failed";
            Toast.makeText(this, message, 1).show();
            return;
        }
        String uid = this.mAuth.getCurrentUser() != null ? this.mAuth.getCurrentUser().getUid() : null;
        if (uid == null) {
            setLoading(false);
            return;
        }
        Map<String, Object> driverData = new HashMap<>();
        driverData.put("driverId", uid);
        driverData.put("name", name);
        driverData.put("email", email);
        driverData.put("vehicleType", vehicleType);
        driverData.put("vehicleNumber", vehicleNumber);
        driverData.put("capacity", Double.valueOf(capacity));
        driverData.put("rating", Float.valueOf(5.0f));
        driverData.put("available", false);
        driverData.put("photoUrl", photoUrl);
        driverData.put("photoData", photoData);
        driverData.put("completedTrips", 0);
        driverData.put("experienceYears", Integer.valueOf(Math.max(0, experienceYears)));
        driverData.put(Driver.STATUS_APPROVED, false);
        driverData.put("approvalStatus", Driver.STATUS_PENDING);
        driverData.put("disabled", false);
        FirebaseDatabase.getInstance().getReference().child("drivers").child(uid).setValue(driverData).addOnCompleteListener(new OnCompleteListener() { // from class: cyberorion.pk.DriverSignUpActivity$$ExternalSyntheticLambda5
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public final void onComplete(Task task2) {
                this.f$0.m390lambda$registerDriver$4$cyberorionpkDriverSignUpActivity(task2);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$registerDriver$4$cyberorion-pk-DriverSignUpActivity, reason: not valid java name */
    /* synthetic */ void m390lambda$registerDriver$4$cyberorionpkDriverSignUpActivity(Task dbTask) {
        setLoading(false);
        if (dbTask.isSuccessful()) {
            this.mAuth.signOut();
            Toast.makeText(this, "Application submitted. An admin must approve your driver profile before you can accept jobs.", 1).show();
            Intent intent = new Intent(this, (Class<?>) DriverLoginActivity.class);
            intent.addFlags(268468224);
            startActivity(intent);
            finish();
            return;
        }
        Toast.makeText(this, "Could not save driver profile", 1).show();
    }

    private String encodeSelectedPhoto() {
        if (this.selectedPhotoUri.isEmpty()) {
            return "";
        }
        try {
            InputStream in = getContentResolver().openInputStream(Uri.parse(this.selectedPhotoUri));
            try {
                Bitmap source = BitmapFactory.decodeStream(in);
                if (source != null) {
                    int w = source.getWidth();
                    int h = source.getHeight();
                    Bitmap scaled = source;
                    if (w > 320 || h > 320) {
                        float scale = Math.min(320 / w, 320 / h);
                        scaled = Bitmap.createScaledBitmap(source, Math.max(1, Math.round(w * scale)), Math.max(1, Math.round(h * scale)), true);
                    }
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    scaled.compress(Bitmap.CompressFormat.JPEG, 65, out);
                    if (scaled != source) {
                        scaled.recycle();
                    }
                    source.recycle();
                    String strEncodeToString = Base64.encodeToString(out.toByteArray(), 2);
                    if (in != null) {
                        in.close();
                    }
                    return strEncodeToString;
                }
                if (in != null) {
                    in.close();
                }
                return "";
            } catch (Throwable th) {
                if (in != null) {
                    try {
                        in.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        } catch (Exception e) {
            return "";
        }
        return "";
    }

    private String textOf(TextInputEditText et) {
        return et.getText() != null ? et.getText().toString().trim() : "";
    }

    private void setLoading(boolean loading) {
        this.progressBar.setVisibility(loading ? 0 : 8);
        this.btnSignUp.setEnabled(!loading);
    }
}
