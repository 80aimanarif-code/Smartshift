package cyberorion.pk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/* JADX INFO: loaded from: classes3.dex */
public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        HeroImages.load((ImageView) findViewById(R.id.ivBookHeroPhoto), "https://images.unsplash.com/photo-1768638687895-b5ee4a586c7f", getResources().getDisplayMetrics().widthPixels);
        this.mAuth = FirebaseAuth.getInstance();
        this.mDatabase = FirebaseDatabase.getInstance().getReference();
        enforceAccountAccess();
        TextView tvWelcome = (TextView) findViewById(R.id.tvWelcome);
        MaterialButton btnProfile = (MaterialButton) findViewById(R.id.btnProfile);
        MaterialButton btnNotifications = (MaterialButton) findViewById(R.id.btnNotifications);
        View notifBadge = findViewById(R.id.viewNotifBadge);
        MaterialCardView cardBook = (MaterialCardView) findViewById(R.id.cardBook);
        MaterialCardView cardLuggage = (MaterialCardView) findViewById(R.id.cardLuggage);
        MaterialCardView cardTrack = (MaterialCardView) findViewById(R.id.cardTrack);
        loadGreeting(tvWelcome);
        btnProfile.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m415lambda$onCreate$0$cyberorionpkMainActivity(view);
            }
        });
        btnNotifications.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda2
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m416lambda$onCreate$1$cyberorionpkMainActivity(view);
            }
        });
        if (this.mAuth.getCurrentUser() != null) {
            NotificationHelper.attachUnreadBadge(this.mAuth.getCurrentUser().getUid(), notifBadge);
        }
        cardBook.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m417lambda$onCreate$2$cyberorionpkMainActivity(view);
            }
        });
        cardLuggage.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m418lambda$onCreate$3$cyberorionpkMainActivity(view);
            }
        });
        cardTrack.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m419lambda$onCreate$4$cyberorionpkMainActivity(view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m415lambda$onCreate$0$cyberorionpkMainActivity(View v) {
        startActivity(new Intent(this, (Class<?>) ProfileActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m416lambda$onCreate$1$cyberorionpkMainActivity(View v) {
        startActivity(new Intent(this, (Class<?>) NotificationsActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m417lambda$onCreate$2$cyberorionpkMainActivity(View v) {
        startActivity(new Intent(this, (Class<?>) ShiftingTypeActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m418lambda$onCreate$3$cyberorionpkMainActivity(View v) {
        startActivity(new Intent(this, (Class<?>) ShiftingTypeActivity.class));
    }

    /* JADX INFO: renamed from: lambda$onCreate$4$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m419lambda$onCreate$4$cyberorionpkMainActivity(View v) {
        startActivity(new Intent(this, (Class<?>) TrackOrderActivity.class));
    }

    private void enforceAccountAccess() {
        if (this.mAuth.getCurrentUser() == null) {
            startActivity(new Intent(this, (Class<?>) LoginActivity.class));
            finish();
        } else {
            String uid = this.mAuth.getCurrentUser().getUid();
            this.mDatabase.child("users").child(uid).child("disabled").get().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.MainActivity$$ExternalSyntheticLambda0
                @Override // com.google.android.gms.tasks.OnSuccessListener
                public final void onSuccess(Object obj) {
                    this.f$0.m414lambda$enforceAccountAccess$5$cyberorionpkMainActivity((DataSnapshot) obj);
                }
            });
        }
    }

    /* JADX INFO: renamed from: lambda$enforceAccountAccess$5$cyberorion-pk-MainActivity, reason: not valid java name */
    /* synthetic */ void m414lambda$enforceAccountAccess$5$cyberorionpkMainActivity(DataSnapshot snapshot) {
        Boolean disabled = (Boolean) snapshot.getValue(Boolean.class);
        if (Boolean.TRUE.equals(disabled)) {
            this.mAuth.signOut();
            Intent i = new Intent(this, (Class<?>) LoginActivity.class);
            i.addFlags(268468224);
            startActivity(i);
            finish();
        }
    }

    private void loadGreeting(final TextView tvWelcome) {
        if (this.mAuth.getCurrentUser() == null) {
            return;
        }
        String userId = this.mAuth.getCurrentUser().getUid();
        this.mDatabase.child("users").child(userId).addListenerForSingleValueEvent(new ValueEventListener() { // from class: cyberorion.pk.MainActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                User user = (User) snapshot.getValue(User.class);
                String name = (user == null || user.name == null || user.name.isEmpty()) ? "there" : user.name;
                tvWelcome.setText(MainActivity.this.getString(R.string.greeting_format, new Object[]{name}));
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
                tvWelcome.setText(MainActivity.this.getString(R.string.greeting_format, new Object[]{"there"}));
            }
        });
    }
}
