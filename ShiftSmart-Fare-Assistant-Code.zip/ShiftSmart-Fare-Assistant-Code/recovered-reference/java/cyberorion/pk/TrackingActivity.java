package cyberorion.pk;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes3.dex */
public class TrackingActivity extends AppCompatActivity implements OnMapReadyCallback {
    private static final long LOCATION_INTERVAL_MS = 5000;
    private static final long LOCATION_MIN_INTERVAL_MS = 2000;
    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private Query activeSosQuery;
    private String bookingId;
    private DatabaseReference bookingRef;
    private MaterialButton btnToggleSharing;
    private Booking currentBooking;
    private Marker driverMarker;
    private Double dropoffLat;
    private Double dropoffLng;
    private FloatingActionButton fabSos;
    private FusedLocationProviderClient fusedLocationClient;
    private GoogleMap googleMap;
    private View layoutDriverControls;
    private LocationCallback locationCallback;
    private ActivityResultLauncher<String[]> locationPermissionLauncher;
    private MapView mapView;
    private Double pickupLat;
    private Double pickupLng;
    private String role;
    private DatabaseReference trackingRef;
    private TextView tvSosBanner;
    private TextView tvTripRoute;
    private TextView tvTripStatus;
    private boolean sharingLocation = false;
    private boolean routeDrawn = false;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);
        this.bookingId = getIntent().getStringExtra(BookingKeys.EXTRA_BOOKING_ID);
        this.role = getIntent().getStringExtra(BookingKeys.EXTRA_ROLE);
        if (this.role == null) {
            this.role = BookingKeys.ROLE_CUSTOMER;
        }
        if (this.bookingId == null) {
            Toast.makeText(this, "Missing booking reference", 0).show();
            finish();
            return;
        }
        this.tvTripStatus = (TextView) findViewById(R.id.tvTripStatus);
        this.tvTripRoute = (TextView) findViewById(R.id.tvTripRoute);
        this.tvSosBanner = (TextView) findViewById(R.id.tvSosBanner);
        this.layoutDriverControls = findViewById(R.id.layoutDriverControls);
        this.btnToggleSharing = (MaterialButton) findViewById(R.id.btnToggleSharing);
        this.fabSos = (FloatingActionButton) findViewById(R.id.fabSos);
        findViewById(R.id.btnDamageComparison).setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m483lambda$onCreate$0$cyberorionpkTrackingActivity(view);
            }
        });
        this.fabSos.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda5
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m484lambda$onCreate$1$cyberorionpkTrackingActivity(view);
            }
        });
        this.mapView = (MapView) findViewById(R.id.mapTracking);
        Bundle mapViewBundle = savedInstanceState != null ? savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY) : null;
        this.mapView.onCreate(mapViewBundle);
        this.mapView.getMapAsync(this);
        DatabaseReference root = FirebaseDatabase.getInstance().getReference();
        this.bookingRef = root.child("bookings").child(this.bookingId);
        this.trackingRef = root.child("tracking").child(this.bookingId);
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        this.locationPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), new ActivityResultCallback() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda6
            @Override // androidx.activity.result.ActivityResultCallback
            public final void onActivityResult(Object obj) {
                this.f$0.m485lambda$onCreate$2$cyberorionpkTrackingActivity((Map) obj);
            }
        });
        if (BookingKeys.ROLE_DRIVER.equals(this.role)) {
            this.layoutDriverControls.setVisibility(0);
            this.btnToggleSharing.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda7
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    this.f$0.m486lambda$onCreate$3$cyberorionpkTrackingActivity(view);
                }
            });
        }
        loadBooking();
        listenForDriverPosition();
        listenForActiveSos();
    }

    /* JADX INFO: renamed from: lambda$onCreate$0$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m483lambda$onCreate$0$cyberorionpkTrackingActivity(View v) {
        Intent i = new Intent(this, (Class<?>) DamageComparisonActivity.class);
        i.putExtra(BookingKeys.EXTRA_BOOKING_ID, this.bookingId);
        startActivity(i);
    }

    /* JADX INFO: renamed from: lambda$onCreate$1$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m484lambda$onCreate$1$cyberorionpkTrackingActivity(View v) {
        showSosDialog();
    }

    /* JADX INFO: renamed from: lambda$onCreate$2$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m485lambda$onCreate$2$cyberorionpkTrackingActivity(Map grantResults) {
        boolean granted = Boolean.TRUE.equals(grantResults.get("android.permission.ACCESS_FINE_LOCATION")) || Boolean.TRUE.equals(grantResults.get("android.permission.ACCESS_COARSE_LOCATION"));
        if (granted) {
            beginSharing();
        } else {
            Toast.makeText(this, "Location permission is needed to share your live position", 1).show();
        }
    }

    /* JADX INFO: renamed from: lambda$onCreate$3$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m486lambda$onCreate$3$cyberorionpkTrackingActivity(View v) {
        toggleSharing();
    }

    private void showSosDialog() {
        new AlertDialog.Builder(this).setTitle(R.string.sos_dialog_title).setMessage(R.string.sos_dialog_message).setPositiveButton(R.string.sos_alert_support, new DialogInterface.OnClickListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda0
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m487lambda$showSosDialog$4$cyberorionpkTrackingActivity(dialogInterface, i);
            }
        }).setNeutralButton(R.string.sos_call_emergency, new DialogInterface.OnClickListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda1
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                this.f$0.m488lambda$showSosDialog$5$cyberorionpkTrackingActivity(dialogInterface, i);
            }
        }).setNegativeButton(android.R.string.cancel, (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: renamed from: lambda$showSosDialog$4$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m487lambda$showSosDialog$4$cyberorionpkTrackingActivity(DialogInterface dialog, int which) {
        raiseSosAlert();
    }

    /* JADX INFO: renamed from: lambda$showSosDialog$5$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m488lambda$showSosDialog$5$cyberorionpkTrackingActivity(DialogInterface dialog, int which) {
        Intent dial = new Intent("android.intent.action.DIAL", Uri.parse("tel:1122"));
        startActivity(dial);
    }

    private void raiseSosAlert() {
        if (this.currentBooking == null) {
            Toast.makeText(this, "Booking not loaded yet — please try again", 0).show();
            return;
        }
        String uid = FirebaseAuth.getInstance().getCurrentUser() != null ? FirebaseAuth.getInstance().getCurrentUser().getUid() : null;
        Double lat = Double.valueOf(this.driverMarker != null ? this.driverMarker.getPosition().latitude : this.pickupLat.doubleValue());
        Double lng = Double.valueOf(this.driverMarker != null ? this.driverMarker.getPosition().longitude : this.pickupLng.doubleValue());
        SosHelper.raise(this.currentBooking, uid, this.role, "SOS triggered from live tracking", lat, lng);
        Toast.makeText(this, R.string.sos_sent_message, 1).show();
    }

    private void listenForActiveSos() {
        this.activeSosQuery = FirebaseDatabase.getInstance().getReference().child(AppNotification.TYPE_SOS).orderByChild("bookingId").equalTo(this.bookingId);
        this.activeSosQuery.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.TrackingActivity.1
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                boolean active = false;
                for (DataSnapshot child : snapshot.getChildren()) {
                    SosAlert alert = (SosAlert) child.getValue(SosAlert.class);
                    if (alert != null && SosAlert.STATUS_ACTIVE.equals(alert.status)) {
                        active = true;
                        break;
                    }
                }
                TrackingActivity.this.tvSosBanner.setVisibility(active ? 0 : 8);
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void loadBooking() {
        this.bookingRef.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.TrackingActivity.2
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                Booking booking = (Booking) snapshot.getValue(Booking.class);
                if (booking == null) {
                    return;
                }
                booking.bookingId = TrackingActivity.this.bookingId;
                TrackingActivity.this.currentBooking = booking;
                TrackingActivity.this.pickupLat = booking.pickupLat;
                TrackingActivity.this.pickupLng = booking.pickupLng;
                TrackingActivity.this.dropoffLat = booking.dropoffLat;
                TrackingActivity.this.dropoffLng = booking.dropoffLng;
                BookingStatus status = BookingStatus.fromLabel(booking.status);
                TrackingActivity.this.tvTripStatus.setText(status.label);
                TrackingActivity.this.tvTripRoute.setText(String.format("%s → %s", booking.pickup, booking.dropoff));
                if (TrackingActivity.this.googleMap != null && TrackingActivity.this.pickupLat != null && TrackingActivity.this.dropoffLat != null) {
                    TrackingActivity.this.drawRouteOnce();
                }
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
                Toast.makeText(TrackingActivity.this, error.getMessage(), 0).show();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void drawRouteOnce() {
        if (this.routeDrawn || this.googleMap == null || this.pickupLat == null || this.dropoffLat == null) {
            return;
        }
        this.routeDrawn = true;
        LatLng pickupLatLng = new LatLng(this.pickupLat.doubleValue(), this.pickupLng.doubleValue());
        LatLng dropoffLatLng = new LatLng(this.dropoffLat.doubleValue(), this.dropoffLng.doubleValue());
        this.googleMap.addMarker(new MarkerOptions().position(pickupLatLng).title("Pickup").icon(BitmapDescriptorFactory.defaultMarker(210.0f)));
        this.googleMap.addMarker(new MarkerOptions().position(dropoffLatLng).title("Drop-off").icon(BitmapDescriptorFactory.defaultMarker(30.0f)));
        this.googleMap.addPolyline(new PolylineOptions().add(pickupLatLng, dropoffLatLng).width(6.0f).color(getColor(R.color.primaryColor)).geodesic(true));
        final LatLngBounds bounds = new LatLngBounds.Builder().include(pickupLatLng).include(dropoffLatLng).build();
        this.mapView.post(new Runnable() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m482lambda$drawRouteOnce$6$cyberorionpkTrackingActivity(bounds);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$drawRouteOnce$6$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m482lambda$drawRouteOnce$6$cyberorionpkTrackingActivity(LatLngBounds bounds) {
        if (this.googleMap != null) {
            this.googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 120));
        }
    }

    private void listenForDriverPosition() {
        this.trackingRef.addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.TrackingActivity.3
            @Override // com.google.firebase.database.ValueEventListener
            public void onDataChange(DataSnapshot snapshot) {
                Double lat = (Double) snapshot.child("lat").getValue(Double.class);
                Double lng = (Double) snapshot.child("lng").getValue(Double.class);
                if (lat == null || lng == null || TrackingActivity.this.googleMap == null) {
                    return;
                }
                LatLng position = new LatLng(lat.doubleValue(), lng.doubleValue());
                Marker marker = TrackingActivity.this.driverMarker;
                TrackingActivity trackingActivity = TrackingActivity.this;
                if (marker == null) {
                    trackingActivity.driverMarker = TrackingActivity.this.googleMap.addMarker(new MarkerOptions().position(position).title("Driver").icon(BitmapDescriptorFactory.defaultMarker(120.0f)));
                } else {
                    trackingActivity.driverMarker.setPosition(position);
                }
            }

            @Override // com.google.firebase.database.ValueEventListener
            public void onCancelled(DatabaseError error) {
            }
        });
    }

    private void toggleSharing() {
        if (this.sharingLocation) {
            stopSharing();
        } else if (hasLocationPermission()) {
            beginSharing();
        } else {
            this.locationPermissionLauncher.launch(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"});
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this, "android.permission.ACCESS_COARSE_LOCATION") == 0;
    }

    private void beginSharing() {
        if (hasLocationPermission()) {
            LocationRequest request = new LocationRequest.Builder(5000L).setMinUpdateIntervalMillis(LOCATION_MIN_INTERVAL_MS).setPriority(100).build();
            this.locationCallback = new LocationCallback() { // from class: cyberorion.pk.TrackingActivity.4
                @Override // com.google.android.gms.location.LocationCallback
                public void onLocationResult(LocationResult result) {
                    Location location = result.getLastLocation();
                    if (location != null) {
                        TrackingActivity.this.pushDriverLocation(location);
                    }
                }
            };
            try {
                this.fusedLocationClient.requestLocationUpdates(request, this.locationCallback, Looper.getMainLooper());
                this.sharingLocation = true;
                this.btnToggleSharing.setText("Stop Sharing Location");
                Toast.makeText(this, "Sharing your live location with the customer", 0).show();
                this.fusedLocationClient.getLastLocation().addOnSuccessListener(new OnSuccessListener() { // from class: cyberorion.pk.TrackingActivity$$ExternalSyntheticLambda3
                    @Override // com.google.android.gms.tasks.OnSuccessListener
                    public final void onSuccess(Object obj) {
                        this.f$0.m481lambda$beginSharing$7$cyberorionpkTrackingActivity((Location) obj);
                    }
                });
            } catch (SecurityException e) {
                Toast.makeText(this, "Location permission is required to share your position", 1).show();
            }
        }
    }

    /* JADX INFO: renamed from: lambda$beginSharing$7$cyberorion-pk-TrackingActivity, reason: not valid java name */
    /* synthetic */ void m481lambda$beginSharing$7$cyberorionpkTrackingActivity(Location location) {
        if (location != null) {
            pushDriverLocation(location);
        }
    }

    private void stopSharing() {
        this.sharingLocation = false;
        this.btnToggleSharing.setText("Start Sharing Location");
        if (this.locationCallback != null) {
            this.fusedLocationClient.removeLocationUpdates(this.locationCallback);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void pushDriverLocation(Location location) {
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        Map<String, Object> position = new HashMap<>();
        position.put("lat", Double.valueOf(lat));
        position.put("lng", Double.valueOf(lng));
        position.put("accuracy", Float.valueOf(location.getAccuracy()));
        position.put("updatedAt", Long.valueOf(System.currentTimeMillis()));
        this.trackingRef.setValue(position);
        if (BookingKeys.ROLE_DRIVER.equals(this.role) && FirebaseAuth.getInstance().getCurrentUser() != null) {
            Map<String, Object> driverLocation = new HashMap<>();
            driverLocation.put("currentLat", Double.valueOf(lat));
            driverLocation.put("currentLng", Double.valueOf(lng));
            FirebaseDatabase.getInstance().getReference("drivers").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(driverLocation);
        }
    }

    @Override // com.google.android.gms.maps.OnMapReadyCallback
    public void onMapReady(GoogleMap map) {
        this.googleMap = map;
        if (this.pickupLat != null && this.dropoffLat != null) {
            drawRouteOnce();
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStart() {
        super.onStart();
        this.mapView.onStart();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        this.mapView.onResume();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        this.mapView.onPause();
        super.onPause();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onStop() {
        this.mapView.onStop();
        super.onStop();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onDestroy() {
        if (this.sharingLocation) {
            stopSharing();
        }
        this.mapView.onDestroy();
        super.onDestroy();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onLowMemory() {
        super.onLowMemory();
        this.mapView.onLowMemory();
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }
        this.mapView.onSaveInstanceState(mapViewBundle);
    }
}
