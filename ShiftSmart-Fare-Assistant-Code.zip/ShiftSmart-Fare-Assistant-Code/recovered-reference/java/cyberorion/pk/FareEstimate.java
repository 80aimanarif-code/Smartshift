package cyberorion.pk;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class FareEstimate implements Serializable {
    public final List<FareBreakdownItem> breakdown = new ArrayList();
    public double distanceKm;
    public int estimatedDurationMinutes;
    public double totalFare;

    public void add(String label, double amount) {
        if (amount <= 0.0d) {
            return;
        }
        this.breakdown.add(new FareBreakdownItem(label, amount));
        this.totalFare += amount;
    }

    public String durationLabel() {
        if (this.estimatedDurationMinutes < 60) {
            return this.estimatedDurationMinutes + " min";
        }
        int hrs = this.estimatedDurationMinutes / 60;
        int mins = this.estimatedDurationMinutes % 60;
        return (mins == 0 ? new StringBuilder().append(hrs).append(" hr") : new StringBuilder().append(hrs).append(" hr ").append(mins).append(" min")).toString();
    }
}
