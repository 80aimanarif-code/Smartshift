package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class Complaint {
    public String bookingId;
    public String complaintId;
    public String message;
    public String status;
    public String subject;
    public long timestamp;
    public String userEmail;
    public String userId;
}
