package cyberorion.pk;

import android.app.Activity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class AdminListUi {
    private AdminListUi() {
    }

    public static RecyclerView setup(final Activity activity, String title, final List<AdminRecordAdapter.Record> rows, AdminRecordAdapter.Listener l) {
        float density = activity.getResources().getDisplayMetrics().density;
        LinearLayout linearLayout = new LinearLayout(activity);
        linearLayout.setOrientation(1);
        linearLayout.setBackgroundColor(activity.getColor(R.color.background));
        LinearLayout linearLayout2 = new LinearLayout(activity);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setBackgroundResource(R.drawable.bg_gradient_primary);
        int hPad = (int) (density * 20.0f);
        linearLayout2.setPadding(hPad, hPad, hPad, hPad);
        linearLayout.addView(linearLayout2, new LinearLayout.LayoutParams(-1, -2));
        TextView back = new TextView(activity);
        back.setText("←");
        back.setTextColor(activity.getColor(R.color.white));
        back.setTextSize(20.0f);
        back.setPadding(0, 0, (int) (14.0f * density), 0);
        back.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.AdminListUi$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                activity.finish();
            }
        });
        linearLayout2.addView(back);
        LinearLayout titleBox = new LinearLayout(activity);
        titleBox.setOrientation(1);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
        linearLayout2.addView(titleBox, titleLp);
        TextView head = new TextView(activity);
        head.setText(title);
        head.setTextSize(19.0f);
        head.setTypeface(null, 1);
        head.setTextColor(activity.getColor(R.color.white));
        titleBox.addView(head);
        final TextView countLabel = new TextView(activity);
        countLabel.setTextSize(12.0f);
        countLabel.setTextColor(activity.getColor(R.color.brandMint));
        countLabel.setPadding(0, (int) (2.0f * density), 0, 0);
        titleBox.addView(countLabel);
        RecyclerView rv = new RecyclerView(activity);
        rv.setLayoutManager(new LinearLayoutManager(activity));
        rv.setClipToPadding(false);
        int listPad = (int) (16.0f * density);
        rv.setPadding(listPad, listPad, listPad, listPad);
        AdminRecordAdapter adapter = new AdminRecordAdapter(rows, l);
        rv.setAdapter(adapter);
        updateCountLabel(countLabel, rows.size());
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() { // from class: cyberorion.pk.AdminListUi.1
            private void refresh() {
                AdminListUi.updateCountLabel(countLabel, rows.size());
            }

            @Override // androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
            public void onChanged() {
                refresh();
            }

            @Override // androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
            public void onItemRangeInserted(int positionStart, int itemCount) {
                refresh();
            }

            @Override // androidx.recyclerview.widget.RecyclerView.AdapterDataObserver
            public void onItemRangeRemoved(int positionStart, int itemCount) {
                refresh();
            }
        });
        linearLayout.addView(rv, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        activity.setContentView(linearLayout);
        return rv;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static void updateCountLabel(TextView countLabel, int size) {
        countLabel.setText(size + (size == 1 ? " record" : " records"));
    }
}
