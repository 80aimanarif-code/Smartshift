package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class SosAlert {
    public static final String STATUS_ACTIVE = "active";
    public static final String STATUS_RESOLVED = "resolved";
    public String alertId;
    public String bookingId;
    public Double lat;
    public Double lng;
    public String message;
    public String raisedBy;
    public long resolvedAt;
    public String resolvedBy;
    public String role;
    public String status;
    public long timestamp;

    public SosAlert() {
    }

    public SosAlert(String bookingId, String raisedBy, String role, String message, Double lat, Double lng) {
        this.bookingId = bookingId;
        this.raisedBy = raisedBy;
        this.role = role;
        this.message = message;
        this.lat = lat;
        this.lng = lng;
        this.status = STATUS_ACTIVE;
        this.timestamp = System.currentTimeMillis();
    }
}
