package cyberorion.pk;

import android.os.Bundle;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class TrackOrderActivity extends AppCompatActivity {
    private BookingAdapter adapter;
    private List<Booking> bookingList;
    private LinearLayout emptyState;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private RecyclerView rvBookings;

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_track_order);
        this.mAuth = FirebaseAuth.getInstance();
        this.mDatabase = FirebaseDatabase.getInstance().getReference().child("bookings");
        this.rvBookings = (RecyclerView) findViewById(R.id.rvBookings);
        this.emptyState = (LinearLayout) findViewById(R.id.emptyState);
        this.rvBookings.setLayoutManager(new LinearLayoutManager(this));
        this.bookingList = new ArrayList();
        this.adapter = new BookingAdapter(this.bookingList);
        this.rvBookings.setAdapter(this.adapter);
        fetchBookings();
    }

    private void fetchBookings() {
        if (this.mAuth.getCurrentUser() == null) {
            showEmptyState(true);
        } else {
            String userId = this.mAuth.getCurrentUser().getUid();
            this.mDatabase.orderByChild("userId").equalTo(userId).addValueEventListener(new ValueEventListener() { // from class: cyberorion.pk.TrackOrderActivity.1
                @Override // com.google.firebase.database.ValueEventListener
                public void onDataChange(DataSnapshot snapshot) {
                    TrackOrderActivity.this.bookingList.clear();
                    for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                        Booking booking = (Booking) postSnapshot.getValue(Booking.class);
                        if (booking != null) {
                            booking.bookingId = postSnapshot.getKey();
                            TrackOrderActivity.this.bookingList.add(booking);
                        }
                    }
                    Collections.sort(TrackOrderActivity.this.bookingList, new Comparator<Booking>() { // from class: cyberorion.pk.TrackOrderActivity.1.1
                        @Override // java.util.Comparator
                        public int compare(Booking a, Booking b) {
                            return Long.compare(b.timestamp, a.timestamp);
                        }
                    });
                    TrackOrderActivity.this.adapter.notifyDataSetChanged();
                    TrackOrderActivity.this.showEmptyState(TrackOrderActivity.this.bookingList.isEmpty());
                }

                @Override // com.google.firebase.database.ValueEventListener
                public void onCancelled(DatabaseError error) {
                    TrackOrderActivity.this.showEmptyState(TrackOrderActivity.this.bookingList.isEmpty());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showEmptyState(boolean show) {
        this.emptyState.setVisibility(show ? 0 : 8);
        this.rvBookings.setVisibility(show ? 8 : 0);
    }
}
