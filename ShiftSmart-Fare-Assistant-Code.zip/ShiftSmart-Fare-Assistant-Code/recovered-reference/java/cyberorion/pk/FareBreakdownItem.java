package cyberorion.pk;

import java.io.Serializable;

/* JADX INFO: loaded from: classes3.dex */
public class FareBreakdownItem implements Serializable {
    public final double amount;
    public final String label;

    public FareBreakdownItem(String label, double amount) {
        this.label = label;
        this.amount = amount;
    }
}
