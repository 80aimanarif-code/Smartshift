package cyberorion.pk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public final class CargoCatalog {
    private static final List<CargoCategory> PERSONAL_CATEGORIES = Collections.unmodifiableList(new ArrayList<CargoCategory>() { // from class: cyberorion.pk.CargoCatalog.1
        {
            add(new CargoCategory("small_items", "Small Items", "Documents, small boxes up to 5kg", R.drawable.ic_box_small, 5.0d, false, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("medium_luggage", "Medium Luggage", "Suitcases and bags, 5kg - 20kg", R.drawable.ic_box_medium, 20.0d, false, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("heavy_items", "Heavy Items", "Bulky household items, 20kg+", R.drawable.ic_box_heavy, 60.0d, false, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("fragile_items", "Fragile Items", "Needs careful handling in transit", R.drawable.ic_fragile, 15.0d, true, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("furniture", "Furniture", "Sofas, beds, tables, wardrobes", R.drawable.ic_furniture, 120.0d, false, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("electronics", "Electronics", "TVs, computers, home appliances", R.drawable.ic_electronics, 25.0d, true, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("glass_items", "Glass Items", "Mirrors, glass tables, decor", R.drawable.ic_glass, 20.0d, true, ShiftingType.CargoGroup.PERSONAL));
            add(new CargoCategory("appliances", "Appliances", "Fridges, washing machines, ovens", R.drawable.ic_appliance, 80.0d, false, ShiftingType.CargoGroup.PERSONAL));
        }
    });
    private static final List<CargoCategory> LOGISTICS_CATEGORIES = Collections.unmodifiableList(new ArrayList<CargoCategory>() { // from class: cyberorion.pk.CargoCatalog.2
        {
            add(new CargoCategory("raw_materials", "Raw Materials", "Unprocessed inputs for manufacturing", R.drawable.ic_raw_materials, 1500.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("finished_goods", "Finished Goods", "Packaged products ready for distribution", R.drawable.ic_package, 1000.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("bulk_cargo", "Bulk Cargo", "Loose, unpackaged cargo in large volume", R.drawable.ic_bulk_cargo, 2500.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("palletized_cargo", "Palletized Cargo", "Goods stacked and wrapped on pallets", R.drawable.ic_pallet, 1200.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("heavy_machinery", "Heavy Machinery", "Industrial machines, generators, engines", R.drawable.ic_machinery, 3000.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("industrial_equipment", "Industrial Equipment", "Tools and equipment for factory use", R.drawable.ic_industrial_equipment, 800.0d, false, ShiftingType.CargoGroup.LOGISTICS));
            add(new CargoCategory("fragile_industrial_equipment", "Fragile Industrial Equipment", "Sensitive instruments needing extra care", R.drawable.ic_industrial_equipment, 500.0d, true, ShiftingType.CargoGroup.LOGISTICS));
        }
    });

    private CargoCatalog() {
    }

    public static List<CargoCategory> forGroup(ShiftingType.CargoGroup group) {
        return group == ShiftingType.CargoGroup.LOGISTICS ? LOGISTICS_CATEGORIES : PERSONAL_CATEGORIES;
    }

    public static CargoCategory findById(String id) {
        if (id == null) {
            return null;
        }
        for (CargoCategory category : PERSONAL_CATEGORIES) {
            if (category.id.equals(id)) {
                return category;
            }
        }
        for (CargoCategory category2 : LOGISTICS_CATEGORIES) {
            if (category2.id.equals(id)) {
                return category2;
            }
        }
        return null;
    }
}
