package cyberorion.pk;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class NotificationAdapter extends RecyclerView.Adapter<NotificationViewHolder> {
    private final OnNotificationClickListener listener;
    private final List<AppNotification> notifications;

    public interface OnNotificationClickListener {
        void onClick(AppNotification appNotification);
    }

    public NotificationAdapter(List<AppNotification> notifications, OnNotificationClickListener listener) {
        this.notifications = notifications;
        this.listener = listener;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public NotificationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false);
        return new NotificationViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(NotificationViewHolder holder, int position) {
        final AppNotification n = this.notifications.get(position);
        holder.tvTitle.setText(n.title);
        holder.tvMessage.setText(n.message);
        holder.tvTime.setText(DateFormat.getDateTimeInstance(3, 3).format(new Date(n.timestamp)));
        holder.unreadDot.setVisibility(n.read ? 4 : 0);
        holder.itemView.setAlpha(n.read ? 0.6f : 1.0f);
        holder.itemView.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.NotificationAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.m430lambda$onBindViewHolder$0$cyberorionpkNotificationAdapter(n, view);
            }
        });
    }

    /* JADX INFO: renamed from: lambda$onBindViewHolder$0$cyberorion-pk-NotificationAdapter, reason: not valid java name */
    /* synthetic */ void m430lambda$onBindViewHolder$0$cyberorionpkNotificationAdapter(AppNotification n, View v) {
        this.listener.onClick(n);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.notifications.size();
    }

    static class NotificationViewHolder extends RecyclerView.ViewHolder {
        TextView tvMessage;
        TextView tvTime;
        TextView tvTitle;
        View unreadDot;

        NotificationViewHolder(View itemView) {
            super(itemView);
            this.tvTitle = (TextView) itemView.findViewById(R.id.tvNotifTitle);
            this.tvMessage = (TextView) itemView.findViewById(R.id.tvNotifMessage);
            this.tvTime = (TextView) itemView.findViewById(R.id.tvNotifTime);
            this.unreadDot = itemView.findViewById(R.id.viewUnreadDot);
        }
    }
}
