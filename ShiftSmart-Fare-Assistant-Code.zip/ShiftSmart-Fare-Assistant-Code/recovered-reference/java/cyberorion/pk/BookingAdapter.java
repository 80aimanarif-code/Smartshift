package cyberorion.pk;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;

/* JADX INFO: loaded from: classes3.dex */
public class BookingAdapter extends RecyclerView.Adapter<BookingViewHolder> {
    private final List<Booking> bookingList;

    public BookingAdapter(List<Booking> bookingList) {
        this.bookingList = bookingList;
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public BookingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_booking, parent, false);
        return new BookingViewHolder(view);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public void onBindViewHolder(final BookingViewHolder holder, int position) {
        String driverText;
        final Booking booking = this.bookingList.get(position);
        holder.tvRoute.setText(holder.itemView.getContext().getString(R.string.route_format, booking.pickup, booking.dropoff));
        String cargoLabel = (booking.cargoCategoryName == null || booking.cargoCategoryName.isEmpty()) ? booking.luggageType : booking.cargoCategoryName;
        holder.tvDetails.setText(holder.itemView.getContext().getString(R.string.details_format, cargoLabel, booking.vehicleType));
        if (booking.driverName != null && !booking.driverName.isEmpty()) {
            driverText = holder.itemView.getContext().getString(R.string.driver_line_format, booking.driverName);
        } else {
            driverText = holder.itemView.getContext().getString(R.string.driver_not_assigned);
        }
        holder.tvDriver.setText(driverText);
        holder.tvStatus.setText(holder.itemView.getContext().getString(R.string.status_label, booking.status != null ? booking.status : "Pending"));
        holder.btnTrack.setOnClickListener(new View.OnClickListener() { // from class: cyberorion.pk.BookingAdapter$$ExternalSyntheticLambda0
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                BookingAdapter.lambda$onBindViewHolder$0(holder, booking, view);
            }
        });
    }

    static /* synthetic */ void lambda$onBindViewHolder$0(BookingViewHolder holder, Booking booking, View v) {
        Intent intent = new Intent(holder.itemView.getContext(), (Class<?>) TrackingActivity.class);
        intent.putExtra(BookingKeys.EXTRA_BOOKING_ID, booking.bookingId);
        intent.putExtra(BookingKeys.EXTRA_ROLE, BookingKeys.ROLE_CUSTOMER);
        holder.itemView.getContext().startActivity(intent);
    }

    @Override // androidx.recyclerview.widget.RecyclerView.Adapter
    public int getItemCount() {
        return this.bookingList.size();
    }

    static class BookingViewHolder extends RecyclerView.ViewHolder {
        MaterialButton btnTrack;
        TextView tvDetails;
        TextView tvDriver;
        TextView tvRoute;
        TextView tvStatus;

        BookingViewHolder(View itemView) {
            super(itemView);
            this.tvRoute = (TextView) itemView.findViewById(R.id.tvBookingRoute);
            this.tvDetails = (TextView) itemView.findViewById(R.id.tvBookingDetails);
            this.tvDriver = (TextView) itemView.findViewById(R.id.tvBookingDriver);
            this.tvStatus = (TextView) itemView.findViewById(R.id.tvBookingStatus);
            this.btnTrack = (MaterialButton) itemView.findViewById(R.id.btnTrackBooking);
        }
    }
}
