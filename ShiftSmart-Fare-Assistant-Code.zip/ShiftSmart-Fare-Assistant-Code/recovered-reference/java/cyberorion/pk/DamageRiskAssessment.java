package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public class DamageRiskAssessment {
    public final String level;
    public final String reason;
    public final String recommendation;
    public final int score;

    public DamageRiskAssessment(int score, String level, String recommendation, String reason) {
        this.score = score;
        this.level = level;
        this.recommendation = recommendation;
        this.reason = reason;
    }
}
