package cyberorion.pk;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/* JADX INFO: loaded from: classes3.dex */
public final class NocPolicy {
    public static final double DEFAULT_DISTANCE_THRESHOLD_KM = 100.0d;
    public static final double DEFAULT_HEAVY_WEIGHT_THRESHOLD_KG = 100.0d;
    private static final Set<String> HEAVY_CATEGORY_IDS = new HashSet<String>() { // from class: cyberorion.pk.NocPolicy.1
        {
            add("heavy_items");
            add("heavy_machinery");
        }
    };

    private NocPolicy() {
    }

    public static NocRequirement evaluate(CargoSelection cargo, Double distanceKm) {
        return evaluate(cargo, distanceKm, 100.0d, 100.0d);
    }

    public static NocRequirement evaluate(CargoSelection cargo, Double distanceKm, double distanceThresholdKm, double heavyWeightThresholdKg) {
        List<NocReason> reasons = new ArrayList<>();
        if (distanceKm != null && distanceKm.doubleValue() > distanceThresholdKm) {
            reasons.add(NocReason.LONG_DISTANCE);
        }
        if (cargo != null) {
            boolean isLogisticsCargo = false;
            boolean heavyByCategory = cargo.cargoCategoryId != null && HEAVY_CATEGORY_IDS.contains(cargo.cargoCategoryId);
            boolean heavyByWeight = cargo.weightKg > heavyWeightThresholdKg;
            if (heavyByCategory || heavyByWeight) {
                reasons.add(NocReason.HEAVY_CARGO);
            }
            if (cargo.fragile) {
                reasons.add(NocReason.FRAGILE_CARGO);
            }
            CargoCategory category = CargoCatalog.findById(cargo.cargoCategoryId);
            if (category != null && category.group == ShiftingType.CargoGroup.LOGISTICS) {
                isLogisticsCargo = true;
            }
            if (isLogisticsCargo) {
                reasons.add(NocReason.INDUSTRIAL_CARGO);
            }
        }
        return new NocRequirement(true ^ reasons.isEmpty(), reasons);
    }

    public enum NocReason {
        LONG_DISTANCE("Long-distance route"),
        HEAVY_CARGO("Heavy cargo"),
        FRAGILE_CARGO("Fragile cargo"),
        INDUSTRIAL_CARGO("Factory / industrial cargo");

        public final String label;

        NocReason(String label) {
            this.label = label;
        }
    }

    public static final class NocRequirement {
        public final List<NocReason> reasons;
        public final boolean required;

        private NocRequirement(boolean required, List<NocReason> reasons) {
            this.required = required;
            this.reasons = reasons;
        }

        public String reasonSummary() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < this.reasons.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(this.reasons.get(i).label);
            }
            return sb.toString();
        }
    }
}
