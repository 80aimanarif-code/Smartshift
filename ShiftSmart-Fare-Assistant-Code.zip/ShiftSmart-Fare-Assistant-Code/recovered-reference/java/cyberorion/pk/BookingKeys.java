package cyberorion.pk;

/* JADX INFO: loaded from: classes3.dex */
public final class BookingKeys {
    public static final String EXTRA_AI_FARE = "extra_ai_fare";
    public static final String EXTRA_BOOKING_ID = "extra_booking_id";
    public static final String EXTRA_CARGO_CATEGORY_ID = "extra_cargo_category_id";
    public static final String EXTRA_CARGO_SELECTION = "extra_cargo_selection";
    public static final String EXTRA_DAMAGE_STAGE = "extra_damage_stage";
    public static final String EXTRA_DISTANCE_KM = "extra_distance_km";
    public static final String EXTRA_DRIVER_ID = "extra_driver_id";
    public static final String EXTRA_DRIVER_NAME = "extra_driver_name";
    public static final String EXTRA_DROPOFF = "extra_dropoff";
    public static final String EXTRA_DROPOFF_LAT = "extra_dropoff_lat";
    public static final String EXTRA_DROPOFF_LNG = "extra_dropoff_lng";
    public static final String EXTRA_ESTIMATED_DURATION_MIN = "extra_estimated_duration_min";
    public static final String EXTRA_ESTIMATED_FARE = "extra_estimated_fare";
    public static final String EXTRA_LUGGAGE_TYPE = "extra_luggage_type";
    public static final String EXTRA_PICKUP = "extra_pickup";
    public static final String EXTRA_PICKUP_LAT = "extra_pickup_lat";
    public static final String EXTRA_PICKUP_LNG = "extra_pickup_lng";
    public static final String EXTRA_RECOMMENDED_VEHICLE_ID = "extra_recommended_vehicle_id";
    public static final String EXTRA_RECOMMENDED_VEHICLE_NAME = "extra_recommended_vehicle_name";
    public static final String EXTRA_ROLE = "extra_role";
    public static final String EXTRA_SHIFTING_TYPE = "extra_shifting_type";
    public static final String EXTRA_VEHICLE_CAPACITY = "extra_vehicle_capacity";
    public static final String EXTRA_VEHICLE_NUMBER = "extra_vehicle_number";
    public static final String EXTRA_VEHICLE_TYPE = "extra_vehicle_type";
    public static final String ROLE_CUSTOMER = "customer";
    public static final String ROLE_DRIVER = "driver";

    private BookingKeys() {
    }
}
