package cyberorion.pk.features;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.Transaction;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Changes one booking atomically. Existing route, cargo and AI fields are left intact. */
public final class BookingServices {
    // FYP sample tariff, in paisa. Keep these values in sync with the supplied rules.
    public static final long PACKING_RATE = 50000;
    public static final long UNPACKING_RATE = 30000;
    public static final long EXTRA_KM_RATE = 6000;
    public static final int MAX_PHOTO_LENGTH = 240000;
    private final DatabaseReference booking;

    public interface Callback { void complete(String error); }
    private interface Change { void apply(MutableData data, String uid); }

    public BookingServices(String bookingId) {
        if (bookingId == null || !bookingId.matches("[A-Za-z0-9_-]{1,128}")) {
            throw new IllegalArgumentException("Invalid booking reference.");
        }
        booking = FirebaseDatabase.getInstance().getReference("bookings").child(bookingId);
    }

    public DatabaseReference reference() { return booking; }

    public void agreeFare(final double rupees, Callback callback) {
        final long base = toPaisa(rupees);
        change((data, uid) -> {
            if (!uid.equals(text(data, "userId")) && !uid.equals(text(data, "driverId"))) {
                throw new IllegalStateException("You are not part of this booking.");
            }
            if (!"Pending".equals(text(data, "status"))) {
                throw new IllegalStateException("Fare changes are allowed before the trip is accepted.");
            }
            Object savedFee = data.child("serviceExtras/feePaisa").getValue();
            long fee = savedFee instanceof Number ? ((Number) savedFee).longValue() : 0;
            Object stopFee = data.child("serviceExtras/stopsFeePaisa").getValue();
            fee = FeatureRules.total(fee, stopFee instanceof Number ? ((Number) stopFee).longValue() : 0);
            long total = FeatureRules.total(base, fee);
            data.child("negotiatedFare").setValue(rupees);
            data.child("finalFare").setValue(total / 100.0);
            data.child("serviceExtras/baseFarePaisa").setValue(base);
            data.child("serviceExtras/totalPaisa").setValue(total);
            data.child("status").setValue("Accepted");
        }, callback);
    }

    public void savePacking(final boolean packing, final boolean unpacking,
                            final int workers, Callback callback) {
        final long charge = FeatureRules.packingCharge(packing, unpacking, workers,
                PACKING_RATE, UNPACKING_RATE);
        change((data, uid) -> {
            requireCustomer(data, uid);
            if (!"Pending".equals(text(data, "status"))) {
                throw new IllegalStateException("Packing can be changed while the booking is pending.");
            }
            MutableData extras = data.child("serviceExtras");
            long base = baseFare(data);
            Object stopFee = extras.child("stopsFeePaisa").getValue();
            long total = FeatureRules.total(base, FeatureRules.total(charge, stopFee instanceof Number ? ((Number) stopFee).longValue() : 0));
            extras.child("baseFarePaisa").setValue(base);
            extras.child("packing").setValue(packing);
            extras.child("unpacking").setValue(unpacking);
            extras.child("workers").setValue(workers);
            extras.child("feePaisa").setValue(charge);
            extras.child("totalPaisa").setValue(total);
            extras.child("serviceStatus").setValue(packing || unpacking ? "Requested" : "Not required");
            extras.child("payment/status").setValue("pending");
            data.child("finalFare").setValue(total / 100.0);
        }, callback);
    }

    public void selectPayment(final String method, Callback callback) {
        final String safeMethod = FeatureRules.cleanPaymentMethod(method);
        change((data, uid) -> {
            requireCustomer(data, uid);
            requireLive(data);
            if ("paid".equals(text(data, "serviceExtras/payment/status"))) {
                throw new IllegalStateException("Payment is already recorded.");
            }
            data.child("serviceExtras/payment/method").setValue(safeMethod);
            data.child("serviceExtras/payment/status").setValue("pending");
            data.child("serviceExtras/payment/selectedAt").setValue(ServerValue.TIMESTAMP);
        }, callback);
    }

    public void schedule(final Long pickupTime, Callback callback) {
        if (pickupTime != null) FeatureRules.checkSchedule(pickupTime, System.currentTimeMillis());
        change((data, uid) -> {
            requireCustomer(data, uid);
            if (!"Pending".equals(text(data, "status"))) throw new IllegalStateException("Reschedule before the driver accepts the booking.");
            if (pickupTime != null) FeatureRules.checkSchedule(pickupTime, System.currentTimeMillis());
            data.child("serviceExtras/scheduledPickupAt").setValue(pickupTime);
            data.child("serviceExtras/scheduleUpdatedAt").setValue(ServerValue.TIMESTAMP);
        }, callback);
    }

    public void saveStops(java.util.List<String> addresses, final double extraDistanceKm, Callback callback) {
        final java.util.List<String> stops = FeatureRules.cleanStops(addresses);
        final long distanceFee = FeatureRules.distanceCharge(extraDistanceKm, EXTRA_KM_RATE);
        change((data, uid) -> {
            requireCustomer(data, uid);
            if (!"Pending".equals(text(data, "status"))) throw new IllegalStateException("Change stops before the driver accepts the booking.");
            for (String stop : stops) {
                if (stop.equalsIgnoreCase(text(data, "pickup").trim()) || stop.equalsIgnoreCase(text(data, "dropoff").trim())) {
                    throw new IllegalArgumentException("An extra stop must differ from the pickup and final drop-off.");
                }
            }
            MutableData extras = data.child("serviceExtras");
            long base = baseFare(data);
            Object packingFee = extras.child("feePaisa").getValue();
            long packing = packingFee instanceof Number ? ((Number) packingFee).longValue() : 0;
            long fee = distanceFee;
            long total = FeatureRules.total(base, FeatureRules.total(packing, fee));
            extras.child("baseFarePaisa").setValue(base);
            extras.child("stops").setValue(stops.isEmpty() ? null : stops);
            extras.child("stopsFeePaisa").setValue(fee);
            extras.child("extraDistanceKm").setValue(extraDistanceKm);
            extras.child("extraKmRatePaisa").setValue(EXTRA_KM_RATE);
            extras.child("totalPaisa").setValue(total);
            extras.child("nextStop").setValue(0);
            data.child("finalFare").setValue(total / 100.0);
        }, callback);
    }

    public void completeNextStop(final int expectedIndex, Callback callback) {
        change((data, uid) -> {
            requireDriver(data, uid);
            if (!"Out for Delivery".equals(text(data, "status"))) throw new IllegalStateException("Start delivery before completing stops.");
            Object current = data.child("serviceExtras/nextStop").getValue();
            int index = current instanceof Number ? ((Number) current).intValue() : 0;
            long count = data.child("serviceExtras/stops").getChildrenCount();
            if (index != expectedIndex || index >= count) throw new IllegalStateException("Stop status changed. Refresh the booking.");
            data.child("serviceExtras/nextStop").setValue(index + 1);
            data.child("serviceExtras/stopCompletedAt/" + index).setValue(ServerValue.TIMESTAMP);
        }, callback);
    }

    public void recordCash(final long expectedAmount, Callback callback) {
        change((data, uid) -> {
            requireDriver(data, uid);
            if (!"cash".equals(text(data, "serviceExtras/payment/method"))) {
                throw new IllegalStateException("The customer must select cash first.");
            }
            long due = totalFare(data);
            FeatureRules.checkCashReceipt("Completed".equals(text(data, "status")),
                    "paid".equals(text(data, "serviceExtras/payment/status")), due, expectedAmount);
            MutableData payment = data.child("serviceExtras/payment");
            payment.child("status").setValue("paid");
            payment.child("amountPaisa").setValue(due);
            payment.child("receivedBy").setValue(uid);
            payment.child("receivedAt").setValue(ServerValue.TIMESTAMP);
            payment.child("receiptId").setValue("CASH-" + booking.getKey());
        }, callback);
    }

    public void advanceService(Callback callback) {
        change((data, uid) -> {
            requireDriver(data, uid);
            requireLive(data);
            String bookingStatus = text(data, "status");
            if ("Pending".equals(bookingStatus) || "Completed".equals(bookingStatus)) {
                throw new IllegalStateException("Service updates are available during the accepted trip.");
            }
            String stage = text(data, "serviceExtras/serviceStatus");
            String next;
            if ("Requested".equals(stage)) next = "In progress";
            else if ("In progress".equals(stage)) next = "Completed";
            else throw new IllegalStateException("There is no pending packing service.");
            data.child("serviceExtras/serviceStatus").setValue(next);
        }, callback);
    }

    public void submitProof(final String photo, final String recipient, Callback callback) {
        FeatureRules.checkProof(photo, recipient, true);
        if (photo.length() > MAX_PHOTO_LENGTH) throw new IllegalArgumentException("Choose a smaller photo.");
        change((data, uid) -> {
            requireDriver(data, uid);
            String status = text(data, "status");
            if (!"Out for Delivery".equals(status) && !"Delivered".equals(status)) {
                throw new IllegalStateException("Delivery proof is available at the delivery stage.");
            }
            if (!text(data, "serviceExtras/proof/confirmedBy").isEmpty()) {
                throw new IllegalStateException("The customer already confirmed this delivery.");
            }
            Object nextStop = data.child("serviceExtras/nextStop").getValue();
            long completedStops = nextStop instanceof Number ? ((Number) nextStop).longValue() : 0;
            if (completedStops < data.child("serviceExtras/stops").getChildrenCount()) {
                throw new IllegalStateException("Complete the extra stops before the final delivery.");
            }
            MutableData proof = data.child("serviceExtras/proof");
            proof.child("photoBase64").setValue(photo);
            proof.child("recipientName").setValue(recipient.trim());
            proof.child("submittedBy").setValue(uid);
            proof.child("submittedAt").setValue(ServerValue.TIMESTAMP);
            data.child("deliveredAt").setValue(ServerValue.TIMESTAMP);
            data.child("status").setValue("Delivered");
        }, callback);
    }

    public void confirmDelivery(Callback callback) {
        change((data, uid) -> {
            requireCustomer(data, uid);
            if (!"Delivered".equals(text(data, "status"))) {
                throw new IllegalStateException("Wait for the driver to submit delivery proof.");
            }
            FeatureRules.checkProof(text(data, "serviceExtras/proof/photoBase64"),
                    text(data, "serviceExtras/proof/recipientName"), true);
            String service = text(data, "serviceExtras/serviceStatus");
            if ("Requested".equals(service) || "In progress".equals(service)) {
                throw new IllegalStateException("The driver must complete the selected services first.");
            }
            data.child("serviceExtras/proof/confirmedBy").setValue(uid);
            data.child("serviceExtras/proof/confirmedAt").setValue(ServerValue.TIMESTAMP);
            data.child("completedAt").setValue(ServerValue.TIMESTAMP);
            data.child("status").setValue("Completed");
        }, callback);
    }

    public void review(final int stars, final String comment, Callback callback) {
        change((data, uid) -> {
            requireCustomer(data, uid);
            FeatureRules.checkRating("Completed".equals(text(data, "status")),
                    data.child("serviceExtras/review").getValue() != null, stars, comment);
            String driver = text(data, "driverId");
            if (driver.isEmpty()) throw new IllegalStateException("This booking has no assigned driver.");
            MutableData review = data.child("serviceExtras/review");
            review.child("stars").setValue(stars);
            review.child("comment").setValue(comment == null ? "" : comment.trim());
            review.child("customerId").setValue(uid);
            review.child("driverId").setValue(driver);
            review.child("createdAt").setValue(ServerValue.TIMESTAMP);
        }, callback);
    }

    private void change(final Change change, final Callback callback) {
        final String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { callback.complete("Please sign in again."); return; }
        booking.runTransaction(new Transaction.Handler() {
            String problem;
            public Transaction.Result doTransaction(MutableData data) {
                problem = null;
                // Firebase can first invoke a transaction with an empty local cache.
                if (data.getValue() == null) return Transaction.success(data);
                try {
                    change.apply(data, uid);
                    data.child("serviceExtras/schemaVersion").setValue(1);
                    data.child("updatedAt").setValue(ServerValue.TIMESTAMP);
                    return Transaction.success(data);
                } catch (IllegalArgumentException | IllegalStateException | ArithmeticException e) {
                    problem = e.getMessage();
                    return Transaction.abort();
                }
            }
            public void onComplete(DatabaseError error, boolean committed, DataSnapshot snapshot) {
                if (error != null) callback.complete("Could not save: " + error.getMessage());
                else if (!committed) callback.complete(problem == null ? "Booking changed. Refresh and try again." : problem);
                else if (snapshot == null || !snapshot.exists()) callback.complete("Booking no longer exists.");
                else callback.complete(null);
            }
        }, false);
    }

    private static void requireCustomer(MutableData data, String uid) {
        if (!uid.equals(text(data, "userId"))) throw new IllegalStateException("Only this booking's customer can do that.");
    }
    private static void requireDriver(MutableData data, String uid) {
        if (!uid.equals(text(data, "driverId"))) throw new IllegalStateException("Only the assigned driver can do that.");
    }
    private static void requireLive(MutableData data) {
        String status = text(data, "status");
        if ("Cancelled".equals(status) || "Rejected".equals(status)) throw new IllegalStateException("This booking is closed.");
    }
    private static String text(MutableData data, String path) {
        Object value = data.child(path).getValue();
        return value == null ? "" : String.valueOf(value);
    }
    private static long baseFare(MutableData data) {
        Object saved = data.child("serviceExtras/baseFarePaisa").getValue();
        if (saved instanceof Number) return ((Number) saved).longValue();
        return totalFare(data);
    }
    private static long totalFare(MutableData data) {
        Object value = data.child("finalFare").getValue();
        if (value == null) value = data.child("negotiatedFare").getValue();
        if (value == null) value = data.child("estimatedFare").getValue();
        return toPaisa(value);
    }
    public static long toPaisa(Object value) {
        if (!(value instanceof Number)) throw new IllegalArgumentException("Booking fare is missing.");
        long result = new BigDecimal(value.toString()).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValueExact();
        if (result < 0) throw new IllegalArgumentException("Invalid booking fare.");
        return result;
    }
}
