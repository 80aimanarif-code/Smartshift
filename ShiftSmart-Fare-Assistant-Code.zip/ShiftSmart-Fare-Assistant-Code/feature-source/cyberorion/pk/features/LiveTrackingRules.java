package cyberorion.pk.features;

/** Android-independent rules used by the live tracking screen. */
public final class LiveTrackingRules {
    private LiveTrackingRules() { }

    public static boolean routeToDropoff(String status) {
        return "Picked Up".equals(status) || "Out for Delivery".equals(status)
                || "Delivered".equals(status) || "Completed".equals(status);
    }

    public static long remainingMinutes(double durationSeconds) {
        if (durationSeconds < 0 || !Double.isFinite(durationSeconds)) {
            throw new IllegalArgumentException("Invalid route duration");
        }
        return Math.max(1, (long) Math.ceil(durationSeconds / 60.0));
    }

    public static long arrivalAt(long now, long minutes) {
        if (now < 0 || minutes < 1 || minutes > 10080) {
            throw new IllegalArgumentException("Invalid arrival estimate");
        }
        return Math.addExact(now, Math.multiplyExact(minutes, 60000L));
    }

    public static String proximity(double distanceKm) {
        if (distanceKm < 0 || !Double.isFinite(distanceKm)) {
            throw new IllegalArgumentException("Invalid remaining distance");
        }
        if (distanceKm < 1) return "Truck is very near";
        if (distanceKm < 5) return "Truck is near";
        return String.format(java.util.Locale.getDefault(), "Truck is %.1f km away", distanceKm);
    }

    public static boolean locationDelayed(long now, long updatedAt) {
        return updatedAt > 0 && now - updatedAt > 120000L;
    }
}
