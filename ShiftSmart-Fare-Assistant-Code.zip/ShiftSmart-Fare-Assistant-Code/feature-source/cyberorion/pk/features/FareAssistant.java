package cyberorion.pk.features;

import android.app.Activity;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.lang.reflect.Field;
import java.util.List;

/** Only attached to NegotiationActivity. Does not write bookings or generate driver offers. */
public final class FareAssistant {
    private static final String TAG = "shiftsmart-fare-assistant";
    private FareAssistant() { }

    public static void attach(Activity page) {
        if (state(page) != null) return;
        TextView reference = page.findViewById(id(page, "tvAiFareReference"));
        EditText input = page.findViewById(id(page, "etOfferAmount"));
        if (reference == null || input == null || !(reference.getParent() instanceof LinearLayout)) return;
        LinearLayout header = (LinearLayout) reference.getParent();
        LinearLayout panel = new LinearLayout(page);
        panel.setTag(TAG);
        panel.setOrientation(LinearLayout.VERTICAL);
        TextView response = new TextView(page);
        response.setTextSize(13);
        response.setTextColor(Color.rgb(22, 59, 42));
        response.setPadding(0, dp(page, 8), 0, 0);
        panel.addView(response, new LinearLayout.LayoutParams(-1, -2));
        Button check = new Button(page);
        check.setText("How much can I reduce?");
        check.setAllCaps(false);
        check.setTextSize(13);
        check.setMinHeight(dp(page, 48));
        panel.addView(check, new LinearLayout.LayoutParams(-1, -2));
        header.addView(panel, new LinearLayout.LayoutParams(-1, -2));
        State state = new State(page, input, response);
        response.setTag(state);
        input.setHint("Base fare offer (Rs.)");
        state.watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            public void afterTextChanged(Editable text) { state.render(false); }
        };
        input.addTextChangedListener(state.watcher);
        check.setOnClickListener(v -> state.render(true));
        state.render(true);
        String bookingId = page.getIntent().getStringExtra("extra_booking_id");
        if (bookingId == null || bookingId.isEmpty()) return;
        state.booking = FirebaseDatabase.getInstance().getReference("bookings").child(bookingId);
        state.listener = new ValueEventListener() {
            public void onDataChange(DataSnapshot booking) {
                if (page.isDestroyed()) return;
                state.ready = false;
                try {
                    Object fare = booking.child("estimatedFare").getValue();
                    // Use the original estimate, never a previous negotiated fare, to stop repeated discounts.
                    double estimated = fare instanceof Number ? ((Number) fare).doubleValue()
                            : page.getIntent().getDoubleExtra("extra_ai_fare", 0);
                    state.base = FareLimitRules.paisa(estimated);
                    state.extras = Math.addExact(charge(booking, "serviceExtras/feePaisa"),
                            charge(booking, "serviceExtras/stopsFeePaisa"));
                    FareLimitRules.total(state.base, state.extras);
                    if (!booking.exists()) throw new IllegalArgumentException("Booking not found.");
                    state.ready = true;
                    state.problem = null;
                } catch (RuntimeException e) {
                    state.problem = "Fare could not be verified. Reopen this booking to try again.";
                }
                state.render(false);
            }
            public void onCancelled(DatabaseError error) {
                if (page.isDestroyed()) return;
                state.ready = false;
                state.problem = "Fare could not be verified. Check your connection and reopen this booking.";
                state.render(false);
            }
        };
        state.booking.addValueEventListener(state.listener);
    }

    /** true means the existing send/accept action must stop before its Firebase write. */
    public static boolean block(Activity page, String type) {
        if ("reject".equals(type)) return false;
        State state = state(page);
        if (state == null) {
            Toast.makeText(page, "Fare assistant could not load. Reopen this booking.", Toast.LENGTH_LONG).show();
            return true;
        }
        if (closed(page)) { state.say("Negotiation is complete. The agreed fare is saved."); return true; }
        if (!state.ready) { state.render(false); return true; }
        try {
            long amount;
            if ("offer".equals(type)) {
                amount = FareLimitRules.offer(state.input.getText().toString());
            } else if ("accept".equals(type)) {
                Object value = field(page, "offers");
                if (!(value instanceof List)) throw new IllegalArgumentException();
                List<?> offers = (List<?>) value;
                if (offers.isEmpty()) throw new IllegalArgumentException();
                Object latest = offers.get(offers.size() - 1);
                Field amountField = latest.getClass().getField("amount");
                amount = FareLimitRules.paisa(((Number) amountField.get(latest)).doubleValue());
            } else return false;
            if (!FareLimitRules.allowed(amount, state.base)) { state.low(); return true; }
            if ("offer".equals(type)) state.valid(amount);
            return false;
        } catch (Exception e) {
            state.say("Enter a valid positive fare with no more than two decimal places.");
            return true;
        }
    }

    public static void refresh(Activity page) {
        State state = state(page);
        if (state != null) page.getWindow().getDecorView().post(() -> state.render(false));
    }

    public static void detach(Activity page) {
        State state = state(page);
        if (state == null) return;
        if (state.booking != null && state.listener != null) state.booking.removeEventListener(state.listener);
        if (state.watcher != null) state.input.removeTextChangedListener(state.watcher);
    }

    private static State state(Activity page) {
        View found = page.getWindow().getDecorView().findViewWithTag(TAG);
        if (!(found instanceof LinearLayout)) return null;
        Object value = ((LinearLayout) found).getChildAt(0).getTag();
        return value instanceof State ? (State) value : null;
    }

    private static int id(Activity page, String name) {
        return page.getResources().getIdentifier(name, "id", page.getPackageName());
    }

    private static int dp(Activity page, int value) {
        return Math.round(value * page.getResources().getDisplayMetrics().density);
    }

    private static Object field(Activity page, String name) {
        try { Field f = page.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(page); }
        catch (Exception e) { return null; }
    }

    private static boolean closed(Activity page) { return Boolean.TRUE.equals(field(page, "negotiationClosed")); }

    private static long charge(DataSnapshot booking, String path) {
        Object value = booking.child(path).getValue();
        if (value == null) return 0;
        if (!(value instanceof Number)) throw new IllegalArgumentException();
        java.math.BigDecimal amount = new java.math.BigDecimal(value.toString());
        long result = amount.longValueExact();
        if (result < 0) throw new IllegalArgumentException();
        return result;
    }

    private static final class State {
        final Activity page;
        final EditText input;
        final TextView response;
        long base, extras;
        boolean ready;
        String problem;
        DatabaseReference booking;
        ValueEventListener listener;
        TextWatcher watcher;
        State(Activity page, EditText input, TextView response) {
            this.page = page; this.input = input; this.response = response;
        }
        void say(String message) { response.setText("Fare assistant: " + message); }
        void render(boolean overview) {
            if (closed(page)) { say("Negotiation is complete. The agreed fare is saved."); return; }
            if (!ready) { say(problem == null ? "Checking the booking fare..." : problem); return; }
            if (overview || input.getText().toString().trim().isEmpty()) {
                long min = FareLimitRules.minimum(base);
                say("You can reduce the estimated base fare by up to " + FareLimitRules.money(base - min)
                        + " (10% limit). Minimum base offer: " + FareLimitRules.money(min)
                        + ". Minimum total: " + FareLimitRules.money(FareLimitRules.total(min, extras))
                        + ". Service charges stay unchanged. Driver approval is required.");
                return;
            }
            try {
                long offer = FareLimitRules.offer(input.getText().toString());
                if (FareLimitRules.allowed(offer, base)) valid(offer); else low();
            } catch (RuntimeException e) { say("Enter a valid positive fare with no more than two decimal places."); }
        }
        void low() {
            long min = FareLimitRules.minimum(base);
            say("This booking cannot go below " + FareLimitRules.money(min) + " base fare ("
                    + FareLimitRules.money(FareLimitRules.total(min, extras))
                    + " including service charges). Please increase your offer.");
        }
        void valid(long offer) {
            say("Your base offer of " + FareLimitRules.money(offer) + " is within the allowed range. Total with service charges: "
                    + FareLimitRules.money(FareLimitRules.total(offer, extras))
                    + ". You can send it to the driver; acceptance is still required.");
        }
    }
}
