package cyberorion.pk.features;

import android.app.Activity;
import android.view.View;
import android.widget.Button;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

/** Shows pending driver requests on the existing admin management button. */
public final class AdminApprovalUi {
    private AdminApprovalUi() { }

    public static void attach(Activity page) {
        int id = page.getResources().getIdentifier("btnManageDrivers", "id", page.getPackageName());
        View view = page.findViewById(id);
        if (!(view instanceof Button)) return;
        Button button = (Button) view;
        button.setContentDescription("Open driver ID approvals and driver records");
        FirebaseDatabase.getInstance().getReference("drivers").addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot drivers) {
                int pending = 0;
                for (DataSnapshot driver : drivers.getChildren()) {
                    String status = driver.child("approvalStatus").getValue(String.class);
                    if ("pending".equalsIgnoreCase(status)) pending++;
                }
                button.setText(pending > 0 ? "Driver approvals (" + pending + " pending)" : "Driver management");
            }

            @Override public void onCancelled(DatabaseError error) {
                button.setText("Driver management");
            }
        });
    }
}
