package cyberorion.pk.features;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** A booking-specific screen. Roles come from the signed-in account and booking, not Intent extras. */
public final class BookingServicesActivity extends Activity {
    private static final int PICK_PHOTO = 701;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private BookingServices services;
    private LinearLayout page;
    private DataSnapshot booking;
    private ValueEventListener listener;
    private String selectedPhoto;
    private String photoUri;
    private String recipientDraft = "";
    private TextView photoStatus;
    private EditText recipientInput;
    private boolean saving;
    private boolean pickingPhoto;
    private boolean listening;
    private long visibleTotal;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (state != null) {
            photoUri = state.getString("photoUri");
            recipientDraft = state.getString("recipient", "");
        }
        try { services = new BookingServices(getIntent().getStringExtra("extra_booking_id")); }
        catch (RuntimeException e) { message(e.getMessage()); finish(); return; }
        listener = new ValueEventListener() {
            public void onDataChange(DataSnapshot snapshot) {
                booking = snapshot;
                if (!saving && !pickingPhoto) render();
            }
            public void onCancelled(DatabaseError error) {
                emptyPage(); label("Cannot load this booking: " + error.getMessage());
                action("Retry", () -> { stopListening(); startListening(); });
            }
        };
        emptyPage(); label("Loading booking...");
        if (photoUri != null) loadPhoto(Uri.parse(photoUri));
    }

    @Override protected void onStart() { super.onStart(); startListening(); }
    @Override protected void onStop() { stopListening(); super.onStop(); }
    private void startListening() {
        if (services != null && listener != null && !listening) {
            listening = true; services.reference().addValueEventListener(listener);
        }
    }
    private void stopListening() {
        if (services != null && listener != null && listening) {
            services.reference().removeEventListener(listener); listening = false;
        }
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
    @Override protected void onSaveInstanceState(Bundle state) {
        state.putString("photoUri", photoUri);
        state.putString("recipient", recipientInput == null ? recipientDraft : recipientInput.getText().toString());
        super.onSaveInstanceState(state);
    }

    private void render() {
        if (isFinishing() || isDestroyed()) return;
        if (recipientInput != null) recipientDraft = recipientInput.getText().toString();
        emptyPage();
        if (booking == null || !booking.exists()) { label("Booking not found."); return; }
        String uid = FirebaseAuth.getInstance().getUid();
        boolean customer = uid != null && uid.equals(text("userId"));
        boolean driver = uid != null && uid.equals(text("driverId"));
        if (!customer && !driver) { label("This booking is not assigned to your account."); return; }
        title("Booking services");
        label(text("pickup") + " -> " + text("dropoff"));
        label("Status: " + text("status"));
        try {
            Object fare = booking.child("finalFare").getValue();
            if (fare == null) fare = booking.child("negotiatedFare").getValue();
            if (fare == null) fare = booking.child("estimatedFare").getValue();
            visibleTotal = BookingServices.toPaisa(fare);
        } catch (RuntimeException e) { label("Fare needs correction before services can be used."); return; }
        title("Total " + money(visibleTotal));
        boolean closed = "Cancelled".equals(text("status")) || "Rejected".equals(text("status"));
        if (closed) { label("This booking is closed. The saved record is shown below."); }
        timingSection();
        packingSection(customer && !closed, driver && !closed);
        stopsSection(customer && !closed, driver && !closed);
        paymentSection(customer && !closed, driver && !closed);
        proofSection(customer && !closed, driver && !closed);
        reviewSection(customer && !closed);
        communicationSection();
        scheduleSection(customer && !closed);
    }

    private void timingSection() {
        title("Delivery timing");
        long minutes = number("routeDurationMinutes");
        if (minutes <= 0) minutes = number("estimatedDurationMinutes");
        if (minutes > 0) label("Estimated driving time: " + durationLabel(minutes));
        showTime("Booking accepted", number("acceptedAt"));
        showTime("Driver left for pickup", number("driverLeftForPickupAt"));
        showTime("Driver arrived at pickup", number("arrivedPickupAt"));
        showTime("Items picked up", number("pickedUpAt"));
        showTime("Delivery started", number("deliveryStartedAt"));
        long expected = number("estimatedDeliveryAt");
        if (expected > 0 && number("deliveredAt") == 0) showTime("Expected arrival", expected);
        showTime("Delivered", number("deliveredAt"));
        showTime("Customer confirmed", number("completedAt"));
        if (number("deliveryStartedAt") == 0 && minutes > 0) {
            label("The arrival day and time will update when the driver starts delivery.");
        }
    }

    private void showTime(String name, long time) {
        if (time > 0) label(name + ": " + dateTime(time));
    }

    private void packingSection(boolean customer, boolean driver) {
        title("Step 3 of 5 - Packing and unpacking");
        long fee = number("serviceExtras/feePaisa");
        long savedWorkers = number("serviceExtras/workers");
        if (fee == 0 && savedWorkers == 0) {
            label("No packing or unpacking service selected.");
        } else {
            label("Service charge: " + money(fee));
            label("Workers: " + savedWorkers + " - " + fallback(text("serviceExtras/serviceStatus"), "Not requested"));
        }
        if (customer && "Pending".equals(text("status"))) {
            label("Packing Rs. 500 and unpacking Rs. 300 per worker. Loading charges stay separate.");
            CheckBox packing = check("Packing required", yes("serviceExtras/packing"));
            CheckBox unpacking = check("Unpacking required", yes("serviceExtras/unpacking"));
            EditText count = input("Number of workers (1-10)", InputType.TYPE_CLASS_NUMBER, 2);
            count.setText(String.valueOf(Math.max(1, number("serviceExtras/workers"))));
            action("Review service charges", () -> {
                try {
                    int workers = packing.isChecked() || unpacking.isChecked()
                            ? Integer.parseInt(count.getText().toString().trim()) : 0;
                    long charge = FeatureRules.packingCharge(packing.isChecked(), unpacking.isChecked(), workers,
                            BookingServices.PACKING_RATE, BookingServices.UNPACKING_RATE);
                    long base = booking.child("serviceExtras/baseFarePaisa").exists()
                            ? number("serviceExtras/baseFarePaisa") : visibleTotal;
                    confirm("Save services?", "Service charge: " + money(charge) + "\nUpdated total: " + money(FeatureRules.total(base, FeatureRules.total(charge, number("serviceExtras/stopsFeePaisa")))),
                            () -> save(cb -> services.savePacking(packing.isChecked(), unpacking.isChecked(), workers, cb)));
                } catch (RuntimeException e) { message("Check the worker count. " + e.getMessage()); }
            });
        }
        String stage = text("serviceExtras/serviceStatus");
        if (driver && !"Pending".equals(text("status")) && !"Completed".equals(text("status"))
                && ("Requested".equals(stage) || "In progress".equals(stage))) {
            action("Requested".equals(stage) ? "Start selected services" : "Mark services complete",
                    () -> save(cb -> services.advanceService(cb)));
        }
    }

    private void communicationSection() {
        title("Updates and messages");
        label("Latest booking update: " + new java.util.Date(number("updatedAt")));
        label("Pending -> Accepted -> Driver En Route -> Arrived at Pickup -> Picked Up -> Out for Delivery -> Delivered -> Completed");
        action("Customer-driver chat", () -> startActivity(new Intent(this, BookingChatActivity.class)
                .putExtra("extra_booking_id", booking.getKey())));
        action("Share booking details", () -> {
            StringBuilder details = new StringBuilder("ShiftSmart booking\nReference: ").append(booking.getKey())
                    .append("\nStatus: ").append(text("status")).append("\nPickup: ").append(text("pickup"));
            for (DataSnapshot stop : booking.child("serviceExtras/stops").getChildren()) details.append("\nStop: ").append(stop.getValue());
            details.append("\nDrop-off: ").append(text("dropoff")).append("\nTotal: ").append(money(visibleTotal));
            if (number("serviceExtras/scheduledPickupAt") > 0) details.append("\nPickup time: ").append(new java.util.Date(number("serviceExtras/scheduledPickupAt")));
            details.append("\nStatus snapshot shared at ").append(new java.util.Date()).append(". This is not a live tracking link.");
            confirm("Share booking details", "This shares the addresses, fare and booking reference with the recipient you choose.",
                    () -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, details.toString()), "Share booking details")));
        });
    }

    private void scheduleSection(boolean customer) {
        title("Pickup schedule");
        long pickup = number("serviceExtras/scheduledPickupAt");
        label(pickup == 0 ? "As soon as available" : new java.util.Date(pickup).toString());
        if (!customer || !"Pending".equals(text("status"))) return;
        label("Choose 30 minutes to 90 days ahead. You can reschedule until driver acceptance. Times use this device's time zone.");
        action(pickup == 0 ? "Schedule pickup" : "Reschedule pickup", () -> {
            java.util.Calendar chosen = java.util.Calendar.getInstance(); chosen.add(java.util.Calendar.HOUR_OF_DAY, 1);
            DatePickerDialog date = new DatePickerDialog(this, (picker, year, month, day) -> {
                chosen.set(java.util.Calendar.YEAR, year); chosen.set(java.util.Calendar.MONTH, month); chosen.set(java.util.Calendar.DAY_OF_MONTH, day);
                new TimePickerDialog(this, (time, hour, minute) -> {
                    chosen.set(java.util.Calendar.HOUR_OF_DAY, hour); chosen.set(java.util.Calendar.MINUTE, minute);
                    chosen.set(java.util.Calendar.SECOND, 0); chosen.set(java.util.Calendar.MILLISECOND, 0);
                    confirm("Save pickup time", chosen.getTime().toString(), () -> save(cb -> services.schedule(chosen.getTimeInMillis(), cb)));
                }, chosen.get(java.util.Calendar.HOUR_OF_DAY), chosen.get(java.util.Calendar.MINUTE), false).show();
            }, chosen.get(java.util.Calendar.YEAR), chosen.get(java.util.Calendar.MONTH), chosen.get(java.util.Calendar.DAY_OF_MONTH));
            date.getDatePicker().setMinDate(System.currentTimeMillis());
            date.getDatePicker().setMaxDate(System.currentTimeMillis() + 90L * 24 * 60 * 60 * 1000); date.show();
        });
        if (pickup > 0) action("Remove scheduled time", () -> confirm("Remove schedule", "Change pickup to as soon as available?", () -> save(cb -> services.schedule(null, cb))));
    }

    private void stopsSection(boolean customer, boolean driver) {
        title("Step 4 of 5 - Extra route stops");
        java.util.List<String> stops = new java.util.ArrayList<>();
        for (DataSnapshot stop : booking.child("serviceExtras/stops").getChildren()) stops.add(String.valueOf(stop.getValue()));
        int next = (int) number("serviceExtras/nextStop");
        if (stops.isEmpty()) {
            label("No extra route stop selected.");
        } else {
            for (int i = 0; i < stops.size(); i++) label((i + 1) + ". " + stops.get(i) + (i < next ? " - Completed" : " - Pending"));
            label("Additional distance: " + String.format(Locale.US, "%.1f km", decimal("serviceExtras/extraDistanceKm")));
            label("Distance charge: " + money(number("serviceExtras/stopsFeePaisa")) + " at Rs. 60/km");
        }
        if (customer && "Pending".equals(text("status"))) {
            label("Add up to 3 pickup/drop stops between the route. Check the full route in Google Maps, then enter the additional kilometres compared with the direct route.");
            EditText[] addresses = new EditText[3];
            for (int i = 0; i < 3; i++) {
                addresses[i] = input("Extra stop " + (i + 1) + " full address (optional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, 200);
                if (i < stops.size()) addresses[i].setText(stops.get(i));
            }
            EditText extraKm = input("Additional route distance in km (for example 4.5)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL, 6);
            extraKm.setText(String.format(Locale.US, "%.1f", decimal("serviceExtras/extraDistanceKm")));
            action("Check full route in Google Maps", () -> {
                StringBuilder waypoints = new StringBuilder();
                for (EditText address : addresses) if (!address.getText().toString().trim().isEmpty()) {
                    if (waypoints.length() > 0) waypoints.append('|');
                    waypoints.append(address.getText().toString().trim());
                }
                Uri route = Uri.parse("https://www.google.com/maps/dir/?api=1&origin=" + Uri.encode(text("pickup"))
                        + "&destination=" + Uri.encode(text("dropoff")) + (waypoints.length() == 0 ? "" : "&waypoints=" + Uri.encode(waypoints.toString())));
                try { startActivity(new Intent(Intent.ACTION_VIEW, route)); }
                catch (android.content.ActivityNotFoundException e) { message("Install a map app or browser to check the route."); }
            });
            action("Review extra stops", () -> {
                java.util.List<String> entered = new java.util.ArrayList<>();
                for (EditText address : addresses) if (!address.getText().toString().trim().isEmpty()) entered.add(address.getText().toString().trim());
                try {
                    FeatureRules.cleanStops(entered);
                    long base = booking.child("serviceExtras/baseFarePaisa").exists() ? number("serviceExtras/baseFarePaisa") : visibleTotal;
                    double additionalKm = Double.parseDouble(extraKm.getText().toString().trim());
                    long routeFee = FeatureRules.distanceCharge(additionalKm, BookingServices.EXTRA_KM_RATE);
                    long total = FeatureRules.total(base, FeatureRules.total(number("serviceExtras/feePaisa"), routeFee));
                    confirm("Save extra stops", "Additional distance: " + String.format(Locale.US, "%.1f km", additionalKm)
                                    + "\nRate: Rs. 60/km\nDistance charge: " + money(routeFee) + "\nUpdated total: " + money(total),
                            () -> save(cb -> services.saveStops(entered, additionalKm, cb)));
                } catch (RuntimeException e) { message(e.getMessage()); }
            });
        }
        if (driver && "Out for Delivery".equals(text("status")) && next < stops.size()) {
            action("Navigate to next stop", () -> {
                Uri route = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(stops.get(next)));
                try { startActivity(new Intent(Intent.ACTION_VIEW, route)); }
                catch (android.content.ActivityNotFoundException e) { message("Install a map app or browser to navigate."); }
            });
            action("Mark next stop complete", () -> confirm("Complete stop", stops.get(next), () -> save(cb -> services.completeNextStop(next, cb))));
        }
    }

    private void paymentSection(boolean customer, boolean driver) {
        title("Step 5 of 5 - Payment method");
        String payment = text("serviceExtras/payment/status");
        String method = text("serviceExtras/payment/method");
        label("Method: " + paymentLabel(method));
        label("Payment status: " + fallback(payment, "Not recorded"));
        if (customer && !"paid".equals(payment)) {
            label("Demo/FYP accounts only - do not send real money.");
            label("JazzCash demo: 0300 0000000\nEasypaisa demo: 0311 0000000\nBank demo: ShiftSmart FYP, IBAN PK00 DEMO 0000 0000 0000 0000");
            action("JazzCash (demo)", () -> choosePayment("jazzcash"));
            action("Easypaisa (demo)", () -> choosePayment("easypaisa"));
            action("Bank transfer (demo)", () -> choosePayment("bank"));
            action("Cash on delivery", () -> choosePayment("cash"));
        }
        if (driver && method.isEmpty()) label("The customer has not selected a payment method yet.");
        if (driver && "Completed".equals(text("status")) && "cash".equals(text("serviceExtras/payment/method")) && !"paid".equals(payment)) {
            action("Record cash received", () -> confirm("Confirm cash received", "Record receipt of " + money(visibleTotal) + "?",
                    () -> save(cb -> services.recordCash(visibleTotal, cb))));
        }
        if ("paid".equals(payment)) {
            String receipt = "ShiftSmart cash receipt\nBooking: " + booking.getKey() + "\nReceipt: "
                    + text("serviceExtras/payment/receiptId") + "\nAmount: " + money(number("serviceExtras/payment/amountPaisa"))
                    + "\nRecorded by the assigned driver.\nDate: "
                    + new java.util.Date(number("serviceExtras/payment/receivedAt"));
            label(receipt);
            action("Share receipt", () -> startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND)
                    .setType("text/plain").putExtra(Intent.EXTRA_TEXT, receipt), "Share receipt")));
        }
        if (customer) label("JazzCash, Easypaisa and bank transfer are selection simulations. No gateway or real account is connected.");
    }

    private void proofSection(boolean customer, boolean driver) {
        title("Proof of delivery");
        String proof = text("serviceExtras/proof/photoBase64");
        if (!proof.isEmpty()) {
            label("Recipient: " + text("serviceExtras/proof/recipientName"));
            try {
                byte[] bytes = Base64.decode(proof, Base64.DEFAULT);
                Bitmap photo = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (photo != null) {
                    ImageView preview = new ImageView(this); preview.setImageBitmap(photo);
                    preview.setContentDescription("Delivery photo"); preview.setAdjustViewBounds(true);
                    preview.setMaxHeight(dp(280)); page.addView(preview);
                }
            } catch (IllegalArgumentException e) { label("The saved photo could not be displayed."); }
        }
        String status = text("status");
        if (driver && ("Out for Delivery".equals(status) || "Delivered".equals(status))
                && text("serviceExtras/proof/confirmedBy").isEmpty()) {
            recipientInput = input("Recipient name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS, 80);
            recipientInput.setText(recipientDraft);
            photoStatus = label(selectedPhoto == null ? "Choose a delivery photo." : "Photo ready to upload.");
            action("Choose delivery photo", () -> {
                recipientDraft = recipientInput.getText().toString(); pickingPhoto = true;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                try { startActivityForResult(intent, PICK_PHOTO); }
                catch (android.content.ActivityNotFoundException e) { pickingPhoto = false; message("No photo picker is available."); }
            });
            action("Submit delivery proof", () -> {
                recipientDraft = recipientInput.getText().toString();
                save(cb -> services.submitProof(selectedPhoto, recipientDraft, cb));
            });
        }
        if (customer && "Delivered".equals(status) && !proof.isEmpty()) {
            action("Confirm items received", () -> confirm("Confirm delivery", "Have you received your items and checked the selected services?",
                    () -> save(cb -> services.confirmDelivery(cb))));
        }
        if (!text("serviceExtras/proof/confirmedBy").isEmpty()) label("Receipt confirmed by the customer.");
        else label("The customer confirms delivery after checking the driver's photo.");
    }

    private void reviewSection(boolean customer) {
        title("Driver review");
        if (booking.child("serviceExtras/review").exists()) {
            label(number("serviceExtras/review/stars") + " / 5 stars\n" + text("serviceExtras/review/comment")); return;
        }
        if (!customer || !"Completed".equals(text("status"))) { label("Reviews open when the booking is completed."); return; }
        RatingBar rating = new RatingBar(this); rating.setNumStars(5); rating.setStepSize(1); rating.setRating(0);
        page.addView(rating, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        EditText comment = input("Review (optional, up to 500 characters)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE, 500);
        action("Submit review", () -> save(cb -> services.review((int) rating.getRating(), comment.getText().toString(), cb)));
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_PHOTO) return;
        pickingPhoto = false;
        if (result != RESULT_OK || data == null || data.getData() == null) { render(); return; }
        Uri uri = data.getData(); photoUri = uri.toString();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (SecurityException ignored) { }
        loadPhoto(uri);
    }

    private void loadPhoto(Uri uri) {
        selectedPhoto = null;
        if (photoStatus != null) photoStatus.setText("Preparing photo...");
        worker.execute(() -> {
            try {
                BitmapFactory.Options options = new BitmapFactory.Options(); options.inJustDecodeBounds = true;
                try (InputStream stream = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(stream, null, options); }
                if (options.outWidth < 1 || options.outHeight < 1) throw new IllegalArgumentException("Choose a valid image.");
                options.inSampleSize = 1;
                while (Math.max(options.outWidth, options.outHeight) / options.inSampleSize > 1000) options.inSampleSize *= 2;
                options.inJustDecodeBounds = false;
                Bitmap bitmap;
                try (InputStream stream = getContentResolver().openInputStream(uri)) { bitmap = BitmapFactory.decodeStream(stream, null, options); }
                if (bitmap == null) throw new IllegalArgumentException("Could not open this image.");
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                for (int quality = 85; quality >= 25; quality -= 15) {
                    bytes.reset(); bitmap.compress(Bitmap.CompressFormat.JPEG, quality, bytes);
                    if (bytes.size() <= 175000) break;
                }
                bitmap.recycle();
                if (bytes.size() > 175000) throw new IllegalArgumentException("Choose a simpler or smaller photo.");
                final String encoded = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
                runOnUiThread(() -> { if (!isDestroyed()) { selectedPhoto = encoded; render(); } });
            } catch (Exception e) {
                runOnUiThread(() -> { if (!isDestroyed()) { photoUri = null; message("Photo failed: " + e.getMessage()); render(); } });
            }
        });
    }

    private interface SaveAction { void run(BookingServices.Callback callback); }
    private void save(SaveAction action) {
        if (saving) return;
        saving = true; enable(page, false);
        try {
            action.run(error -> {
                if (isDestroyed()) return;
                saving = false; enable(page, true);
                message(error == null ? "Saved successfully." : error);
                if (error == null) render();
            });
        } catch (RuntimeException e) { saving = false; enable(page, true); message(e.getMessage()); }
    }
    private void enable(View view, boolean enabled) {
        view.setEnabled(enabled);
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) enable(((ViewGroup) view).getChildAt(i), enabled);
    }
    private void emptyPage() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(20), dp(18), dp(20), dp(32));
        page.setBackgroundColor(FeatureEntry.color(this, "background", 0xfff7fbf8));
        scroll.addView(page); setContentView(scroll);
        action("Back", this::finish);
    }
    private void title(String text) { TextView view = label(text); view.setTextSize(18); view.setTypeface(null, Typeface.BOLD); view.setPadding(0, dp(18), 0, dp(6)); }
    private TextView label(String text) {
        TextView view = new TextView(this); view.setText(text); view.setTextSize(14);
        view.setTextColor(FeatureEntry.color(this, "textPrimary", 0xff163b2a)); view.setPadding(0, dp(4), 0, dp(4)); page.addView(view); return view;
    }
    private EditText input(String hint, int type, int length) {
        EditText input = new EditText(this); input.setHint(hint); input.setInputType(type);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(length)}); page.addView(input); return input;
    }
    private CheckBox check(String text, boolean checked) { CheckBox box = new CheckBox(this); box.setText(text); box.setChecked(checked); page.addView(box); return box; }
    private void action(String text, Runnable action) {
        Button button = new Button(this); button.setText(text); button.setAllCaps(false); button.setMinHeight(dp(48));
        button.setTextColor(0xffffffff);
        button.setBackgroundTintList(ColorStateList.valueOf(FeatureEntry.color(this, "primaryColor", 0xff0b8f4d)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(5); params.bottomMargin = dp(5);
        page.addView(button, params); button.setOnClickListener(view -> action.run());
    }
    private void confirm(String title, String text, Runnable yes) { new AlertDialog.Builder(this).setTitle(title).setMessage(text).setNegativeButton("Cancel", null).setPositiveButton("Confirm", (dialog, which) -> yes.run()).show(); }
    private void message(String text) { Toast.makeText(this, text == null ? "Please try again." : text, Toast.LENGTH_LONG).show(); }
    private String text(String path) { Object value = booking.child(path).getValue(); return value == null ? "" : String.valueOf(value); }
    private long number(String path) { Object value = booking.child(path).getValue(); return value instanceof Number ? ((Number) value).longValue() : 0; }
    private double decimal(String path) { Object value = booking.child(path).getValue(); return value instanceof Number ? ((Number) value).doubleValue() : 0; }
    private boolean yes(String path) { return Boolean.TRUE.equals(booking.child(path).getValue()); }
    private String fallback(String value, String fallback) { return value.isEmpty() ? fallback : value; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private String money(long paisa) { return String.format(Locale.US, "Rs. %,.2f", paisa / 100.0); }
    private String durationLabel(long minutes) {
        if (minutes < 60) return minutes + " min";
        long hours = minutes / 60;
        long left = minutes % 60;
        return left == 0 ? hours + " hr" : hours + " hr " + left + " min";
    }
    private String dateTime(long time) {
        return new java.text.SimpleDateFormat("EEEE, dd MMM yyyy 'at' hh:mm a", Locale.getDefault())
                .format(new java.util.Date(time));
    }
    private void choosePayment(String method) {
        confirm("Select " + paymentLabel(method), "This records the selected method as pending. It does not transfer money.",
                () -> save(cb -> services.selectPayment(method, cb)));
    }
    private String paymentLabel(String method) {
        if ("jazzcash".equals(method)) return "JazzCash (demo)";
        if ("easypaisa".equals(method)) return "Easypaisa (demo)";
        if ("bank".equals(method)) return "Bank transfer (demo)";
        if ("cash".equals(method)) return "Cash on delivery";
        return "Not selected";
    }
}
