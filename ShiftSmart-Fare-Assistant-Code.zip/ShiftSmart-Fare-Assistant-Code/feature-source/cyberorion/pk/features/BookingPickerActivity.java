package cyberorion.pk.features;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public final class BookingPickerActivity extends Activity {
    private Query bookings;
    private ValueEventListener listener;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        String uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        int padding = Math.round(16 * getResources().getDisplayMetrics().density); page.setPadding(padding, padding, padding, padding);
        page.setBackgroundColor(FeatureEntry.color(this, "background", 0xfff7fbf8));
        ScrollView scroll = new ScrollView(this); scroll.addView(page); setContentView(scroll);
        Button back = new Button(this); back.setText("Back"); back.setOnClickListener(v -> finish()); page.addView(back);
        TextView title = new TextView(this); title.setText("Assigned booking services"); title.setTextSize(22); page.addView(title);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); page.addView(list);
        bookings = FirebaseDatabase.getInstance().getReference("bookings").orderByChild("driverId").equalTo(uid);
        listener = new ValueEventListener() {
            public void onDataChange(DataSnapshot snapshot) {
                list.removeAllViews();
                if (!snapshot.exists()) { TextView empty = new TextView(BookingPickerActivity.this); empty.setText("No assigned bookings."); list.addView(empty); }
                for (DataSnapshot booking : snapshot.getChildren()) {
                    Button row = new Button(BookingPickerActivity.this); row.setAllCaps(false);
                    row.setText(String.valueOf(booking.child("pickup").getValue()) + " → " + booking.child("dropoff").getValue() + "\n" + booking.child("status").getValue());
                    row.setOnClickListener(v -> FeatureEntry.open(BookingPickerActivity.this, booking.getKey())); list.addView(row);
                }
            }
            public void onCancelled(DatabaseError error) { list.removeAllViews(); TextView message = new TextView(BookingPickerActivity.this); message.setText("Could not load bookings: " + error.getMessage()); list.addView(message); }
        };
    }
    @Override protected void onStart() { super.onStart(); if (bookings != null) bookings.addValueEventListener(listener); }
    @Override protected void onStop() { if (bookings != null) bookings.removeEventListener(listener); super.onStop(); }
}
