package cyberorion.pk.features;

import android.app.Activity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/** Stores important delivery times when the driver changes the booking status. */
public final class DeliveryTiming {
    private DeliveryTiming() { }

    public static void record(Activity page, Object booking, Object status) {
        String bookingId = field(booking, "bookingId");
        String state = status instanceof Enum ? ((Enum<?>) status).name() : String.valueOf(status);
        if (bookingId.isEmpty()) return;
        String timeField = fieldFor(state);
        if (timeField == null) return;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("bookings").child(bookingId);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(DataSnapshot data) {
                if (data.child(timeField).exists()) return;
                long now = System.currentTimeMillis();
                Map<String, Object> values = new HashMap<>();
                values.put(timeField, now);
                if ("deliveryStartedAt".equals(timeField)) {
                    long minutes = number(data, "routeDurationMinutes");
                    if (minutes <= 0) minutes = number(data, "estimatedDurationMinutes");
                    if (minutes > 0) values.put("estimatedDeliveryAt", now + minutes * 60000L);
                }
                ref.updateChildren(values);
            }

            @Override public void onCancelled(DatabaseError error) { }
        });
    }

    private static String fieldFor(String status) {
        if ("ACCEPTED".equals(status)) return "acceptedAt";
        if ("EN_ROUTE_PICKUP".equals(status)) return "driverLeftForPickupAt";
        if ("ARRIVED_PICKUP".equals(status)) return "arrivedPickupAt";
        if ("PICKED_UP".equals(status)) return "pickedUpAt";
        if ("DELIVERING".equals(status)) return "deliveryStartedAt";
        return null;
    }

    private static String field(Object object, String name) {
        if (object == null) return "";
        try {
            Field value = object.getClass().getField(name);
            Object result = value.get(object);
            return result == null ? "" : String.valueOf(result);
        } catch (Exception ignored) { return ""; }
    }

    private static long number(DataSnapshot data, String name) {
        Object value = data.child(name).getValue();
        return value instanceof Number ? ((Number) value).longValue() : 0;
    }
}
