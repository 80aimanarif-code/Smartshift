package cyberorion.pk.features;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;
import java.util.Map;

/** Booking chat stays separate from negotiation offers. */
public final class BookingChatActivity extends Activity {
    private Query messages;
    private DatabaseReference room;
    private DatabaseReference bookingRef;
    private ValueEventListener listener;
    private ValueEventListener membership;
    private TextView history;
    private EditText input;
    private Button send;
    private boolean canSend;
    private boolean sending;
    private String uid;
    private String senderRole;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        uid = FirebaseAuth.getInstance().getUid();
        if (uid == null) { finish(); return; }
        String bookingId = getIntent().getStringExtra("extra_booking_id");
        try { bookingRef = new BookingServices(bookingId).reference(); }
        catch (RuntimeException e) { finish(); return; }
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(16 * getResources().getDisplayMetrics().density); page.setPadding(pad, pad, pad, pad);
        page.setBackgroundColor(FeatureEntry.color(this, "background", 0xfff7fbf8)); setContentView(page);
        Button back = new Button(this); back.setText("Back to booking"); page.addView(back); back.setOnClickListener(v -> finish());
        TextView title = new TextView(this); title.setText("Booking chat · latest 100 messages"); title.setTextSize(18); page.addView(title);
        history = new TextView(this); history.setTextSize(16); history.setTextIsSelectable(true);
        ScrollView scroll = new ScrollView(this); scroll.addView(history); page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        input = new EditText(this); input.setHint("Write a message"); input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1000)}); page.addView(input);
        if (state != null) input.setText(state.getString("draft", ""));
        send = new Button(this); send.setText("Send"); send.setEnabled(false); page.addView(send);
        room = FirebaseDatabase.getInstance().getReference("bookingChats").child(bookingId).child("messages");
        messages = room.orderByChild("sentAt").limitToLast(100);
        listener = new ValueEventListener() {
            public void onDataChange(DataSnapshot snapshot) {
                StringBuilder text = new StringBuilder();
                for (DataSnapshot message : snapshot.getChildren()) {
                    String author = uid.equals(message.child("senderId").getValue()) ? "You" : String.valueOf(message.child("senderRole").getValue());
                    Object time = message.child("sentAt").getValue();
                    text.append(author);
                    if (time instanceof Number) text.append(" · ").append(new java.util.Date(((Number) time).longValue()));
                    text.append('\n').append(String.valueOf(message.child("text").getValue())).append("\n\n");
                }
                history.setText(text.length() == 0 ? "No messages yet." : text.toString());
            }
            public void onCancelled(DatabaseError error) { history.setText("Chat could not load: " + error.getMessage()); }
        };
        membership = new ValueEventListener() {
            public void onDataChange(DataSnapshot data) {
                boolean customer = uid.equals(data.child("userId").getValue());
                boolean driver = uid.equals(data.child("driverId").getValue());
                String status = String.valueOf(data.child("status").getValue());
                canSend = (customer || driver) && !"Cancelled".equals(status) && !"Rejected".equals(status) && !"Completed".equals(status);
                senderRole = customer ? "Customer" : "Driver";
                send.setEnabled(canSend && !sending);
                if (!customer && !driver) { Toast.makeText(BookingChatActivity.this, "You are not part of this booking.", Toast.LENGTH_LONG).show(); finish(); }
                else if (!canSend) input.setHint("This completed or closed booking has read-only chat.");
            }
            public void onCancelled(DatabaseError error) { canSend = false; send.setEnabled(false); history.setText(error.getMessage()); }
        };
        send.setOnClickListener(v -> send());
    }
    @Override protected void onStart() { super.onStart(); if (messages != null) { messages.addValueEventListener(listener); bookingRef.addValueEventListener(membership); } }
    @Override protected void onStop() { if (messages != null) { messages.removeEventListener(listener); bookingRef.removeEventListener(membership); } super.onStop(); }
    @Override protected void onSaveInstanceState(Bundle state) { if (input != null) state.putString("draft", input.getText().toString()); super.onSaveInstanceState(state); }
    private void send() {
        if (!canSend || sending) return;
        final String text;
        try { text = FeatureRules.cleanMessage(input.getText().toString()); }
        catch (IllegalArgumentException e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); return; }
        Map<String, Object> message = new HashMap<>(); message.put("senderId", uid); message.put("senderRole", senderRole);
        message.put("text", text); message.put("sentAt", ServerValue.TIMESTAMP);
        sending = true; send.setEnabled(false);
        room.push().setValue(message).addOnCompleteListener(task -> {
            if (isDestroyed()) return;
            sending = false; send.setEnabled(canSend);
            if (task.isSuccessful()) { if (input.getText().toString().trim().equals(text)) input.setText(""); }
            else Toast.makeText(this, "Message not sent. Check connection and database access.", Toast.LENGTH_LONG).show();
        });
    }
}
