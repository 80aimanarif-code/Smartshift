package cyberorion.pk.features;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Replaces the old Google tracking view with a Mapbox live truck map. */
public final class LiveTrackingMap {
    private static final String TOKEN = "pk.eyJ1IjoiaGFzbmF0cWF6aTIwMDMiLCJhIjoiY211cHlxZzg0MDZjczJ4czduY3V3YW44NSJ9.ezyEpCMyAOmyVnErnUFOGQ";

    private LiveTrackingMap() { }

    public static void attach(Activity page, String bookingId) {
        int mapId = page.getResources().getIdentifier("mapTracking", "id", page.getPackageName());
        View oldMap = page.findViewById(mapId);
        if (oldMap == null || !(oldMap.getParent() instanceof ViewGroup)) return;
        ViewGroup mapBox = (ViewGroup) oldMap.getParent();
        oldMap.setVisibility(View.GONE);

        WebView map = new WebView(page);
        map.setTag("mapbox-live-tracking");
        WebSettings settings = map.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        mapBox.addView(map, 0, new ViewGroup.LayoutParams(-1, -1));

        TextView summary = addSummary(page);
        State state = new State(page, bookingId, map, summary);
        map.addJavascriptInterface(new RouteBridge(state), "AndroidRoute");
        map.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                state.mapReady = true;
                state.draw();
            }
        });
        map.loadDataWithBaseURL("https://api.mapbox.com/", mapPage(), "text/html", "UTF-8", null);
        state.listen();
    }

    private static TextView addSummary(Activity page) {
        int routeId = page.getResources().getIdentifier("tvTripRoute", "id", page.getPackageName());
        View route = page.findViewById(routeId);
        TextView text = new TextView(page);
        text.setText("Waiting for the driver's live location...");
        text.setTextSize(13);
        text.setTextColor(FeatureEntry.color(page, "textPrimary", 0xff163b2a));
        text.setPadding(dp(page, 12), dp(page, 10), dp(page, 12), dp(page, 10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(238, 247, 241));
        bg.setCornerRadius(dp(page, 12));
        text.setBackground(bg);
        if (route != null && route.getParent() instanceof LinearLayout) {
            LinearLayout parent = (LinearLayout) route.getParent();
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.topMargin = dp(page, 8);
            parent.addView(text, params);
        }
        return text;
    }

    private static String mapPage() {
        return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<link href='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.css' rel='stylesheet'>"
                + "<script src='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.js'></script>"
                + "<style>html,body,#map{margin:0;width:100%;height:100%;}</style></head><body><div id='map'></div><script>"
                + "mapboxgl.accessToken='" + TOKEN + "';"
                + "const map=new mapboxgl.Map({container:'map',style:'mapbox://styles/mapbox/streets-v12',center:[73.05,31.5],zoom:6});"
                + "map.addControl(new mapboxgl.NavigationControl());let truck,pick,drop,first=true;"
                + "async function updateTruck(tLng,tLat,pLng,pLat,dLng,dLat,toDrop){if(!map.loaded()){setTimeout(()=>updateTruck(tLng,tLat,pLng,pLat,dLng,dLat,toDrop),250);return;}"
                + "if(!pick)pick=new mapboxgl.Marker({color:'#0b8f4d'}).setLngLat([pLng,pLat]).addTo(map);"
                + "if(!drop)drop=new mapboxgl.Marker({color:'#dc2626'}).setLngLat([dLng,dLat]).addTo(map);"
                + "if(!truck)truck=new mapboxgl.Marker({color:'#2563eb'}).setLngLat([tLng,tLat]).addTo(map);else truck.setLngLat([tLng,tLat]);"
                + "const x=toDrop?dLng:pLng,y=toDrop?dLat:pLat,u='https://api.mapbox.com/directions/v5/mapbox/driving/'+tLng+','+tLat+';'+x+','+y+'?geometries=geojson&overview=full&access_token='+mapboxgl.accessToken;"
                + "try{const data=await(await fetch(u)).json();if(!data.routes||!data.routes[0])return;const feature={type:'Feature',geometry:data.routes[0].geometry};"
                + "if(map.getSource('liveRoute'))map.getSource('liveRoute').setData(feature);else{map.addSource('liveRoute',{type:'geojson',data:feature});map.addLayer({id:'liveRoute',type:'line',source:'liveRoute',paint:{'line-color':'#2563eb','line-width':6}});}"
                + "const b=new mapboxgl.LngLatBounds();data.routes[0].geometry.coordinates.forEach(c=>b.extend(c));if(first){map.fitBounds(b,{padding:55});first=false;}"
                + "AndroidRoute.update(data.routes[0].distance/1000,data.routes[0].duration,toDrop);}catch(e){}}"
                + "</script></body></html>";
    }

    private static final class State {
        final Activity page;
        final String bookingId;
        final WebView map;
        final TextView summary;
        boolean mapReady;
        double pickupLat, pickupLng, dropLat, dropLng, truckLat, truckLng;
        boolean hasBooking, hasTruck, toDrop;
        long locationTime;

        State(Activity page, String bookingId, WebView map, TextView summary) {
            this.page = page; this.bookingId = bookingId; this.map = map; this.summary = summary;
        }

        void listen() {
            FirebaseDatabase.getInstance().getReference("bookings").child(bookingId)
                    .addValueEventListener(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot data) {
                    Double a = value(data, "pickupLat"), b = value(data, "pickupLng");
                    Double c = value(data, "dropoffLat"), d = value(data, "dropoffLng");
                    if (a == null || b == null || c == null || d == null) return;
                    pickupLat = a; pickupLng = b; dropLat = c; dropLng = d; hasBooking = true;
                    String status = String.valueOf(data.child("status").getValue());
                    toDrop = LiveTrackingRules.routeToDropoff(status);
                    draw();
                }
                @Override public void onCancelled(DatabaseError error) { }
            });
            FirebaseDatabase.getInstance().getReference("tracking").child(bookingId)
                    .addValueEventListener(new ValueEventListener() {
                @Override public void onDataChange(DataSnapshot data) {
                    Double a = value(data, "lat"), b = value(data, "lng");
                    if (a == null || b == null) return;
                    truckLat = a; truckLng = b; hasTruck = true;
                    Object time = data.child("updatedAt").getValue();
                    locationTime = time instanceof Number ? ((Number) time).longValue() : System.currentTimeMillis();
                    draw();
                }
                @Override public void onCancelled(DatabaseError error) { }
            });
        }

        void draw() {
            if (!mapReady || !hasBooking) return;
            if (!hasTruck) {
                summary.setText("Waiting for the driver's live location...");
                return;
            }
            String js = String.format(Locale.US, "updateTruck(%.7f,%.7f,%.7f,%.7f,%.7f,%.7f,%s)",
                    truckLng, truckLat, pickupLng, pickupLat, dropLng, dropLat, toDrop ? "true" : "false");
            map.evaluateJavascript(js, null);
        }
    }

    private static final class RouteBridge {
        final State state;
        RouteBridge(State state) { this.state = state; }

        @JavascriptInterface public void update(double distanceKm, double durationSeconds, boolean toDrop) {
            state.page.runOnUiThread(() -> {
                long now = System.currentTimeMillis();
                long minutes = LiveTrackingRules.remainingMinutes(durationSeconds);
                long arrival = LiveTrackingRules.arrivalAt(now, minutes);
                String closeness = LiveTrackingRules.proximity(distanceKm);
                String target = toDrop ? "Expected delivery" : "Expected pickup arrival";
                String updated = state.locationTime > 0 ? "\nLocation updated: " + time(state.locationTime) : "";
                String delayed = LiveTrackingRules.locationDelayed(now, state.locationTime)
                        ? "\nLocation signal is delayed" : "";
                state.summary.setText(closeness + "  -  " + duration(minutes) + " remaining\n"
                        + target + ": " + dateTime(arrival) + updated + delayed);
            });
        }
    }

    private static Double value(DataSnapshot data, String name) {
        Object value = data.child(name).getValue();
        return value instanceof Number ? ((Number) value).doubleValue() : null;
    }

    private static String duration(long minutes) {
        if (minutes < 60) return minutes + " min";
        long hours = minutes / 60, left = minutes % 60;
        return left == 0 ? hours + " hr" : hours + " hr " + left + " min";
    }

    private static String dateTime(long value) {
        return new SimpleDateFormat("EEEE, dd MMM yyyy 'at' hh:mm a", Locale.getDefault()).format(new Date(value));
    }

    private static String time(long value) {
        return new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(new Date(value));
    }

    private static int dp(Activity page, int value) {
        return Math.round(value * page.getResources().getDisplayMetrics().density);
    }
}
