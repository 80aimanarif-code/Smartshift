package cyberorion.pk.features;

import android.app.Activity;
import android.text.InputFilter;
import android.text.method.DigitsKeyListener;
import android.widget.EditText;

/** Small signup checks kept separate so they are easy to read and test. */
public final class SignupValidator {
    private SignupValidator() {
    }

    public static void configureCustomerSignup(Activity signupPage) {
        EditText phoneNumber = findInput(signupPage, "etPhone");
        if (phoneNumber != null) {
            phoneNumber.setKeyListener(DigitsKeyListener.getInstance("0123456789+ -"));
            phoneNumber.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        }
        configurePassword(signupPage);
    }

    public static void configureDriverSignup(Activity signupPage) {
        configurePassword(signupPage);
    }

    public static boolean validateCustomerSignup(Activity signupPage) {
        EditText phoneInput = findInput(signupPage, "etPhone");
        if (phoneInput == null) return false;

        String phoneNumber = normalizePakistaniNumber(phoneInput.getText().toString());
        if (phoneNumber == null) {
            phoneInput.setError("Enter a Pakistani number, for example 03001234567");
            phoneInput.requestFocus();
            return false;
        }

        phoneInput.setError(null);
        phoneInput.setText(phoneNumber);
        return validatePassword(signupPage);
    }

    public static boolean validateDriverSignup(Activity signupPage) {
        return validatePassword(signupPage);
    }

    public static String normalizePakistaniNumber(String phoneNumber) {
        if (phoneNumber == null) return null;
        String cleanNumber = phoneNumber.replace(" ", "").replace("-", "");

        if (cleanNumber.matches("03[0-9]{9}")) return cleanNumber;
        if (cleanNumber.matches("\\+923[0-9]{9}")) return "0" + cleanNumber.substring(3);
        return null;
    }

    public static boolean isStrongPassword(String passwordText) {
        if (passwordText == null || passwordText.length() < 8 || passwordText.length() > 64) {
            return false;
        }

        boolean hasLetter = false;
        boolean hasNumber = false;
        boolean hasSymbol = false;

        for (int i = 0; i < passwordText.length(); i++) {
            char currentChar = passwordText.charAt(i);
            if (Character.isWhitespace(currentChar)) return false;
            if (Character.isLetter(currentChar)) hasLetter = true;
            else if (Character.isDigit(currentChar)) hasNumber = true;
            else hasSymbol = true;
        }
        return hasLetter && hasNumber && hasSymbol;
    }

    private static void configurePassword(Activity signupPage) {
        EditText passwordInput = findInput(signupPage, "etPassword");
        if (passwordInput == null) return;
        passwordInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
    }

    private static boolean validatePassword(Activity signupPage) {
        EditText passwordInput = findInput(signupPage, "etPassword");
        if (passwordInput == null) return false;

        String passwordText = passwordInput.getText().toString();
        if (!isStrongPassword(passwordText)) {
            passwordInput.setError("Use 8+ characters with a letter, number and symbol");
            passwordInput.requestFocus();
            return false;
        }
        passwordInput.setError(null);
        return true;
    }

    private static EditText findInput(Activity signupPage, String idName) {
        int inputId = signupPage.getResources().getIdentifier(idName, "id", signupPage.getPackageName());
        return signupPage.findViewById(inputId);
    }
}
