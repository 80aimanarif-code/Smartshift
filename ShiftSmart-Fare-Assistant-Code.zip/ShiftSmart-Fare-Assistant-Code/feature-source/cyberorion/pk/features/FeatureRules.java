package cyberorion.pk.features;

/** Small, Android-independent rules shared by the new booking features. */
public final class FeatureRules {
    private FeatureRules() { }

    public static final int MAX_WORKERS = 10;

    public static long distanceCharge(double extraKm, long ratePerKmPaisa) {
        if (Double.isNaN(extraKm) || Double.isInfinite(extraKm) || extraKm < 0 || extraKm > 500) {
            throw new IllegalArgumentException("Additional route distance must be between 0 and 500 km.");
        }
        if (ratePerKmPaisa < 0) throw new IllegalArgumentException("Distance rate cannot be negative.");
        return java.math.BigDecimal.valueOf(extraKm).multiply(java.math.BigDecimal.valueOf(ratePerKmPaisa))
                .setScale(0, java.math.RoundingMode.HALF_UP).longValueExact();
    }

    public static String cleanPaymentMethod(String method) {
        if ("cash".equals(method) || "jazzcash".equals(method) || "easypaisa".equals(method)
                || "bank".equals(method)) return method;
        throw new IllegalArgumentException("Choose a valid payment method.");
    }

    public static void checkSchedule(long pickupTime, long now) {
        long delay = Math.subtractExact(pickupTime, now);
        if (delay < 30L * 60 * 1000 || delay > 90L * 24 * 60 * 60 * 1000) {
            throw new IllegalArgumentException("Choose a pickup time between 30 minutes and 90 days from now.");
        }
    }

    public static java.util.List<String> cleanStops(java.util.List<String> stops) {
        if (stops == null || stops.size() > 3) throw new IllegalArgumentException("Add up to 3 extra delivery stops.");
        java.util.List<String> result = new java.util.ArrayList<>();
        for (String stop : stops) {
            String address = stop == null ? "" : stop.trim();
            if (address.length() < 5 || address.length() > 200) {
                throw new IllegalArgumentException("Each stop needs a full address between 5 and 200 characters.");
            }
            for (String saved : result) if (saved.equalsIgnoreCase(address)) {
                throw new IllegalArgumentException("Remove duplicate stops.");
            }
            result.add(address);
        }
        return result;
    }

    public static String cleanMessage(String message) {
        String text = message == null ? "" : message.trim();
        if (text.isEmpty() || text.length() > 1000) throw new IllegalArgumentException("Write a message of 1 to 1000 characters.");
        return text;
    }

    public static long packingCharge(boolean packing, boolean unpacking, int workers,
                                     long packingRate, long unpackingRate) {
        if (packingRate < 0 || unpackingRate < 0) {
            throw new IllegalArgumentException("Service rates cannot be negative.");
        }
        if (!packing && !unpacking) {
            if (workers != 0) throw new IllegalArgumentException("No workers are needed without a service.");
            return 0;
        }
        if (workers < 1 || workers > MAX_WORKERS) {
            throw new IllegalArgumentException("Choose between 1 and 10 workers.");
        }
        long rate = Math.addExact(packing ? packingRate : 0, unpacking ? unpackingRate : 0);
        return Math.multiplyExact(workers, rate);
    }

    public static long total(long baseFare, long serviceCharge) {
        if (baseFare < 0 || serviceCharge < 0) {
            throw new IllegalArgumentException("Amounts cannot be negative.");
        }
        return Math.addExact(baseFare, serviceCharge);
    }

    public static void checkRating(boolean completed, boolean alreadyRated,
                                   int stars, String comment) {
        if (!completed) throw new IllegalStateException("Complete the booking before reviewing it.");
        if (alreadyRated) throw new IllegalStateException("This booking already has a review.");
        if (stars < 1 || stars > 5) throw new IllegalArgumentException("Choose 1 to 5 stars.");
        if (comment != null && comment.trim().length() > 500) {
            throw new IllegalArgumentException("Keep the review within 500 characters.");
        }
    }

    public static double ratingAverage(long starTotal, long reviewCount) {
        if (reviewCount < 0 || starTotal < reviewCount || starTotal > Math.multiplyExact(reviewCount, 5)) {
            throw new IllegalArgumentException("Invalid rating totals.");
        }
        return reviewCount == 0 ? 0 : (double) starTotal / reviewCount;
    }

    public static void checkCashReceipt(boolean completed, boolean alreadyPaid, long total,
                                        long received) {
        if (!completed) throw new IllegalStateException("Cash can be recorded after delivery confirmation.");
        if (alreadyPaid) throw new IllegalStateException("Payment has already been recorded.");
        if (total < 0 || received != total) throw new IllegalArgumentException("Received amount must match the total.");
    }

    public static void checkProof(String photoReference, String recipientName, boolean confirmed) {
        if (photoReference == null || photoReference.trim().isEmpty()) {
            throw new IllegalArgumentException("Attach a delivery photo first.");
        }
        if (recipientName == null || recipientName.trim().isEmpty() || recipientName.trim().length() > 80) {
            throw new IllegalArgumentException("Enter the recipient name, up to 80 characters.");
        }
        if (!confirmed) throw new IllegalArgumentException("The customer must confirm receipt.");
    }
}
