package cyberorion.pk.features;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Displays the calculated pickup, optional stop and drop-off route on Mapbox. */
public final class MapboxMapActivity extends Activity {
    private static final String TOKEN = "pk.eyJ1IjoiaGFzbmF0cWF6aTIwMDMiLCJhIjoiY211cHlxZzg0MDZjczJ4czduY3V3YW44NSJ9.ezyEpCMyAOmyVnErnUFOGQ";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        android.content.SharedPreferences saved = getSharedPreferences("booking_steps", 0);
        String pickupLat = saved.getString("pickupLat", "");
        String pickupLng = saved.getString("pickupLng", "");
        String stopLat = saved.getString("stopLat", "");
        String stopLng = saved.getString("stopLng", "");
        String dropLat = saved.getString("dropoffLat", "");
        String dropLng = saved.getString("dropoffLng", "");
        if (!number(pickupLat) || !number(pickupLng) || !number(dropLat) || !number(dropLng)) {
            finish(); return;
        }

        String coordinates = pickupLng + "," + pickupLat + ";"
                + (number(stopLat) && number(stopLng) ? stopLng + "," + stopLat + ";" : "")
                + dropLng + "," + dropLat;
        String stopMarker = number(stopLat) && number(stopLng)
                ? "new mapboxgl.Marker({color:'#f59e0b'}).setLngLat([" + stopLng + "," + stopLat + "]).addTo(map);" : "";
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<link href='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.css' rel='stylesheet'>"
                + "<script src='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.js'></script>"
                + "<style>html,body,#map{margin:0;width:100%;height:100%;}</style></head><body><div id='map'></div><script>"
                + "mapboxgl.accessToken='" + TOKEN + "';"
                + "const map=new mapboxgl.Map({container:'map',style:'mapbox://styles/mapbox/streets-v12',center:["
                + pickupLng + "," + pickupLat + "],zoom:11});map.addControl(new mapboxgl.NavigationControl());"
                + "new mapboxgl.Marker({color:'#0b8f4d'}).setLngLat([" + pickupLng + "," + pickupLat + "]).addTo(map);"
                + stopMarker
                + "new mapboxgl.Marker({color:'#dc2626'}).setLngLat([" + dropLng + "," + dropLat + "]).addTo(map);"
                + "map.on('load',async()=>{const u='https://api.mapbox.com/directions/v5/mapbox/driving/" + coordinates
                + "?geometries=geojson&overview=full&access_token='+mapboxgl.accessToken;const d=await(await fetch(u)).json();"
                + "if(d.routes&&d.routes[0]){map.addSource('route',{type:'geojson',data:{type:'Feature',geometry:d.routes[0].geometry}});"
                + "map.addLayer({id:'route',type:'line',source:'route',layout:{'line-join':'round','line-cap':'round'},paint:{'line-color':'#0b8f4d','line-width':6}});"
                + "const b=new mapboxgl.LngLatBounds();d.routes[0].geometry.coordinates.forEach(c=>b.extend(c));map.fitBounds(b,{padding:55});}});"
                + "</script></body></html>";

        WebView map = new WebView(this);
        WebSettings settings = map.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        map.setWebViewClient(new WebViewClient());
        setContentView(map);
        map.loadDataWithBaseURL("https://api.mapbox.com/", html, "text/html", "UTF-8", null);
    }

    private boolean number(String value) {
        if (value == null || value.isEmpty()) return false;
        try { Double.parseDouble(value); return true; }
        catch (NumberFormatException error) { return false; }
    }
}
