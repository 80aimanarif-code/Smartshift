package cyberorion.pk.features;

import android.app.Activity;
import android.location.Address;
import android.location.Geocoder;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small additions for the existing Step 4 and Step 5 screens. */
public final class BookingStepExtras {
    private static final String MAPBOX_TOKEN = "pk.eyJ1IjoiaGFzbmF0cWF6aTIwMDMiLCJhIjoiY211cHlxZzg0MDZjczJ4czduY3V3YW44NSJ9.ezyEpCMyAOmyVnErnUFOGQ";

    private BookingStepExtras() {
    }

    public static void configureRouteStep(final Activity page) {
        final EditText pickupInput = input(page, "etPickup");
        final EditText stopInput = input(page, "etExtraStop");
        final EditText dropInput = input(page, "etDropoff");
        final Button routeButton = button(page, "btnCalculateRoute");
        final TextView resultText = text(page, "tvDistanceResult");
        if (pickupInput == null || stopInput == null || dropInput == null || routeButton == null || resultText == null) return;

        final WebView routeMap = createMapboxPreview(page);
        routeButton.setVisibility(View.GONE);
        stopInput.setTag(0);
        final Handler waitForTyping = new Handler(Looper.getMainLooper());
        final Runnable[] pendingRoute = new Runnable[1];
        TextWatcher routeWatcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            public void afterTextChanged(Editable s) {
                int requestNumber = stopInput.getTag() instanceof Integer ? (Integer) stopInput.getTag() : 0;
                stopInput.setTag(requestNumber + 1);
                setField(page, "distanceKm", null);
                resultText.setText("Enter pickup and drop-off to load the route");
                if (pendingRoute[0] != null) waitForTyping.removeCallbacks(pendingRoute[0]);
                String pickup = pickupInput.getText().toString().trim();
                String dropoff = dropInput.getText().toString().trim();
                if (pickup.length() < 3 || dropoff.length() < 3) return;
                pendingRoute[0] = () -> calculateRoute(page, pickupInput, stopInput, dropInput,
                        routeButton, resultText, routeMap);
                waitForTyping.postDelayed(pendingRoute[0], 1200);
            }
        };
        pickupInput.addTextChangedListener(routeWatcher);
        stopInput.addTextChangedListener(routeWatcher);
        dropInput.addTextChangedListener(routeWatcher);
    }

    private static void calculateRoute(final Activity page, final EditText pickupInput, final EditText stopInput,
                                       final EditText dropInput, final Button routeButton, final TextView resultText,
                                       final WebView routeMap) {
        final String pickup = pickupInput.getText().toString().trim();
        final String middleStop = stopInput.getText().toString().trim();
        final String dropoff = dropInput.getText().toString().trim();
        if (pickup.isEmpty() || dropoff.isEmpty()) {
            Toast.makeText(page, "Please enter pickup and drop-off locations", Toast.LENGTH_SHORT).show();
            return;
        }

        routeButton.setEnabled(false);
        resultText.setText("Locating route...");
        int oldRequest = stopInput.getTag() instanceof Integer ? (Integer) stopInput.getTag() : 0;
        final int currentRequest = oldRequest + 1;
        stopInput.setTag(currentRequest);
        new Thread(() -> {
            try {
                Point start = findMapboxPlace(pickup);
                Point end = findMapboxPlace(dropoff);
                Point stop = middleStop.isEmpty() ? null : findMapboxPlace(middleStop);
                RouteInfo direct = start == null || end == null ? null : mapboxRoute(start, end);
                RouteInfo route = direct;
                if (stop != null && direct != null) route = mapboxRoute(start, stop, end);
                final RouteInfo selectedRoute = route;
                page.runOnUiThread(() -> showMapboxRoute(page, stopInput, middleStop, start, stop, end,
                        direct, selectedRoute, routeButton, resultText, routeMap, currentRequest));
            } catch (Exception error) {
                page.runOnUiThread(() -> showMapboxError(page, stopInput, routeButton, resultText,
                        currentRequest, error.getMessage()));
            }
        }).start();
    }

    private static void showMapboxRoute(Activity page, EditText stopInput, String middleStop,
                                        Point start, Point stop, Point end, RouteInfo direct, RouteInfo route,
                                        Button routeButton, TextView resultText, WebView routeMap, int requestNumber) {
        int latestRequest = stopInput.getTag() instanceof Integer ? (Integer) stopInput.getTag() : 0;
        if (requestNumber != latestRequest || page.isFinishing()) return;
        routeButton.setEnabled(true);
        if (start == null || end == null || (!middleStop.isEmpty() && stop == null) || direct == null || route == null) {
            resultText.setText("Could not find one of the entered locations");
            return;
        }

        double routeKm = route.distanceKm;
        int travelMinutes = Math.max(1, (int) Math.ceil(route.durationSeconds / 60.0));
        long calculatedAt = System.currentTimeMillis();
        double addedKm = Math.max(0, routeKm - direct.distanceKm);
        double addedCharge = addedKm * 45.0;

        setField(page, "pickupLat", start.latitude);
        setField(page, "pickupLng", start.longitude);
        setField(page, "dropoffLat", end.latitude);
        setField(page, "dropoffLng", end.longitude);
        setField(page, "distanceKm", routeKm);
        page.getIntent().putExtra("extra_stop", middleStop);
        page.getIntent().putExtra("extra_stop_added_km", addedKm);
        page.getSharedPreferences("booking_steps", 0).edit()
                .putString("extraStop", middleStop)
                .putFloat("extraStopAddedKm", (float) addedKm)
                .putFloat("routeDistanceKm", (float) routeKm)
                .putInt("routeDurationMinutes", travelMinutes)
                .putLong("routeCalculatedAt", calculatedAt)
                .putString("pickupLat", String.valueOf(start.latitude))
                .putString("pickupLng", String.valueOf(start.longitude))
                .putString("dropoffLat", String.valueOf(end.latitude))
                .putString("dropoffLng", String.valueOf(end.longitude))
                .putString("stopLat", stop == null ? "" : String.valueOf(stop.latitude))
                .putString("stopLng", stop == null ? "" : String.valueOf(stop.longitude))
                .apply();

        String routeLine = stop == null
                ? String.format(Locale.getDefault(), "Route distance: %.1f km", routeKm)
                : String.format(Locale.getDefault(), "Route: %.1f km  -  Extra: %.1f km  -  Added fare: Rs. %.0f", routeKm, addedKm, addedCharge);
        resultText.setText(routeLine + "\nEstimated travel: " + durationLabel(travelMinutes)
                + "\nLive arrival time will appear after the driver starts sharing location.");
        showInlineRoute(routeMap, start, stop, end);
    }

    private static void showMapboxError(Activity page, EditText stopInput, Button routeButton,
                                        TextView resultText, int requestNumber, String message) {
        int latestRequest = stopInput.getTag() instanceof Integer ? (Integer) stopInput.getTag() : 0;
        if (requestNumber != latestRequest || page.isFinishing()) return;
        routeButton.setEnabled(true);
        resultText.setText("Mapbox route could not be loaded. Check internet and token settings.");
    }

    private static WebView createMapboxPreview(Activity page) {
        int cardId = id(page, "cardMap");
        View cardView = page.findViewById(cardId);
        if (!(cardView instanceof ViewGroup)) return null;
        ViewGroup card = (ViewGroup) cardView;
        WebView map = new WebView(page);
        WebSettings settings = map.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        map.setWebViewClient(new WebViewClient());
        card.removeAllViews();
        card.addView(map, new ViewGroup.LayoutParams(-1, -1));
        String empty = "<!doctype html><html><body style='margin:0;background:#eef5f0;display:flex;align-items:center;justify-content:center;height:100%;font-family:sans-serif;color:#527060'><div>Route will appear here</div></body></html>";
        map.loadDataWithBaseURL("https://api.mapbox.com/", empty, "text/html", "UTF-8", null);
        return map;
    }

    private static void showInlineRoute(WebView map, Point start, Point stop, Point end) {
        if (map == null) return;
        String coordinates = point(start) + ";" + (stop == null ? "" : point(stop) + ";") + point(end);
        String stopMarker = stop == null ? "" : "new mapboxgl.Marker({color:'#f59e0b'}).setLngLat([" + point(stop) + "]).addTo(map);";
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<link href='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.css' rel='stylesheet'>"
                + "<script src='https://api.mapbox.com/mapbox-gl-js/v3.19.0/mapbox-gl.js'></script>"
                + "<style>html,body,#map{margin:0;width:100%;height:100%;}</style></head><body><div id='map'></div><script>"
                + "mapboxgl.accessToken='" + MAPBOX_TOKEN + "';const map=new mapboxgl.Map({container:'map',style:'mapbox://styles/mapbox/streets-v12',center:["
                + point(start) + "],zoom:11});map.addControl(new mapboxgl.NavigationControl());"
                + "new mapboxgl.Marker({color:'#0b8f4d'}).setLngLat([" + point(start) + "]).addTo(map);" + stopMarker
                + "new mapboxgl.Marker({color:'#dc2626'}).setLngLat([" + point(end) + "]).addTo(map);"
                + "map.on('load',async()=>{const u='https://api.mapbox.com/directions/v5/mapbox/driving/" + coordinates
                + "?geometries=geojson&overview=full&access_token='+mapboxgl.accessToken;const d=await(await fetch(u)).json();if(d.routes&&d.routes[0]){"
                + "map.addSource('route',{type:'geojson',data:{type:'Feature',geometry:d.routes[0].geometry}});map.addLayer({id:'route',type:'line',source:'route',paint:{'line-color':'#0b8f4d','line-width':6}});"
                + "const b=new mapboxgl.LngLatBounds();d.routes[0].geometry.coordinates.forEach(c=>b.extend(c));map.fitBounds(b,{padding:38});}});</script></body></html>";
        map.loadDataWithBaseURL("https://api.mapbox.com/", html, "text/html", "UTF-8", null);
    }

    private static String point(Point point) {
        return String.format(Locale.US, "%.6f,%.6f", point.longitude, point.latitude);
    }

    private static Point findMapboxPlace(String place) throws Exception {
        String encoded = URLEncoder.encode(place, "UTF-8").replace("+", "%20");
        String url = "https://api.mapbox.com/geocoding/v5/mapbox.places/" + encoded
                + ".json?country=pk&limit=1&access_token=" + MAPBOX_TOKEN;
        JSONObject data = readJson(url);
        JSONArray features = data.optJSONArray("features");
        if (features == null || features.length() == 0) return null;
        JSONArray center = features.getJSONObject(0).getJSONArray("center");
        return new Point(center.getDouble(1), center.getDouble(0));
    }

    private static RouteInfo mapboxRoute(Point... points) throws Exception {
        StringBuilder coordinates = new StringBuilder();
        for (Point point : points) {
            if (coordinates.length() > 0) coordinates.append(';');
            coordinates.append(String.format(Locale.US, "%.6f,%.6f", point.longitude, point.latitude));
        }
        String url = "https://api.mapbox.com/directions/v5/mapbox/driving/" + coordinates
                + "?overview=false&access_token=" + MAPBOX_TOKEN;
        JSONObject data = readJson(url);
        JSONArray routes = data.optJSONArray("routes");
        if (routes == null || routes.length() == 0) throw new IllegalStateException("No driving route found");
        JSONObject route = routes.getJSONObject(0);
        return new RouteInfo(route.getDouble("distance") / 1000.0, route.getDouble("duration"));
    }

    private static JSONObject readJson(String address) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(address).openConnection();
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("Accept", "application/json");
        try {
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            reader.close();
            if (status < 200 || status >= 300) throw new IllegalStateException("Mapbox HTTP " + status);
            return new JSONObject(body.toString());
        } finally {
            connection.disconnect();
        }
    }

    private static final class Point {
        final double latitude;
        final double longitude;
        Point(double latitude, double longitude) {
            this.latitude = latitude;
            this.longitude = longitude;
        }
    }

    private static final class RouteInfo {
        final double distanceKm;
        final double durationSeconds;
        RouteInfo(double distanceKm, double durationSeconds) {
            this.distanceKm = distanceKm;
            this.durationSeconds = durationSeconds;
        }
    }

    public static void configurePaymentStep(Activity page) {
        RadioGroup paymentGroup = group(page, "paymentMethodGroup");
        if (paymentGroup != null && paymentGroup.getCheckedRadioButtonId() == -1) {
            RadioButton cash = radio(page, "paymentCash");
            if (cash != null) cash.setChecked(true);
        }
    }

    public static void addPaymentToBooking(Activity page, Map<String, Object> bookingData) {
        RadioGroup paymentGroup = group(page, "paymentMethodGroup");
        if (paymentGroup == null) return;
        RadioButton selected = page.findViewById(paymentGroup.getCheckedRadioButtonId());
        String paymentMethod = selected == null ? "Cash on Delivery" : selected.getText().toString();
        bookingData.put("paymentMethod", paymentMethod);
        bookingData.put("paymentStatus", "Pending");
        int routeMinutes = page.getSharedPreferences("booking_steps", 0).getInt("routeDurationMinutes", 0);
        if (routeMinutes > 0) {
            bookingData.put("routeDurationMinutes", routeMinutes);
            bookingData.put("estimatedDurationMinutes", routeMinutes);
            bookingData.put("routeCalculatedAt", page.getSharedPreferences("booking_steps", 0)
                    .getLong("routeCalculatedAt", System.currentTimeMillis()));
        }
        String extraStop = page.getSharedPreferences("booking_steps", 0).getString("extraStop", "");
        if (extraStop != null && !extraStop.isEmpty()) {
            bookingData.put("extraStop", extraStop);
            bookingData.put("extraStopAddedKm", page.getSharedPreferences("booking_steps", 0)
                    .getFloat("extraStopAddedKm", 0));
            bookingData.put("routeDistanceKm", page.getSharedPreferences("booking_steps", 0)
                    .getFloat("routeDistanceKm", 0));
        }
    }

    private static Address findAddress(Geocoder geocoder, String place) {
        try {
            List<Address> matches = geocoder.getFromLocationName(place, 1);
            return matches == null || matches.isEmpty() ? null : matches.get(0);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static double distanceKm(Address first, Address second) {
        double earthRadius = 6371.0;
        double lat1 = Math.toRadians(first.getLatitude());
        double lat2 = Math.toRadians(second.getLatitude());
        double latChange = Math.toRadians(second.getLatitude() - first.getLatitude());
        double lngChange = Math.toRadians(second.getLongitude() - first.getLongitude());
        double value = Math.sin(latChange / 2) * Math.sin(latChange / 2)
                + Math.cos(lat1) * Math.cos(lat2) * Math.sin(lngChange / 2) * Math.sin(lngChange / 2);
        return earthRadius * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
    }

    private static String durationLabel(int minutes) {
        if (minutes < 60) return minutes + " min";
        int hours = minutes / 60;
        int left = minutes % 60;
        return left == 0 ? hours + " hr" : hours + " hr " + left + " min";
    }

    private static void setField(Activity page, String fieldName, Object value) {
        try {
            Field field = page.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(page, value);
        } catch (Exception ignored) { }
    }

    private static void callDrawRoute(Activity page) {
        try {
            Method method = page.getClass().getDeclaredMethod("drawRoute");
            method.setAccessible(true);
            method.invoke(page);
        } catch (Exception ignored) { }
    }

    private static int id(Activity page, String name) {
        return page.getResources().getIdentifier(name, "id", page.getPackageName());
    }
    private static EditText input(Activity page, String name) { return page.findViewById(id(page, name)); }
    private static Button button(Activity page, String name) { return page.findViewById(id(page, name)); }
    private static TextView text(Activity page, String name) { return page.findViewById(id(page, name)); }
    private static RadioGroup group(Activity page, String name) { return page.findViewById(id(page, name)); }
    private static RadioButton radio(Activity page, String name) { return page.findViewById(id(page, name)); }
}
