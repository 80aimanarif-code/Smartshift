package cyberorion.pk.features;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

/** The small bridge called by the preserved original screens. */
public final class FeatureEntry {
    private FeatureEntry() { }

    public static void attach(Activity activity) {
        String bookingId = activity.getIntent().getStringExtra("extra_booking_id");
        if (bookingId == null || activity.isFinishing()) return;
        if ("TrackingActivity".equals(activity.getClass().getSimpleName())) {
            LiveTrackingMap.attach(activity, bookingId);
        }
        int anchorId = activity.getResources().getIdentifier("btnConfirmBooking", "id", activity.getPackageName());
        View anchor = activity.findViewById(anchorId);
        if (anchor == null) {
            anchorId = activity.getResources().getIdentifier("btnDamageComparison", "id", activity.getPackageName());
            anchor = activity.findViewById(anchorId);
        }
        if (anchor == null || !(anchor.getParent() instanceof LinearLayout)) return;
        LinearLayout parent = (LinearLayout) anchor.getParent();
        if (parent.findViewWithTag("booking-services") != null) return;
        Button button = new Button(activity);
        button.setTag("booking-services");
        button.setText("Payment, services & delivery");
        button.setAllCaps(false);
        if (anchor instanceof Button) button.setTypeface(((Button) anchor).getTypeface());
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color(activity, "primaryColor", 0xff078443));
        shape.setCornerRadius(12 * activity.getResources().getDisplayMetrics().density);
        button.setBackground(shape);
        button.setTextColor(Color.WHITE);
        int space = (int) (12 * activity.getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, space * 4);
        params.setMargins(space, space, space, space);
        parent.addView(button, parent.indexOfChild(anchor), params);
        button.setOnClickListener(view -> open(activity, bookingId));
    }

    public static void open(Activity activity, String bookingId) {
        if (bookingId == null) return;
        activity.startActivity(new Intent(activity, BookingServicesActivity.class)
                .putExtra("extra_booking_id", bookingId));
    }

    public static void attachDriverDashboard(Activity activity) {
        int id = activity.getResources().getIdentifier("driverHeader", "id", activity.getPackageName());
        View view = activity.findViewById(id);
        if (!(view instanceof LinearLayout)) return;
        Button button = new Button(activity); button.setText("Booking services & messages"); button.setAllCaps(false);
        ((LinearLayout) view).addView(button, new LinearLayout.LayoutParams(-1, -2));
        button.setOnClickListener(v -> activity.startActivity(new Intent(activity, BookingPickerActivity.class)));
    }

    public static void agreeFare(Activity activity, String bookingId, double amount) {
        try {
            new BookingServices(bookingId).agreeFare(amount, error -> Toast.makeText(activity,
                    error == null ? "Fare agreed. Selected service charges are included." : error,
                    Toast.LENGTH_LONG).show());
        } catch (RuntimeException e) {
            Toast.makeText(activity, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    static int color(Activity activity, String name, int fallback) {
        int id = activity.getResources().getIdentifier(name, "color", activity.getPackageName());
        return id == 0 ? fallback : activity.getColor(id);
    }
}
