package cyberorion.pk.features;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Local review-build policy: at most 10% off the estimated base fare. */
public final class FareLimitRules {
    private FareLimitRules() { }

    public static long paisa(double rupees) {
        if (!Double.isFinite(rupees) || rupees <= 0) throw new IllegalArgumentException("Enter a positive fare.");
        long result = BigDecimal.valueOf(rupees).movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP).longValueExact();
        if (result <= 0) throw new IllegalArgumentException("Enter a positive fare.");
        return result;
    }

    public static long offer(String text) {
        BigDecimal value = new BigDecimal(text.trim());
        long amount = value.movePointRight(2).setScale(0, RoundingMode.UNNECESSARY).longValueExact();
        if (amount <= 0) throw new IllegalArgumentException("Enter a positive fare.");
        return amount;
    }

    public static long minimum(long estimatedBase) {
        if (estimatedBase <= 0) throw new IllegalArgumentException("Fare estimate is unavailable.");
        return BigDecimal.valueOf(estimatedBase).multiply(new BigDecimal("0.90"))
                .setScale(0, RoundingMode.CEILING).longValueExact();
    }

    public static long total(long base, long extras) {
        if (base <= 0 || extras < 0) throw new IllegalArgumentException("Invalid fare charges.");
        return Math.addExact(base, extras);
    }

    public static boolean allowed(long offer, long estimatedBase) {
        return offer >= minimum(estimatedBase);
    }

    public static String money(long paisa) {
        return "Rs. " + BigDecimal.valueOf(paisa, 2).stripTrailingZeros().toPlainString();
    }
}
