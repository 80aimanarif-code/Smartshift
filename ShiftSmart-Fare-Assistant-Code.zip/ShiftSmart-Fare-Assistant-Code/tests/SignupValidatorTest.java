package cyberorion.pk.features;

public class SignupValidatorTest {
    private static int checks = 0;

    private static void check(boolean value, String message) {
        checks++;
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        check("03001234567".equals(SignupValidator.normalizePakistaniNumber("03001234567")), "local number");
        check("03001234567".equals(SignupValidator.normalizePakistaniNumber("+923001234567")), "international number");
        check("03001234567".equals(SignupValidator.normalizePakistaniNumber("+92 300-1234567")), "formatted number");
        check(SignupValidator.normalizePakistaniNumber("04001234567") == null, "invalid network prefix");
        check(SignupValidator.normalizePakistaniNumber("923001234567") == null, "missing plus or zero");
        check(SignupValidator.normalizePakistaniNumber("0300123456") == null, "short number");
        check(SignupValidator.normalizePakistaniNumber("030012345678") == null, "long number");
        check(SignupValidator.normalizePakistaniNumber(null) == null, "null number");

        check(SignupValidator.isStrongPassword("Student@123"), "valid password");
        check(!SignupValidator.isStrongPassword("student123"), "missing symbol");
        check(!SignupValidator.isStrongPassword("student@abc"), "missing number");
        check(!SignupValidator.isStrongPassword("1234567@"), "missing letter");
        check(!SignupValidator.isStrongPassword("Stu@123"), "short password");
        check(!SignupValidator.isStrongPassword("Student @123"), "space in password");
        System.out.println(checks + " signup validation checks passed.");
    }
}
