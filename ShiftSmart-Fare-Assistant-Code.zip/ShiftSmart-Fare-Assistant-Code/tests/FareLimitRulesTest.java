import cyberorion.pk.features.FareLimitRules;

public class FareLimitRulesTest {
    private static int checks;
    private static void check(boolean condition) {
        checks++;
        if (!condition) throw new AssertionError("Check " + checks + " failed");
    }
    private static void rejects(Runnable action) {
        boolean rejected = false;
        try { action.run(); } catch (RuntimeException expected) { rejected = true; }
        check(rejected);
    }
    public static void main(String[] args) {
        long base = FareLimitRules.paisa(5000);
        check(FareLimitRules.minimum(base) == 450000);
        check(!FareLimitRules.allowed(FareLimitRules.offer("4000"), base));
        check(!FareLimitRules.allowed(FareLimitRules.offer("4499.99"), base));
        check(FareLimitRules.allowed(FareLimitRules.offer("4500"), base));
        check(FareLimitRules.allowed(FareLimitRules.offer("4700"), base));
        check(FareLimitRules.allowed(FareLimitRules.offer("6000"), base));
        check(FareLimitRules.total(FareLimitRules.minimum(base), 160000) == 610000);
        check(FareLimitRules.minimum(base) == 450000); // counteroffers do not lower the baseline
        check(FareLimitRules.minimum(101) == 91); // ceiling never grants more than 10%
        check(FareLimitRules.minimum(1) == 1);
        check(FareLimitRules.paisa(100.123456) == 10012); // unrounded legacy estimates
        check(FareLimitRules.offer(" 4500.50 ") == 450050);
        check(FareLimitRules.money(450000).equals("Rs. 4500"));
        check(FareLimitRules.money(450050).equals("Rs. 4500.5"));
        rejects(() -> FareLimitRules.offer(""));
        rejects(() -> FareLimitRules.offer("abc"));
        rejects(() -> FareLimitRules.offer("NaN"));
        rejects(() -> FareLimitRules.offer("Infinity"));
        rejects(() -> FareLimitRules.offer("0"));
        rejects(() -> FareLimitRules.offer("-100"));
        rejects(() -> FareLimitRules.offer("4500.001"));
        rejects(() -> FareLimitRules.offer("999999999999999999999"));
        rejects(() -> FareLimitRules.paisa(Double.NaN));
        rejects(() -> FareLimitRules.paisa(Double.POSITIVE_INFINITY));
        rejects(() -> FareLimitRules.paisa(0));
        rejects(() -> FareLimitRules.paisa(0.001));
        rejects(() -> FareLimitRules.minimum(0));
        rejects(() -> FareLimitRules.total(base, -1));
        rejects(() -> FareLimitRules.total(Long.MAX_VALUE, 1));
        System.out.println(checks + " fare-limit checks passed");
    }
}
