import cyberorion.pk.features.LiveTrackingRules;

public class LiveTrackingRulesTest {
    private static int passed;
    private static void check(boolean value) {
        if (!value) throw new AssertionError();
        passed++;
    }
    private static void rejects(Runnable action) {
        try { action.run(); } catch (IllegalArgumentException | ArithmeticException expected) { passed++; return; }
        throw new AssertionError("Invalid live tracking value accepted");
    }
    public static void main(String[] args) {
        check(!LiveTrackingRules.routeToDropoff("Driver En Route"));
        check(LiveTrackingRules.routeToDropoff("Picked Up"));
        check(LiveTrackingRules.routeToDropoff("Out for Delivery"));
        check(LiveTrackingRules.remainingMinutes(1) == 1);
        check(LiveTrackingRules.remainingMinutes(121) == 3);
        rejects(() -> LiveTrackingRules.remainingMinutes(-1));
        check(LiveTrackingRules.arrivalAt(1000, 2) == 121000);
        rejects(() -> LiveTrackingRules.arrivalAt(1000, 0));
        check("Truck is very near".equals(LiveTrackingRules.proximity(0.9)));
        check("Truck is near".equals(LiveTrackingRules.proximity(3.2)));
        check(LiveTrackingRules.proximity(8.25).contains("8.3 km"));
        rejects(() -> LiveTrackingRules.proximity(-0.1));
        check(!LiveTrackingRules.locationDelayed(200000, 100000));
        check(LiveTrackingRules.locationDelayed(300001, 100000));
        System.out.println("PASS: " + passed + " live tracking checks");
    }
}
