import cyberorion.pk.features.FeatureRules;

public class FeatureRulesTest {
    private static int passed;
    private static void equal(long expected, long actual) {
        if (expected != actual) throw new AssertionError(expected + " != " + actual);
        passed++;
    }
    private static void rejects(Runnable action) {
        try { action.run(); } catch (IllegalArgumentException | IllegalStateException | ArithmeticException expected) {
            passed++; return;
        }
        throw new AssertionError("Invalid action was accepted.");
    }
    public static void main(String[] args) {
        equal(0, FeatureRules.packingCharge(false, false, 0, 50000, 30000));
        equal(100000, FeatureRules.packingCharge(true, false, 2, 50000, 30000));
        equal(60000, FeatureRules.packingCharge(false, true, 2, 50000, 30000));
        equal(160000, FeatureRules.packingCharge(true, true, 2, 50000, 30000));
        rejects(() -> FeatureRules.packingCharge(true, false, 0, 50000, 30000));
        rejects(() -> FeatureRules.packingCharge(true, true, 11, 50000, 30000));
        rejects(() -> FeatureRules.packingCharge(false, false, 1, 50000, 30000));
        rejects(() -> FeatureRules.packingCharge(true, false, 1, -1, 0));
        equal(460000, FeatureRules.total(300000, 160000));
        // Recalculate from the base fare; never feed an already adjusted total back in.
        equal(400000, FeatureRules.total(300000, 100000));
        rejects(() -> FeatureRules.total(-1, 100));
        rejects(() -> FeatureRules.total(Long.MAX_VALUE, 1));
        FeatureRules.checkRating(true, false, 5, "Good service"); passed++;
        rejects(() -> FeatureRules.checkRating(false, false, 5, ""));
        rejects(() -> FeatureRules.checkRating(true, true, 5, ""));
        rejects(() -> FeatureRules.checkRating(true, false, 0, ""));
        rejects(() -> FeatureRules.checkRating(true, false, 6, ""));
        rejects(() -> FeatureRules.checkRating(true, false, 4, new String(new char[501]).replace('\0', 'a')));
        equal(0, (long) FeatureRules.ratingAverage(0, 0));
        equal(450, Math.round(FeatureRules.ratingAverage(9, 2) * 100));
        rejects(() -> FeatureRules.ratingAverage(11, 2));
        FeatureRules.checkCashReceipt(true, false, 460000, 460000); passed++;
        rejects(() -> FeatureRules.checkCashReceipt(false, false, 460000, 460000));
        rejects(() -> FeatureRules.checkCashReceipt(true, true, 460000, 460000));
        rejects(() -> FeatureRules.checkCashReceipt(true, false, 460000, 450000));
        FeatureRules.checkProof("delivery/booking-1/photo.jpg", "Recipient", true); passed++;
        rejects(() -> FeatureRules.checkProof("", "Recipient", true));
        rejects(() -> FeatureRules.checkProof("photo.jpg", " ", true));
        rejects(() -> FeatureRules.checkProof("photo.jpg", "Recipient", false));
        long now = 1800000000000L;
        FeatureRules.checkSchedule(now + 1800000, now); passed++;
        FeatureRules.checkSchedule(now + 90L * 86400000, now); passed++;
        rejects(() -> FeatureRules.checkSchedule(now - 1, now));
        rejects(() -> FeatureRules.checkSchedule(now + 1799999, now));
        rejects(() -> FeatureRules.checkSchedule(now + 90L * 86400000 + 1, now));
        equal(0, FeatureRules.cleanStops(java.util.Collections.emptyList()).size());
        equal(2, FeatureRules.cleanStops(java.util.Arrays.asList("  Main Road 12 ", "Mall Road 8")).size());
        rejects(() -> FeatureRules.cleanStops(java.util.Arrays.asList("Main Road 12", " main road 12 ")));
        rejects(() -> FeatureRules.cleanStops(java.util.Arrays.asList("", "Mall Road 8")));
        rejects(() -> FeatureRules.cleanStops(java.util.Arrays.asList("Road 1", "Road 2", "Road 3", "Road 4")));
        rejects(() -> FeatureRules.cleanMessage("   "));
        rejects(() -> FeatureRules.cleanMessage(new String(new char[1001]).replace('\0', 'a')));
        if (!"Hello driver".equals(FeatureRules.cleanMessage(" Hello driver "))) throw new AssertionError();
        passed++;
        equal(480000, FeatureRules.total(300000, FeatureRules.total(160000, 20000)));
        equal(27000, FeatureRules.distanceCharge(4.5, 6000));
        equal(0, FeatureRules.distanceCharge(0, 6000));
        rejects(() -> FeatureRules.distanceCharge(-1, 6000));
        rejects(() -> FeatureRules.distanceCharge(501, 6000));
        if (!"jazzcash".equals(FeatureRules.cleanPaymentMethod("jazzcash"))) throw new AssertionError();
        passed++;
        rejects(() -> FeatureRules.cleanPaymentMethod("card"));
        System.out.println("PASS: " + passed + " business rule checks");
    }
}
