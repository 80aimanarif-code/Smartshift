## Fare assistant update - 06 October 2026

The packaged `ShiftSmart-Live-Tracking.apk` now contains the exact updated
`ShiftSmart-Fare-Assistant.apk` build delivered separately. Its SHA-256 is
`1ed2b4302a3194745d7e6536f7250bcff52ec95d7d96bf8b45b9e3408b947d14`. APK size: 11,388,173 bytes.

Only fare negotiation was changed in this update. The screen gives immediate
guidance while typing and includes a **How much can I reduce?** button. The
minimum base offer is 90% of the original estimated fare, rounded upward to the
nearest paisa. This is an explicit local review-build policy, not a trained AI
model, fuel-cost model, live market price, or a driver-generated counteroffer.
Packing/unpacking and saved extra-stop fees are added without discount.

Offers below the minimum are blocked before sending; accepting an older offer
below the limit is also blocked. Valid offers still require driver acceptance.
The helper reads booking data and does not automatically accept, dispatch, or
write a synthetic driver response. Pending/error states request a verified fare
rather than silently allowing an unchecked offer.

Example: Rs. 5,000 estimated base -> Rs. 4,500 minimum base. Rs. 4,000 is blocked;
Rs. 4,700 is allowed to be sent. With Rs. 1,600 extra services, the minimum total
is Rs. 6,100. The offer field is the base fare; extras are displayed separately
in the assistant's total.

New readable code: `FareAssistant.java` and `FareLimitRules.java`.
New test: `tests/FareLimitRulesTest.java` (29 checks passed).
Updated integration: `integration/NegotiationActivity.smali`.
The existing rebuild script now invokes `build/patch_fare_assistant.py` after its
prior hooks and compiles these helpers through the existing feature-source glob.
Its existing external tool/input requirements remain; a full rebuild from that
script and Android Studio Gradle sync have not been rerun in this update.

APK v2/v3 signatures verified with the supplied build's same certificate.
Compared with the supplied live-tracking APK, only `classes3.dex` changed and
`classes6.dex` was added, excluding regenerated signing metadata. Within
classes3, only NegotiationActivity changed; all other original classes and all
other packaged content were preserved. Real-phone/emulator and live Firebase
tests remain pending. These limits are local app behavior; no backend rules or
deployment were changed. Existing documentation below describes the prior build.

---

# ShiftSmart Android review package

This package extends the supplied Android APK with eight non-AI booking features, safer signup validation, direct additions to booking Steps 3, 4 and 5, and a clearer admin driver-approval entry point. It contains a signed review APK, readable new Java source, recovered reference code and layouts, backend source, and test results. It is **not a verified production release**. Android device testing and Firebase setup are still required.

## Start here

1. Open `feature-source/cyberorion/pk/features/` or `New-Android-Code.txt` to review the new code.
2. Read `UI-AND-ADMIN-FIXES.md`, `MANUAL-TESTS.md` and `validation.json` for the scope and evidence.
3. Use `ShiftSmart-Live-Tracking.apk` on a test device after configuring the backend and reviewing its permissions. It uses the original package name and a new review signing certificate. It cannot normally update an installation signed with the original key. Do not remove your only working installation to try it; use a separate test device or emulator.
4. Follow `backend/README.md` before claiming that reviews, chat or other online flows are fully working.

## Implemented source

| Feature | Added behavior | Current boundary |
|---|---|---|
| Payment | JazzCash, Easypaisa, bank transfer and cash selection; pending/paid states and cash receipt | Digital options are visibly labelled FYP demos; no gateway or real account |
| Reviews | One customer review per completed booking; 1-5 stars and comment | Driver average requires the supplied server function |
| Packing | Packing/unpacking, worker count, itemized surcharge, service progress | Sample Rs. 500/300 per-worker tariff |
| Delivery proof | Compressed shared photo, recipient name, customer confirmation | Uses Realtime Database photos; device tests pending |
| Chat | Booking-specific live messages and closed-booking read-only history | New database rules required; no push notifications |
| Schedule | Pickup date/time, reschedule/remove while pending | Stores a reservation; no automatic dispatch or reminders |
| Extra stops | Up to 3 ordered pickup/drop stops, next-stop navigation and Rs. 60 per additional kilometre | Mapbox calculates the road route and additional distance; an on-device route test is still required |
| Status and sharing | Current status, lifecycle explanation, booking-detail sharing | Shares a timestamped snapshot, not a public live tracking URL |

Customer signup now accepts Pakistani mobile numbers in `03XXXXXXXXX` or `+923XXXXXXXXX` format and stores a normalized `03...` number. Customer and driver signup passwords require 8-64 characters with at least one letter, one number and one symbol. Spaces are rejected.

The main booking flow now shows packing/unpacking in Step 3, an optional middle stop in Step 4, and JazzCash, Easypaisa, bank transfer and cash-on-delivery choices in Step 5. Step 4 uses Mapbox geocoding and driving directions, includes the middle stop when calculating route kilometres, and automatically updates an inline route map after the user stops typing. The old Google map view and separate route button are hidden. The existing Rs. 45/km fare rule therefore charges the longer route. Demo payment details do not process real money.

Step 4 also shows the Mapbox driving duration. When the driver changes the live booking status, the app records acceptance, departure for pickup, pickup arrival, item pickup and delivery start times. Starting delivery calculates the expected arrival from the actual departure time. Delivery proof records the delivered time and customer confirmation records completion time.

The tracking screen replaces the visible Google map with Mapbox. It listens to the existing Firebase live driver coordinates, moves the truck marker, requests the remaining road route, and shows whether the truck is near, remaining kilometres/minutes, expected pickup or delivery arrival, last location-update time, and a delayed-signal warning. Step 4 only shows route duration; it no longer presents a hypothetical “dispatch now” arrival.

## Preservation and integration

The Step 2 category card layout now uses an equal 170dp height, two-line titles and three-line descriptions. This prevents the Electronics, Glass Items and Appliances cards from collapsing when RecyclerView reuses them. The booking-services screen uses compact spacing, the app's green buttons, ASCII route separators, and hides demo payment instructions from drivers. New screens inherit the original app theme and reuse the background/primary color resources.

New driver accounts are saved with a pending approval status. The admin dashboard now shows the number of pending driver requests on its Driver approvals button. The existing driver-management screen shows the driver's photo, email, vehicle, rating, completed trips and experience, and lets the admin approve, reject, disable or enable the account. A pending driver cannot sign in until an admin approves the account.

Nine original classes are patched: `BookingReviewActivity`, `TrackingActivity`, `DriverDashboardActivity`, `AdminDashboardActivity`, `NegotiationActivity`, `SignUpActivity`, `DriverSignUpActivity`, `BookingActivity`, and `DriverSelectionActivity`. Four layouts are intentionally updated for Step 2 through Step 5. Original fare-estimation, vehicle recommendation and damage-risk code is preserved.

## Source provenance

`recovered-reference` is output recovered from the APK. It is for inspection and is not the original Android Studio project. Decompiled Java includes synthetic names and at least one unresolved fare-estimator method. Do not claim that this folder can compile as a complete app or that it was manually written. The APK preserves the original compiled implementation for those parts.

`feature-source` contains new readable Java. `android-feature-library` is an Android Studio library project for those new classes, not a replacement full-app project. It has no Gradle wrapper; use Gradle 8.9/JDK 17 with Android SDK 35. Its Gradle sync is untested here, while the same source was compiled separately against Android and Firebase APIs.

`build/patch_apk.py` and `build/rebuild.ps1` document the repeatable APK extension process. Required tools are JDK 17, Python 3, Apktool 3.0.3 and Android SDK Build Tools 35.0.0. Tools are not bundled. The untouched original APK is included for reproducibility.

## Verification

- 49 Android-independent business-rule checks passed.
- 14 live-tracking rule checks passed.
- 14 signup validation checks passed.
- 15 server aggregation checks passed, including duplicate-event handling.
- New Java compilation, DEX generation and APK assembly passed.
- APK v2/v3 signatures verified.
- Original smali preservation and the intended Step 2 through Step 5 resource changes were checked statically.
- No emulator/phone tests, live Firebase tests, backend deployment or payment-gateway tests were performed. The Mapbox classes and configuration were compiled and packaged, but the supplied token could not be called from this build environment and needs one on-device route test.

Do not label all eight features production-complete until the manual checklist and backend authorization tests pass. Existing app bugs outside this extension have not been comprehensively audited or fixed.
