# Device and backend test checklist

All checks below are **not run**. Use separate customer and driver test accounts and a test Firebase project. Existing functionality needs regression testing as well as the new controls.

| Scenario | Expected outcome |
|---|---|
| Sign in, cargo selection, vehicle/fare, negotiation | Existing workflow remains usable |
| Open booking review, tracking, driver dashboard | Existing content visible; new button does not overlap controls |
| Light/dark mode, small display, keyboard, rotation | Controls legible and tappable; input not clipped |
| Add two packing/unpacking workers | Packing Rs. 1,000 + unpacking Rs. 600; final total increases once |
| Change/remove services and add/remove stops | Base fare retained; surcharges recalculated, never doubled |
| Negotiate with extras selected | Agreed base plus all surcharges shown consistently |
| Select cash | Status pending, no false paid receipt |
| Complete service and delivery, confirm as customer | Customer confirmation changes status to Completed |
| Record cash as assigned driver | Correct amount, immutable receipt, duplicate blocked |
| Upload large/invalid image or revoke photo access | Clear error; no false delivery completion |
| Open proof as customer on another device | Shared photo and recipient visible |
| Submit review twice, review before completion | Invalid actions rejected; one server aggregate update |
| Unrelated account attempts any booking mutation | Server rules reject, even through direct database requests |
| Chat between two participants and after closure | Messages sync; closed-booking chat is read-only |
| Disconnect during send/save, reconnect | No false success; retries do not duplicate payment/review |
| Schedule in past, too soon, beyond 90 days | Invalid time rejected |
| Reschedule after driver acceptance | Change rejected |
| Add duplicate/too many stops or invalid distance | Validation error; prior stops retained; Rs. 60/km matches the entered additional distance |
| Driver completes stops out of sequence/twice | Invalid/stale completion rejected |
| Share details/receipt and cancel Android share sheet | Correct snapshot shared only when selected; cancellation safe |
| Check map, SOS, damage, complaints, admin, notifications | Existing features verified independently |
| Verify legacy bookings without serviceExtras | Safe defaults and readable history |
| Replay review/completion server events | Counts and averages remain correct |

Scheduling does not automatically dispatch a driver. The user checks the route in Google Maps and enters the additional kilometres; automatic road-distance calculation requires a configured routing API. Digital payment choices are FYP simulations and must remain demo-labelled. Sharing is not public live tracking.
# Signup validation

- Customer signup accepts `03001234567` and `+923001234567`.
- The international form is changed to `03...` before the account is saved.
- Customer signup rejects a missing `+`/`0`, wrong prefix, letters, and short or long numbers.
- Customer and driver signup reject passwords shorter than 8 characters or missing a letter, number, or symbol.
- Both signup screens accept a password such as `Student@123` and show the original signup flow afterward.
# Delivery timing check

1. In Step 4 enter pickup and drop-off addresses and wait for the automatic route.
2. Confirm distance, estimated travel time, and arrival day/date/time appear below the map.
3. Complete a test booking and move it to Out for Delivery from the driver account.
4. Open Booking services from the customer tracking screen.
5. Confirm Delivery started and Expected arrival use the driver's actual departure time.
6. Submit delivery proof and confirm Delivered time appears; customer confirmation should add Customer confirmed time.

# Mapbox live tracking check

1. Open the same active booking on a driver phone and a customer phone.
2. On the driver phone open Live Tracking, grant location permission and tap Start Sharing Location.
3. On the customer phone open Live Tracking and confirm the visible map is Mapbox.
4. Confirm the blue truck marker moves after driver location updates.
5. Before pickup, confirm the remaining route and arrival refer to the pickup location.
6. Move the booking to Picked Up or Out for Delivery and confirm the route changes to drop-off.
7. Confirm remaining kilometres, remaining minutes, expected arrival day/date/time and location-update time change.
8. Stop driver updates for more than two minutes and confirm Location signal is delayed appears.

# Fare assistant update - device checks (not run)

- Open negotiation with a Rs. 5,000 base estimate. Check maximum reduction:
  Rs. 500 and minimum base Rs. 4,500.
- Enter Rs. 4,000 and tap Send: immediate minimum-fare response; no offer write.
- Enter Rs. 4,499.99: blocked. Enter Rs. 4,500 or Rs. 4,700: allowed for sending.
- Use Rs. 1,600 service charges: minimum total Rs. 6,100, without discounting extras.
- Send a valid offer: require the other participant's actual acceptance; no auto-accept.
- Receive an old below-limit offer: accepting it must be blocked.
- Check empty, zero, negative, malformed and more-than-two-decimal input.
- Reopen/rotate the screen: no duplicate assistant; listeners removed on destruction.
- Complete negotiation: assistant reflects completion and no new fare submission.
- Check offline/denied/missing booking: no unchecked fare send or false success.
- Check small screen, keyboard, scrolling and original negotiation actions.
- Verify driver suggestion, tracking and other screens remain usable.

The new policy is enforced in this APK's negotiation UI. Server authorization
and enforcement of the same minimum across older clients are not part of this update.
