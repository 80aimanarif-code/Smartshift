.class public Lcyberorion/pk/TrackingActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "TrackingActivity.java"

# interfaces
.implements Lcom/google/android/gms/maps/OnMapReadyCallback;


# static fields
.field private static final LOCATION_INTERVAL_MS:J = 0x1388L

.field private static final LOCATION_MIN_INTERVAL_MS:J = 0x7d0L

.field private static final MAP_VIEW_BUNDLE_KEY:Ljava/lang/String; = "MapViewBundleKey"


# instance fields
.field private activeSosQuery:Lcom/google/firebase/database/Query;

.field private bookingId:Ljava/lang/String;

.field private bookingRef:Lcom/google/firebase/database/DatabaseReference;

.field private btnToggleSharing:Lcom/google/android/material/button/MaterialButton;

.field private currentBooking:Lcyberorion/pk/Booking;

.field private driverMarker:Lcom/google/android/gms/maps/model/Marker;

.field private dropoffLat:Ljava/lang/Double;

.field private dropoffLng:Ljava/lang/Double;

.field private fabSos:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

.field private fusedLocationClient:Lcom/google/android/gms/location/FusedLocationProviderClient;

.field private googleMap:Lcom/google/android/gms/maps/GoogleMap;

.field private layoutDriverControls:Landroid/view/View;

.field private locationCallback:Lcom/google/android/gms/location/LocationCallback;

.field private locationPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/activity/result/ActivityResultLauncher<",
            "[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private mapView:Lcom/google/android/gms/maps/MapView;

.field private pickupLat:Ljava/lang/Double;

.field private pickupLng:Ljava/lang/Double;

.field private role:Ljava/lang/String;

.field private routeDrawn:Z

.field private sharingLocation:Z

.field private trackingRef:Lcom/google/firebase/database/DatabaseReference;

.field private tvSosBanner:Landroid/widget/TextView;

.field private tvTripRoute:Landroid/widget/TextView;

.field private tvTripStatus:Landroid/widget/TextView;


# direct methods
.method static bridge synthetic -$$Nest$fgetbookingId(Lcyberorion/pk/TrackingActivity;)Ljava/lang/String;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdriverMarker(Lcyberorion/pk/TrackingActivity;)Lcom/google/android/gms/maps/model/Marker;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdropoffLat(Lcyberorion/pk/TrackingActivity;)Ljava/lang/Double;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->dropoffLat:Ljava/lang/Double;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetgoogleMap(Lcyberorion/pk/TrackingActivity;)Lcom/google/android/gms/maps/GoogleMap;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetpickupLat(Lcyberorion/pk/TrackingActivity;)Ljava/lang/Double;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettvSosBanner(Lcyberorion/pk/TrackingActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->tvSosBanner:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettvTripRoute(Lcyberorion/pk/TrackingActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->tvTripRoute:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgettvTripStatus(Lcyberorion/pk/TrackingActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/TrackingActivity;->tvTripStatus:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputcurrentBooking(Lcyberorion/pk/TrackingActivity;Lcyberorion/pk/Booking;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->currentBooking:Lcyberorion/pk/Booking;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputdriverMarker(Lcyberorion/pk/TrackingActivity;Lcom/google/android/gms/maps/model/Marker;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputdropoffLat(Lcyberorion/pk/TrackingActivity;Ljava/lang/Double;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->dropoffLat:Ljava/lang/Double;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputdropoffLng(Lcyberorion/pk/TrackingActivity;Ljava/lang/Double;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->dropoffLng:Ljava/lang/Double;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpickupLat(Lcyberorion/pk/TrackingActivity;Ljava/lang/Double;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    return-void
.end method

.method static bridge synthetic -$$Nest$fputpickupLng(Lcyberorion/pk/TrackingActivity;Ljava/lang/Double;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->pickupLng:Ljava/lang/Double;

    return-void
.end method

.method static bridge synthetic -$$Nest$mdrawRouteOnce(Lcyberorion/pk/TrackingActivity;)V
    .locals 0

    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->drawRouteOnce()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mpushDriverLocation(Lcyberorion/pk/TrackingActivity;Landroid/location/Location;)V
    .locals 0

    invoke-direct {p0, p1}, Lcyberorion/pk/TrackingActivity;->pushDriverLocation(Landroid/location/Location;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 65
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    .line 91
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->sharingLocation:Z

    .line 231
    iput-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->routeDrawn:Z

    return-void
.end method

.method private beginSharing()V
    .locals 5

    .line 316
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->hasLocationPermission()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    .line 318
    :cond_0
    new-instance v0, Lcom/google/android/gms/location/LocationRequest$Builder;

    const-wide/16 v1, 0x1388

    invoke-direct {v0, v1, v2}, Lcom/google/android/gms/location/LocationRequest$Builder;-><init>(J)V

    .line 319
    const-wide/16 v1, 0x7d0

    invoke-virtual {v0, v1, v2}, Lcom/google/android/gms/location/LocationRequest$Builder;->setMinUpdateIntervalMillis(J)Lcom/google/android/gms/location/LocationRequest$Builder;

    move-result-object v0

    .line 320
    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Lcom/google/android/gms/location/LocationRequest$Builder;->setPriority(I)Lcom/google/android/gms/location/LocationRequest$Builder;

    move-result-object v0

    .line 321
    invoke-virtual {v0}, Lcom/google/android/gms/location/LocationRequest$Builder;->build()Lcom/google/android/gms/location/LocationRequest;

    move-result-object v0

    .line 323
    .local v0, "request":Lcom/google/android/gms/location/LocationRequest;
    new-instance v1, Lcyberorion/pk/TrackingActivity$4;

    invoke-direct {v1, p0}, Lcyberorion/pk/TrackingActivity$4;-><init>(Lcyberorion/pk/TrackingActivity;)V

    iput-object v1, p0, Lcyberorion/pk/TrackingActivity;->locationCallback:Lcom/google/android/gms/location/LocationCallback;

    .line 332
    const/4 v1, 0x1

    :try_start_0
    iget-object v2, p0, Lcyberorion/pk/TrackingActivity;->fusedLocationClient:Lcom/google/android/gms/location/FusedLocationProviderClient;

    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->locationCallback:Lcom/google/android/gms/location/LocationCallback;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-interface {v2, v0, v3, v4}, Lcom/google/android/gms/location/FusedLocationProviderClient;->requestLocationUpdates(Lcom/google/android/gms/location/LocationRequest;Lcom/google/android/gms/location/LocationCallback;Landroid/os/Looper;)Lcom/google/android/gms/tasks/Task;
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 336
    nop

    .line 338
    iput-boolean v1, p0, Lcyberorion/pk/TrackingActivity;->sharingLocation:Z

    .line 339
    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->btnToggleSharing:Lcom/google/android/material/button/MaterialButton;

    const-string v2, "Stop Sharing Location"

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 340
    const-string v1, "Sharing your live location with the customer"

    const/4 v2, 0x0

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 344
    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->fusedLocationClient:Lcom/google/android/gms/location/FusedLocationProviderClient;

    invoke-interface {v1}, Lcom/google/android/gms/location/FusedLocationProviderClient;->getLastLocation()Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda3;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    .line 347
    return-void

    .line 333
    :catch_0
    move-exception v2

    .line 334
    .local v2, "e":Ljava/lang/SecurityException;
    const-string v3, "Location permission is required to share your position"

    invoke-static {p0, v3, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 335
    return-void
.end method

.method private drawRouteOnce()V
    .locals 7

    .line 234
    iget-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->routeDrawn:Z

    if-nez v0, :cond_1

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->dropoffLat:Ljava/lang/Double;

    if-nez v0, :cond_0

    goto/16 :goto_0

    .line 235
    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->routeDrawn:Z

    .line 237
    new-instance v1, Lcom/google/android/gms/maps/model/LatLng;

    iget-object v2, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    iget-object v4, p0, Lcyberorion/pk/TrackingActivity;->pickupLng:Ljava/lang/Double;

    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v4

    invoke-direct {v1, v2, v3, v4, v5}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 238
    .local v1, "pickupLatLng":Lcom/google/android/gms/maps/model/LatLng;
    new-instance v2, Lcom/google/android/gms/maps/model/LatLng;

    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->dropoffLat:Ljava/lang/Double;

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    iget-object v5, p0, Lcyberorion/pk/TrackingActivity;->dropoffLng:Ljava/lang/Double;

    invoke-virtual {v5}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v5

    invoke-direct {v2, v3, v4, v5, v6}, Lcom/google/android/gms/maps/model/LatLng;-><init>(DD)V

    .line 240
    .local v2, "dropoffLatLng":Lcom/google/android/gms/maps/model/LatLng;
    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    new-instance v4, Lcom/google/android/gms/maps/model/MarkerOptions;

    invoke-direct {v4}, Lcom/google/android/gms/maps/model/MarkerOptions;-><init>()V

    .line 241
    invoke-virtual {v4, v1}, Lcom/google/android/gms/maps/model/MarkerOptions;->position(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 242
    const-string v5, "Pickup"

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/MarkerOptions;->title(Ljava/lang/String;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 243
    const/high16 v5, 0x43520000    # 210.0f

    invoke-static {v5}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->defaultMarker(F)Lcom/google/android/gms/maps/model/BitmapDescriptor;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/MarkerOptions;->icon(Lcom/google/android/gms/maps/model/BitmapDescriptor;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 240
    invoke-virtual {v3, v4}, Lcom/google/android/gms/maps/GoogleMap;->addMarker(Lcom/google/android/gms/maps/model/MarkerOptions;)Lcom/google/android/gms/maps/model/Marker;

    .line 244
    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    new-instance v4, Lcom/google/android/gms/maps/model/MarkerOptions;

    invoke-direct {v4}, Lcom/google/android/gms/maps/model/MarkerOptions;-><init>()V

    .line 245
    invoke-virtual {v4, v2}, Lcom/google/android/gms/maps/model/MarkerOptions;->position(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 246
    const-string v5, "Drop-off"

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/MarkerOptions;->title(Ljava/lang/String;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 247
    const/high16 v5, 0x41f00000    # 30.0f

    invoke-static {v5}, Lcom/google/android/gms/maps/model/BitmapDescriptorFactory;->defaultMarker(F)Lcom/google/android/gms/maps/model/BitmapDescriptor;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/MarkerOptions;->icon(Lcom/google/android/gms/maps/model/BitmapDescriptor;)Lcom/google/android/gms/maps/model/MarkerOptions;

    move-result-object v4

    .line 244
    invoke-virtual {v3, v4}, Lcom/google/android/gms/maps/GoogleMap;->addMarker(Lcom/google/android/gms/maps/model/MarkerOptions;)Lcom/google/android/gms/maps/model/Marker;

    .line 248
    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    new-instance v4, Lcom/google/android/gms/maps/model/PolylineOptions;

    invoke-direct {v4}, Lcom/google/android/gms/maps/model/PolylineOptions;-><init>()V

    const/4 v5, 0x2

    new-array v5, v5, [Lcom/google/android/gms/maps/model/LatLng;

    const/4 v6, 0x0

    aput-object v1, v5, v6

    aput-object v2, v5, v0

    .line 249
    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/PolylineOptions;->add([Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/PolylineOptions;

    move-result-object v4

    .line 250
    const/high16 v5, 0x40c00000    # 6.0f

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/PolylineOptions;->width(F)Lcom/google/android/gms/maps/model/PolylineOptions;

    move-result-object v4

    sget v5, Lcyberorion/pk/R$color;->primaryColor:I

    .line 251
    invoke-virtual {p0, v5}, Lcyberorion/pk/TrackingActivity;->getColor(I)I

    move-result v5

    invoke-virtual {v4, v5}, Lcom/google/android/gms/maps/model/PolylineOptions;->color(I)Lcom/google/android/gms/maps/model/PolylineOptions;

    move-result-object v4

    .line 252
    invoke-virtual {v4, v0}, Lcom/google/android/gms/maps/model/PolylineOptions;->geodesic(Z)Lcom/google/android/gms/maps/model/PolylineOptions;

    move-result-object v0

    .line 248
    invoke-virtual {v3, v0}, Lcom/google/android/gms/maps/GoogleMap;->addPolyline(Lcom/google/android/gms/maps/model/PolylineOptions;)Lcom/google/android/gms/maps/model/Polyline;

    .line 254
    new-instance v0, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    invoke-direct {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;-><init>()V

    .line 255
    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    move-result-object v0

    .line 256
    invoke-virtual {v0, v2}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->include(Lcom/google/android/gms/maps/model/LatLng;)Lcom/google/android/gms/maps/model/LatLngBounds$Builder;

    move-result-object v0

    .line 257
    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/LatLngBounds$Builder;->build()Lcom/google/android/gms/maps/model/LatLngBounds;

    move-result-object v0

    .line 258
    .local v0, "bounds":Lcom/google/android/gms/maps/model/LatLngBounds;
    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    new-instance v4, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda2;

    invoke-direct {v4, p0, v0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda2;-><init>(Lcyberorion/pk/TrackingActivity;Lcom/google/android/gms/maps/model/LatLngBounds;)V

    invoke-virtual {v3, v4}, Lcom/google/android/gms/maps/MapView;->post(Ljava/lang/Runnable;)Z

    .line 263
    return-void

    .line 234
    .end local v0    # "bounds":Lcom/google/android/gms/maps/model/LatLngBounds;
    .end local v1    # "pickupLatLng":Lcom/google/android/gms/maps/model/LatLng;
    .end local v2    # "dropoffLatLng":Lcom/google/android/gms/maps/model/LatLng;
    :cond_1
    :goto_0
    return-void
.end method

.method private hasLocationPermission()Z
    .locals 1

    .line 308
    const-string v0, "android.permission.ACCESS_FINE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1

    .line 310
    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-static {p0, v0}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 308
    :goto_1
    return v0
.end method

.method private listenForActiveSos()V
    .locals 2

    .line 178
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    const-string v1, "sos"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    .line 179
    const-string v1, "bookingId"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->orderByChild(Ljava/lang/String;)Lcom/google/firebase/database/Query;

    move-result-object v0

    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/Query;->equalTo(Ljava/lang/String;)Lcom/google/firebase/database/Query;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->activeSosQuery:Lcom/google/firebase/database/Query;

    .line 180
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->activeSosQuery:Lcom/google/firebase/database/Query;

    new-instance v1, Lcyberorion/pk/TrackingActivity$1;

    invoke-direct {v1, p0}, Lcyberorion/pk/TrackingActivity$1;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/Query;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    .line 199
    return-void
.end method

.method private listenForDriverPosition()V
    .locals 2

    .line 267
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->trackingRef:Lcom/google/firebase/database/DatabaseReference;

    new-instance v1, Lcyberorion/pk/TrackingActivity$3;

    invoke-direct {v1, p0}, Lcyberorion/pk/TrackingActivity$3;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    .line 290
    return-void
.end method

.method private loadBooking()V
    .locals 2

    .line 202
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->bookingRef:Lcom/google/firebase/database/DatabaseReference;

    new-instance v1, Lcyberorion/pk/TrackingActivity$2;

    invoke-direct {v1, p0}, Lcyberorion/pk/TrackingActivity$2;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    .line 229
    return-void
.end method

.method private pushDriverLocation(Landroid/location/Location;)V
    .locals 8
    .param p1, "location"    # Landroid/location/Location;

    .line 359
    invoke-virtual {p1}, Landroid/location/Location;->getLatitude()D

    move-result-wide v0

    .line 360
    .local v0, "lat":D
    invoke-virtual {p1}, Landroid/location/Location;->getLongitude()D

    move-result-wide v2

    .line 362
    .local v2, "lng":D
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4}, Ljava/util/HashMap;-><init>()V

    .line 363
    .local v4, "position":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;"
    const-string v5, "lat"

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 364
    const-string v5, "lng"

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 365
    invoke-virtual {p1}, Landroid/location/Location;->getAccuracy()F

    move-result v5

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const-string v6, "accuracy"

    invoke-interface {v4, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 366
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const-string v6, "updatedAt"

    invoke-interface {v4, v6, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 367
    iget-object v5, p0, Lcyberorion/pk/TrackingActivity;->trackingRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v5, v4}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    .line 369
    const-string v5, "driver"

    iget-object v6, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_0

    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v5

    invoke-virtual {v5}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v5

    if-eqz v5, :cond_0

    .line 370
    new-instance v5, Ljava/util/HashMap;

    invoke-direct {v5}, Ljava/util/HashMap;-><init>()V

    .line 371
    .local v5, "driverLocation":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;"
    const-string v6, "currentLat"

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 372
    const-string v6, "currentLng"

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    invoke-interface {v5, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 373
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v6

    const-string v7, "drivers"

    invoke-virtual {v6, v7}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v6

    .line 374
    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v7

    invoke-virtual {v7}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v7

    invoke-virtual {v7}, Lcom/google/firebase/auth/FirebaseUser;->getUid()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v6

    invoke-virtual {v6, v5}, Lcom/google/firebase/database/DatabaseReference;->updateChildren(Ljava/util/Map;)Lcom/google/android/gms/tasks/Task;

    .line 376
    .end local v5    # "driverLocation":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;"
    :cond_0
    return-void
.end method

.method private raiseSosAlert()V
    .locals 7

    .line 163
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->currentBooking:Lcyberorion/pk/Booking;

    if-nez v0, :cond_0

    .line 164
    const-string v0, "Booking not loaded yet \u2014 please try again"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 165
    return-void

    .line 167
    :cond_0
    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 168
    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseUser;->getUid()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    move-object v2, v0

    .line 169
    .local v2, "uid":Ljava/lang/String;
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    move-result-object v0

    iget-wide v0, v0, Lcom/google/android/gms/maps/model/LatLng;->latitude:D

    goto :goto_1

    :cond_2
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    :goto_1
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    .line 170
    .local v5, "lat":Ljava/lang/Double;
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    if-eqz v0, :cond_3

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->driverMarker:Lcom/google/android/gms/maps/model/Marker;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/model/Marker;->getPosition()Lcom/google/android/gms/maps/model/LatLng;

    move-result-object v0

    iget-wide v0, v0, Lcom/google/android/gms/maps/model/LatLng;->longitude:D

    goto :goto_2

    :cond_3
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->pickupLng:Ljava/lang/Double;

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    :goto_2
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v6

    .line 172
    .local v6, "lng":Ljava/lang/Double;
    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->currentBooking:Lcyberorion/pk/Booking;

    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    const-string v4, "SOS triggered from live tracking"

    invoke-static/range {v1 .. v6}, Lcyberorion/pk/SosHelper;->raise(Lcyberorion/pk/Booking;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Double;Ljava/lang/Double;)V

    .line 173
    sget v0, Lcyberorion/pk/R$string;->sos_sent_message:I

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 174
    return-void
.end method

.method private showSosDialog()V
    .locals 3

    .line 150
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcyberorion/pk/R$string;->sos_dialog_title:I

    .line 151
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(I)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcyberorion/pk/R$string;->sos_dialog_message:I

    .line 152
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setMessage(I)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcyberorion/pk/R$string;->sos_alert_support:I

    new-instance v2, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda0;-><init>(Lcyberorion/pk/TrackingActivity;)V

    .line 153
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(ILandroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcyberorion/pk/R$string;->sos_call_emergency:I

    new-instance v2, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda1;-><init>(Lcyberorion/pk/TrackingActivity;)V

    .line 154
    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNeutralButton(ILandroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 158
    const/high16 v1, 0x1040000

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/app/AlertDialog$Builder;->setNegativeButton(ILandroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 159
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->show()Landroidx/appcompat/app/AlertDialog;

    .line 160
    return-void
.end method

.method private stopSharing()V
    .locals 2

    .line 350
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->sharingLocation:Z

    .line 351
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->btnToggleSharing:Lcom/google/android/material/button/MaterialButton;

    const-string v1, "Start Sharing Location"

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setText(Ljava/lang/CharSequence;)V

    .line 352
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->locationCallback:Lcom/google/android/gms/location/LocationCallback;

    if-eqz v0, :cond_0

    .line 353
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->fusedLocationClient:Lcom/google/android/gms/location/FusedLocationProviderClient;

    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->locationCallback:Lcom/google/android/gms/location/LocationCallback;

    invoke-interface {v0, v1}, Lcom/google/android/gms/location/FusedLocationProviderClient;->removeLocationUpdates(Lcom/google/android/gms/location/LocationCallback;)Lcom/google/android/gms/tasks/Task;

    .line 355
    :cond_0
    return-void
.end method

.method private toggleSharing()V
    .locals 4

    .line 293
    iget-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->sharingLocation:Z

    if-eqz v0, :cond_0

    .line 294
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->stopSharing()V

    .line 295
    return-void

    .line 297
    :cond_0
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->hasLocationPermission()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 298
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->beginSharing()V

    goto :goto_0

    .line 300
    :cond_1
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->locationPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    const/4 v1, 0x2

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "android.permission.ACCESS_FINE_LOCATION"

    aput-object v3, v1, v2

    const/4 v2, 0x1

    const-string v3, "android.permission.ACCESS_COARSE_LOCATION"

    aput-object v3, v1, v2

    invoke-virtual {v0, v1}, Landroidx/activity/result/ActivityResultLauncher;->launch(Ljava/lang/Object;)V

    .line 305
    :goto_0
    return-void
.end method


# virtual methods
.method synthetic lambda$beginSharing$7$cyberorion-pk-TrackingActivity(Landroid/location/Location;)V
    .locals 0
    .param p1, "location"    # Landroid/location/Location;

    .line 345
    if-eqz p1, :cond_0

    invoke-direct {p0, p1}, Lcyberorion/pk/TrackingActivity;->pushDriverLocation(Landroid/location/Location;)V

    .line 346
    :cond_0
    return-void
.end method

.method synthetic lambda$drawRouteOnce$6$cyberorion-pk-TrackingActivity(Lcom/google/android/gms/maps/model/LatLngBounds;)V
    .locals 2
    .param p1, "bounds"    # Lcom/google/android/gms/maps/model/LatLngBounds;

    .line 259
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    if-eqz v0, :cond_0

    .line 260
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    const/16 v1, 0x78

    invoke-static {p1, v1}, Lcom/google/android/gms/maps/CameraUpdateFactory;->newLatLngBounds(Lcom/google/android/gms/maps/model/LatLngBounds;I)Lcom/google/android/gms/maps/CameraUpdate;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/GoogleMap;->animateCamera(Lcom/google/android/gms/maps/CameraUpdate;)V

    .line 262
    :cond_0
    return-void
.end method

.method synthetic lambda$onCreate$0$cyberorion-pk-TrackingActivity(Landroid/view/View;)V
    .locals 3
    .param p1, "v"    # Landroid/view/View;

    .line 114
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/DamageComparisonActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "i":Landroid/content/Intent;
    const-string v1, "extra_booking_id"

    iget-object v2, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method synthetic lambda$onCreate$1$cyberorion-pk-TrackingActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 115
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->showSosDialog()V

    return-void
.end method

.method synthetic lambda$onCreate$2$cyberorion-pk-TrackingActivity(Ljava/util/Map;)V
    .locals 3
    .param p1, "grantResults"    # Ljava/util/Map;

    .line 129
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"

    invoke-interface {p1, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_1

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 130
    const-string v2, "android.permission.ACCESS_COARSE_LOCATION"

    invoke-interface {p1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    move v0, v1

    .line 131
    .local v0, "granted":Z
    :goto_1
    if-eqz v0, :cond_2

    .line 132
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->beginSharing()V

    goto :goto_2

    .line 134
    :cond_2
    const-string v2, "Location permission is needed to share your live position"

    invoke-static {p0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 136
    :goto_2
    return-void
.end method

.method synthetic lambda$onCreate$3$cyberorion-pk-TrackingActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 140
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->toggleSharing()V

    return-void
.end method

.method synthetic lambda$showSosDialog$4$cyberorion-pk-TrackingActivity(Landroid/content/DialogInterface;I)V
    .locals 0
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 153
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->raiseSosAlert()V

    return-void
.end method

.method synthetic lambda$showSosDialog$5$cyberorion-pk-TrackingActivity(Landroid/content/DialogInterface;I)V
    .locals 3
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 155
    new-instance v0, Landroid/content/Intent;

    const-string v1, "tel:1122"

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const-string v2, "android.intent.action.DIAL"

    invoke-direct {v0, v2, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 156
    .local v0, "dial":Landroid/content/Intent;
    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->startActivity(Landroid/content/Intent;)V

    .line 157
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 95
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 96
    sget v0, Lcyberorion/pk/R$layout;->activity_tracking:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->setContentView(I)V

    .line 98
    invoke-virtual {p0}, Lcyberorion/pk/TrackingActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_booking_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    .line 99
    invoke-virtual {p0}, Lcyberorion/pk/TrackingActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_role"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    .line 100
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, "customer"

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    .line 102
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_1

    .line 103
    const-string v0, "Missing booking reference"

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 104
    invoke-virtual {p0}, Lcyberorion/pk/TrackingActivity;->finish()V

    .line 105
    invoke-static {p0}, Lcyberorion/pk/features/FeatureEntry;->attach(Landroid/app/Activity;)V

    return-void

    .line 108
    :cond_1
    sget v0, Lcyberorion/pk/R$id;->tvTripStatus:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->tvTripStatus:Landroid/widget/TextView;

    .line 109
    sget v0, Lcyberorion/pk/R$id;->tvTripRoute:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->tvTripRoute:Landroid/widget/TextView;

    .line 110
    sget v0, Lcyberorion/pk/R$id;->tvSosBanner:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->tvSosBanner:Landroid/widget/TextView;

    .line 111
    sget v0, Lcyberorion/pk/R$id;->layoutDriverControls:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->layoutDriverControls:Landroid/view/View;

    .line 112
    sget v0, Lcyberorion/pk/R$id;->btnToggleSharing:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->btnToggleSharing:Lcom/google/android/material/button/MaterialButton;

    .line 113
    sget v0, Lcyberorion/pk/R$id;->fabSos:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->fabSos:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    .line 114
    sget v0, Lcyberorion/pk/R$id;->btnDamageComparison:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v2, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda4;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 115
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->fabSos:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    new-instance v2, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda5;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v0, v2}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 117
    sget v0, Lcyberorion/pk/R$id;->mapTracking:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/TrackingActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/gms/maps/MapView;

    iput-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    .line 118
    if-eqz p1, :cond_2

    const-string v0, "MapViewBundleKey"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    goto :goto_0

    :cond_2
    const/4 v0, 0x0

    .line 119
    .local v0, "mapViewBundle":Landroid/os/Bundle;
    :goto_0
    iget-object v2, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v2, v0}, Lcom/google/android/gms/maps/MapView;->onCreate(Landroid/os/Bundle;)V

    .line 120
    iget-object v2, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v2, p0}, Lcom/google/android/gms/maps/MapView;->getMapAsync(Lcom/google/android/gms/maps/OnMapReadyCallback;)V

    .line 122
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v2

    invoke-virtual {v2}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    move-result-object v2

    .line 123
    .local v2, "root":Lcom/google/firebase/database/DatabaseReference;
    const-string v3, "bookings"

    invoke-virtual {v2, v3}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v3

    iget-object v4, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v3

    iput-object v3, p0, Lcyberorion/pk/TrackingActivity;->bookingRef:Lcom/google/firebase/database/DatabaseReference;

    .line 124
    const-string v3, "tracking"

    invoke-virtual {v2, v3}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v3

    iget-object v4, p0, Lcyberorion/pk/TrackingActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v3, v4}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v3

    iput-object v3, p0, Lcyberorion/pk/TrackingActivity;->trackingRef:Lcom/google/firebase/database/DatabaseReference;

    .line 126
    invoke-static {p0}, Lcom/google/android/gms/location/LocationServices;->getFusedLocationProviderClient(Landroid/app/Activity;)Lcom/google/android/gms/location/FusedLocationProviderClient;

    move-result-object v3

    iput-object v3, p0, Lcyberorion/pk/TrackingActivity;->fusedLocationClient:Lcom/google/android/gms/location/FusedLocationProviderClient;

    .line 127
    new-instance v3, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;

    invoke-direct {v3}, Landroidx/activity/result/contract/ActivityResultContracts$RequestMultiplePermissions;-><init>()V

    new-instance v4, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda6;

    invoke-direct {v4, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda6;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {p0, v3, v4}, Lcyberorion/pk/TrackingActivity;->registerForActivityResult(Landroidx/activity/result/contract/ActivityResultContract;Landroidx/activity/result/ActivityResultCallback;)Landroidx/activity/result/ActivityResultLauncher;

    move-result-object v3

    iput-object v3, p0, Lcyberorion/pk/TrackingActivity;->locationPermissionLauncher:Landroidx/activity/result/ActivityResultLauncher;

    .line 138
    const-string v3, "driver"

    iget-object v4, p0, Lcyberorion/pk/TrackingActivity;->role:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3

    .line 139
    iget-object v3, p0, Lcyberorion/pk/TrackingActivity;->layoutDriverControls:Landroid/view/View;

    invoke-virtual {v3, v1}, Landroid/view/View;->setVisibility(I)V

    .line 140
    iget-object v1, p0, Lcyberorion/pk/TrackingActivity;->btnToggleSharing:Lcom/google/android/material/button/MaterialButton;

    new-instance v3, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda7;

    invoke-direct {v3, p0}, Lcyberorion/pk/TrackingActivity$$ExternalSyntheticLambda7;-><init>(Lcyberorion/pk/TrackingActivity;)V

    invoke-virtual {v1, v3}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 143
    :cond_3
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->loadBooking()V

    .line 144
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->listenForDriverPosition()V

    .line 145
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->listenForActiveSos()V

    .line 146
    invoke-static {p0}, Lcyberorion/pk/features/FeatureEntry;->attach(Landroid/app/Activity;)V

    return-void
.end method

.method protected onDestroy()V
    .locals 1

    .line 412
    iget-boolean v0, p0, Lcyberorion/pk/TrackingActivity;->sharingLocation:Z

    if-eqz v0, :cond_0

    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->stopSharing()V

    .line 413
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onDestroy()V

    .line 414
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onDestroy()V

    .line 415
    return-void
.end method

.method public onLowMemory()V
    .locals 1

    .line 419
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onLowMemory()V

    .line 420
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onLowMemory()V

    .line 421
    return-void
.end method

.method public onMapReady(Lcom/google/android/gms/maps/GoogleMap;)V
    .locals 1
    .param p1, "map"    # Lcom/google/android/gms/maps/GoogleMap;

    .line 380
    iput-object p1, p0, Lcyberorion/pk/TrackingActivity;->googleMap:Lcom/google/android/gms/maps/GoogleMap;

    .line 381
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->pickupLat:Ljava/lang/Double;

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->dropoffLat:Ljava/lang/Double;

    if-eqz v0, :cond_0

    .line 382
    invoke-direct {p0}, Lcyberorion/pk/TrackingActivity;->drawRouteOnce()V

    .line 384
    :cond_0
    return-void
.end method

.method protected onPause()V
    .locals 1

    .line 400
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onPause()V

    .line 401
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onPause()V

    .line 402
    return-void
.end method

.method protected onResume()V
    .locals 1

    .line 394
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onResume()V

    .line 395
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onResume()V

    .line 396
    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "outState"    # Landroid/os/Bundle;

    .line 425
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 426
    const-string v0, "MapViewBundleKey"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v1

    .line 427
    .local v1, "mapViewBundle":Landroid/os/Bundle;
    if-nez v1, :cond_0

    .line 428
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    move-object v1, v2

    .line 429
    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 431
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/maps/MapView;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 432
    return-void
.end method

.method protected onStart()V
    .locals 1

    .line 388
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onStart()V

    .line 389
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onStart()V

    .line 390
    return-void
.end method

.method protected onStop()V
    .locals 1

    .line 406
    iget-object v0, p0, Lcyberorion/pk/TrackingActivity;->mapView:Lcom/google/android/gms/maps/MapView;

    invoke-virtual {v0}, Lcom/google/android/gms/maps/MapView;->onStop()V

    .line 407
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onStop()V

    .line 408
    return-void
.end method
