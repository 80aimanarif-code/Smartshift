.class public Lcyberorion/pk/NegotiationActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "NegotiationActivity.java"


# instance fields
.field private adapter:Lcyberorion/pk/NegotiationAdapter;

.field private aiFare:D

.field private bookingId:Ljava/lang/String;

.field private bookingRef:Lcom/google/firebase/database/DatabaseReference;

.field private etOfferAmount:Lcom/google/android/material/textfield/TextInputEditText;

.field private layoutQuickActions:Landroid/view/View;

.field private myRole:Ljava/lang/String;

.field private negotiationClosed:Z

.field private final offers:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcyberorion/pk/NegotiationOffer;",
            ">;"
        }
    .end annotation
.end field

.field private offersRef:Lcom/google/firebase/database/DatabaseReference;

.field private rvOffers:Landroidx/recyclerview/widget/RecyclerView;

.field private sendInFlight:Z

.field private tvAiFareReference:Landroid/widget/TextView;

.field private tvNegotiationStatus:Landroid/widget/TextView;


# direct methods
.method static bridge synthetic -$$Nest$fgetadapter(Lcyberorion/pk/NegotiationActivity;)Lcyberorion/pk/NegotiationAdapter;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/NegotiationActivity;->adapter:Lcyberorion/pk/NegotiationAdapter;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetoffers(Lcyberorion/pk/NegotiationActivity;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetrvOffers(Lcyberorion/pk/NegotiationActivity;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/NegotiationActivity;->rvOffers:Landroidx/recyclerview/widget/RecyclerView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$mupdateActionState(Lcyberorion/pk/NegotiationActivity;Lcyberorion/pk/NegotiationOffer;)V
    .locals 0

    invoke-direct {p0, p1}, Lcyberorion/pk/NegotiationActivity;->updateActionState(Lcyberorion/pk/NegotiationOffer;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 35
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    .line 42
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    .line 51
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcyberorion/pk/NegotiationActivity;->negotiationClosed:Z

    .line 52
    iput-boolean v0, p0, Lcyberorion/pk/NegotiationActivity;->sendInFlight:Z

    return-void
.end method

.method private finalizeFare(D)V
    .locals 1

    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    invoke-static {p0, v0, p1, p2}, Lcyberorion/pk/features/FeatureEntry;->agreeFare(Landroid/app/Activity;Ljava/lang/String;D)V

    return-void
.end method

.method private listenForOffers()V
    .locals 2

    .line 94
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offersRef:Lcom/google/firebase/database/DatabaseReference;

    const-string v1, "timestamp"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->orderByChild(Ljava/lang/String;)Lcom/google/firebase/database/Query;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$1;

    invoke-direct {v1, p0}, Lcyberorion/pk/NegotiationActivity$1;-><init>(Lcyberorion/pk/NegotiationActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/Query;->addChildEventListener(Lcom/google/firebase/database/ChildEventListener;)Lcom/google/firebase/database/ChildEventListener;

    .line 114
    return-void
.end method

.method private notifyOtherParty(Ljava/lang/String;D)V
    .locals 2
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "amount"    # D

    .line 186
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->bookingRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v0}, Lcom/google/firebase/database/DatabaseReference;->get()Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0, p1, p2, p3}, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda0;-><init>(Lcyberorion/pk/NegotiationActivity;Ljava/lang/String;D)V

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    .line 206
    return-void
.end method

.method private sendOffer(Ljava/lang/String;)V
    .locals 13

    invoke-static {p0, p1}, Lcyberorion/pk/features/FareAssistant;->block(Landroid/app/Activity;Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, :fare_assistant_continue
    return-void
    :fare_assistant_continue
    .param p1, "type"    # Ljava/lang/String;

    .line 135
    iget-boolean v0, p0, Lcyberorion/pk/NegotiationActivity;->sendInFlight:Z

    if-eqz v0, :cond_0

    return-void

    .line 138
    :cond_0
    const-string v0, "offer"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_4

    .line 139
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->etOfferAmount:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v0}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->etOfferAmount:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v0}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    :cond_1
    const-string v0, ""

    :goto_0
    move-object v3, v0

    .line 140
    .local v3, "text":Ljava/lang/String;
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 141
    const-string v0, "Enter an amount first"

    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 142
    return-void

    .line 145
    :cond_2
    :try_start_0
    invoke-static {v3}, Ljava/lang/Double;->parseDouble(Ljava/lang/String;)D

    move-result-wide v4
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    .line 149
    .local v4, "amount":D
    nop

    .line 151
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3

    const-string p1, "counter"

    .line 152
    .end local v3    # "text":Ljava/lang/String;
    :cond_3
    goto :goto_2

    .line 146
    .end local v4    # "amount":D
    .restart local v3    # "text":Ljava/lang/String;
    :catch_0
    move-exception v0

    .line 147
    .local v0, "e":Ljava/lang/NumberFormatException;
    const-string v1, "Enter a valid amount"

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 148
    return-void

    .line 154
    .end local v0    # "e":Ljava/lang/NumberFormatException;
    .end local v3    # "text":Ljava/lang/String;
    :cond_4
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_5

    iget-wide v3, p0, Lcyberorion/pk/NegotiationActivity;->aiFare:D

    goto :goto_1

    :cond_5
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    iget-object v3, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    sub-int/2addr v3, v1

    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcyberorion/pk/NegotiationOffer;

    iget-wide v3, v0, Lcyberorion/pk/NegotiationOffer;->amount:D

    :goto_1
    move-wide v4, v3

    .line 157
    .restart local v4    # "amount":D
    :goto_2
    move-object v10, p1

    .line 158
    .local v10, "finalType":Ljava/lang/String;
    move-wide v8, v4

    .line 159
    .local v8, "finalAmount":D
    iput-boolean v1, p0, Lcyberorion/pk/NegotiationActivity;->sendInFlight:Z

    .line 160
    invoke-direct {p0, v2}, Lcyberorion/pk/NegotiationActivity;->setSendControlsEnabled(Z)V

    .line 161
    new-instance v6, Lcyberorion/pk/NegotiationOffer;

    iget-object v7, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    invoke-direct/range {v6 .. v12}, Lcyberorion/pk/NegotiationOffer;-><init>(Ljava/lang/String;DLjava/lang/String;J)V

    .line 162
    .local v6, "newOffer":Lcyberorion/pk/NegotiationOffer;
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->offersRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v0}, Lcom/google/firebase/database/DatabaseReference;->push()Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    invoke-virtual {v0, v6}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, v10, v8, v9}, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda5;-><init>(Lcyberorion/pk/NegotiationActivity;Ljava/lang/String;D)V

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 175
    return-void
.end method

.method private setSendControlsEnabled(Z)V
    .locals 1
    .param p1, "enabled"    # Z

    .line 179
    sget v0, Lcyberorion/pk/R$id;->btnSendOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 180
    sget v0, Lcyberorion/pk/R$id;->btnAcceptOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 181
    sget v0, Lcyberorion/pk/R$id;->btnRejectOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 182
    return-void
.end method

.method private updateActionState(Lcyberorion/pk/NegotiationOffer;)V
    .locals 5

    invoke-static {p0}, Lcyberorion/pk/features/FareAssistant;->refresh(Landroid/app/Activity;)V
    .param p1, "latest"    # Lcyberorion/pk/NegotiationOffer;

    .line 118
    iget-boolean v0, p0, Lcyberorion/pk/NegotiationActivity;->negotiationClosed:Z

    if-eqz v0, :cond_0

    return-void

    .line 119
    :cond_0
    const-string v0, "accept"

    iget-object v1, p1, Lcyberorion/pk/NegotiationOffer;->type:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v3, 0x8

    if-eqz v0, :cond_1

    .line 120
    iput-boolean v2, p0, Lcyberorion/pk/NegotiationActivity;->negotiationClosed:Z

    .line 121
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->layoutQuickActions:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 122
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->tvNegotiationStatus:Landroid/widget/TextView;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 123
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->tvNegotiationStatus:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->negotiation_completed_format:I

    iget-wide v2, p1, Lcyberorion/pk/NegotiationOffer;->amount:D

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/NegotiationActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 124
    return-void

    .line 126
    :cond_1
    const-string v0, "reject"

    iget-object v4, p1, Lcyberorion/pk/NegotiationOffer;->type:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 127
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->layoutQuickActions:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 128
    return-void

    .line 130
    :cond_2
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    iget-object v4, p1, Lcyberorion/pk/NegotiationOffer;->senderRole:Ljava/lang/String;

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    xor-int/2addr v0, v2

    .line 131
    .local v0, "fromOtherParty":Z
    iget-object v2, p0, Lcyberorion/pk/NegotiationActivity;->layoutQuickActions:Landroid/view/View;

    if-eqz v0, :cond_3

    goto :goto_0

    :cond_3
    move v1, v3

    :goto_0
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 132
    return-void
.end method


# virtual methods
.method synthetic lambda$finalizeFare$5$cyberorion-pk-NegotiationActivity(Ljava/util/Map;Lcom/google/firebase/database/DataSnapshot;)V
    .locals 3
    .param p1, "updates"    # Ljava/util/Map;
    .param p2, "snapshot"    # Lcom/google/firebase/database/DataSnapshot;

    .line 215
    const-class v0, Ljava/lang/String;

    invoke-virtual {p2, v0}, Lcom/google/firebase/database/DataSnapshot;->getValue(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    .line 216
    .local v0, "status":Ljava/lang/String;
    if-eqz v0, :cond_0

    invoke-static {v0}, Lcyberorion/pk/BookingStatus;->fromLabel(Ljava/lang/String;)Lcyberorion/pk/BookingStatus;

    move-result-object v1

    sget-object v2, Lcyberorion/pk/BookingStatus;->PENDING:Lcyberorion/pk/BookingStatus;

    if-ne v1, v2, :cond_0

    .line 217
    sget-object v1, Lcyberorion/pk/BookingStatus;->ACCEPTED:Lcyberorion/pk/BookingStatus;

    iget-object v1, v1, Lcyberorion/pk/BookingStatus;->label:Ljava/lang/String;

    const-string v2, "status"

    invoke-interface {p1, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 219
    :cond_0
    iget-object v1, p0, Lcyberorion/pk/NegotiationActivity;->bookingRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v1, p1}, Lcom/google/firebase/database/DatabaseReference;->updateChildren(Ljava/util/Map;)Lcom/google/android/gms/tasks/Task;

    .line 220
    return-void
.end method

.method synthetic lambda$notifyOtherParty$4$cyberorion-pk-NegotiationActivity(Ljava/lang/String;DLcom/google/firebase/database/DataSnapshot;)V
    .locals 6
    .param p1, "type"    # Ljava/lang/String;
    .param p2, "amount"    # D
    .param p4, "snapshot"    # Lcom/google/firebase/database/DataSnapshot;

    .line 187
    const-class v0, Lcyberorion/pk/Booking;

    invoke-virtual {p4, v0}, Lcom/google/firebase/database/DataSnapshot;->getValue(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcyberorion/pk/Booking;

    .line 188
    .local v0, "booking":Lcyberorion/pk/Booking;
    if-nez v0, :cond_0

    return-void

    .line 189
    :cond_0
    const-string v1, "customer"

    iget-object v2, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1

    iget-object v1, v0, Lcyberorion/pk/Booking;->driverId:Ljava/lang/String;

    goto :goto_0

    :cond_1
    iget-object v1, v0, Lcyberorion/pk/Booking;->userId:Ljava/lang/String;

    .line 190
    .local v1, "recipientId":Ljava/lang/String;
    :goto_0
    if-eqz v1, :cond_5

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_2

    goto :goto_2

    .line 194
    :cond_2
    const-string v2, "accept"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    .line 195
    const-string v2, "Fare agreed"

    .line 196
    .local v2, "title":Ljava/lang/String;
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v5, "You agreed on Rs. %.0f for this job."

    invoke-static {v3, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .local v3, "message":Ljava/lang/String;
    goto :goto_1

    .line 197
    .end local v2    # "title":Ljava/lang/String;
    .end local v3    # "message":Ljava/lang/String;
    :cond_3
    const-string v2, "reject"

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_4

    .line 198
    const-string v2, "Offer rejected"

    .line 199
    .restart local v2    # "title":Ljava/lang/String;
    const-string v3, "Your negotiation offer was rejected."

    .restart local v3    # "message":Ljava/lang/String;
    goto :goto_1

    .line 201
    .end local v2    # "title":Ljava/lang/String;
    .end local v3    # "message":Ljava/lang/String;
    :cond_4
    const-string v2, "New fare offer"

    .line 202
    .restart local v2    # "title":Ljava/lang/String;
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    const-string v5, "New offer: Rs. %.0f. Open to respond."

    invoke-static {v3, v5, v4}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    .line 204
    .restart local v3    # "message":Ljava/lang/String;
    :goto_1
    const-string v4, "negotiation"

    iget-object v5, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    invoke-static {v1, v2, v3, v4, v5}, Lcyberorion/pk/NotificationHelper;->notify(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 205
    return-void

    .line 190
    .end local v2    # "title":Ljava/lang/String;
    .end local v3    # "message":Ljava/lang/String;
    :cond_5
    :goto_2
    return-void
.end method

.method synthetic lambda$onCreate$0$cyberorion-pk-NegotiationActivity(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 82
    const-string v0, "offer"

    invoke-direct {p0, v0}, Lcyberorion/pk/NegotiationActivity;->sendOffer(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$onCreate$1$cyberorion-pk-NegotiationActivity(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 83
    const-string v0, "accept"

    invoke-direct {p0, v0}, Lcyberorion/pk/NegotiationActivity;->sendOffer(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$onCreate$2$cyberorion-pk-NegotiationActivity(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 84
    const-string v0, "reject"

    invoke-direct {p0, v0}, Lcyberorion/pk/NegotiationActivity;->sendOffer(Ljava/lang/String;)V

    return-void
.end method

.method synthetic lambda$sendOffer$3$cyberorion-pk-NegotiationActivity(Ljava/lang/String;DLcom/google/android/gms/tasks/Task;)V
    .locals 2
    .param p1, "finalType"    # Ljava/lang/String;
    .param p2, "finalAmount"    # D
    .param p4, "task"    # Lcom/google/android/gms/tasks/Task;

    .line 163
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcyberorion/pk/NegotiationActivity;->sendInFlight:Z

    .line 164
    const/4 v1, 0x1

    invoke-direct {p0, v1}, Lcyberorion/pk/NegotiationActivity;->setSendControlsEnabled(Z)V

    .line 165
    invoke-virtual {p4}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    move-result v1

    if-nez v1, :cond_0

    .line 166
    const-string v1, "Could not send. Try again."

    invoke-static {p0, v1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 167
    return-void

    .line 169
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->etOfferAmount:Lcom/google/android/material/textfield/TextInputEditText;

    const-string v1, ""

    invoke-virtual {v0, v1}, Lcom/google/android/material/textfield/TextInputEditText;->setText(Ljava/lang/CharSequence;)V

    .line 170
    const-string v0, "accept"

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 171
    invoke-direct {p0, p2, p3}, Lcyberorion/pk/NegotiationActivity;->finalizeFare(D)V

    .line 173
    :cond_1
    invoke-direct {p0, p1, p2, p3}, Lcyberorion/pk/NegotiationActivity;->notifyOtherParty(Ljava/lang/String;D)V

    .line 174
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 56
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 57
    sget v0, Lcyberorion/pk/R$layout;->activity_negotiation:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->setContentView(I)V

    .line 59
    invoke-virtual {p0}, Lcyberorion/pk/NegotiationActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_booking_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    .line 60
    invoke-virtual {p0}, Lcyberorion/pk/NegotiationActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_role"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    .line 61
    invoke-virtual {p0}, Lcyberorion/pk/NegotiationActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_ai_fare"

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v0

    iput-wide v0, p0, Lcyberorion/pk/NegotiationActivity;->aiFare:D

    .line 62
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    if-nez v0, :cond_0

    const-string v0, "customer"

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    .line 64
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    if-nez v0, :cond_1

    .line 65
    const-string v0, "Missing booking reference"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 66
    invoke-virtual {p0}, Lcyberorion/pk/NegotiationActivity;->finish()V

    .line 67
    return-void

    .line 70
    :cond_1
    sget v0, Lcyberorion/pk/R$id;->rvOffers:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->rvOffers:Landroidx/recyclerview/widget/RecyclerView;

    .line 71
    sget v0, Lcyberorion/pk/R$id;->tvAiFareReference:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->tvAiFareReference:Landroid/widget/TextView;

    .line 72
    sget v0, Lcyberorion/pk/R$id;->tvNegotiationStatus:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->tvNegotiationStatus:Landroid/widget/TextView;

    .line 73
    sget v0, Lcyberorion/pk/R$id;->layoutQuickActions:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->layoutQuickActions:Landroid/view/View;

    .line 74
    sget v0, Lcyberorion/pk/R$id;->etOfferAmount:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->etOfferAmount:Lcom/google/android/material/textfield/TextInputEditText;

    .line 76
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->tvAiFareReference:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->ai_fare_reference_format:I

    iget-wide v2, p0, Lcyberorion/pk/NegotiationActivity;->aiFare:D

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/NegotiationActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 78
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->rvOffers:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v1, p0}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 79
    new-instance v0, Lcyberorion/pk/NegotiationAdapter;

    iget-object v1, p0, Lcyberorion/pk/NegotiationActivity;->offers:Ljava/util/List;

    iget-object v2, p0, Lcyberorion/pk/NegotiationActivity;->myRole:Ljava/lang/String;

    invoke-direct {v0, v1, v2}, Lcyberorion/pk/NegotiationAdapter;-><init>(Ljava/util/List;Ljava/lang/String;)V

    iput-object v0, p0, Lcyberorion/pk/NegotiationActivity;->adapter:Lcyberorion/pk/NegotiationAdapter;

    .line 80
    iget-object v0, p0, Lcyberorion/pk/NegotiationActivity;->rvOffers:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Lcyberorion/pk/NegotiationActivity;->adapter:Lcyberorion/pk/NegotiationAdapter;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 82
    sget v0, Lcyberorion/pk/R$id;->btnSendOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda1;-><init>(Lcyberorion/pk/NegotiationActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 83
    sget v0, Lcyberorion/pk/R$id;->btnAcceptOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda2;

    invoke-direct {v1, p0}, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda2;-><init>(Lcyberorion/pk/NegotiationActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 84
    sget v0, Lcyberorion/pk/R$id;->btnRejectOffer:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/NegotiationActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda3;

    invoke-direct {v1, p0}, Lcyberorion/pk/NegotiationActivity$$ExternalSyntheticLambda3;-><init>(Lcyberorion/pk/NegotiationActivity;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    .line 87
    .local v0, "root":Lcom/google/firebase/database/DatabaseReference;
    const-string v1, "negotiations"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iget-object v2, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    const-string v2, "offers"

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iput-object v1, p0, Lcyberorion/pk/NegotiationActivity;->offersRef:Lcom/google/firebase/database/DatabaseReference;

    .line 88
    const-string v1, "bookings"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iget-object v2, p0, Lcyberorion/pk/NegotiationActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iput-object v1, p0, Lcyberorion/pk/NegotiationActivity;->bookingRef:Lcom/google/firebase/database/DatabaseReference;

    .line 90
    invoke-direct {p0}, Lcyberorion/pk/NegotiationActivity;->listenForOffers()V

    invoke-static {p0}, Lcyberorion/pk/features/FareAssistant;->attach(Landroid/app/Activity;)V

    .line 91
    return-void
.end method

.method protected onDestroy()V
    .locals 0
    invoke-static {p0}, Lcyberorion/pk/features/FareAssistant;->detach(Landroid/app/Activity;)V
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onDestroy()V
    return-void
.end method
