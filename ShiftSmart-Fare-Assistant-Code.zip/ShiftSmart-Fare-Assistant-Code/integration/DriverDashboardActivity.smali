.class public Lcyberorion/pk/DriverDashboardActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "DriverDashboardActivity.java"

# interfaces
.implements Lcyberorion/pk/DriverJobAdapter$OnJobActionListener;


# instance fields
.field private adapter:Lcyberorion/pk/DriverJobAdapter;

.field private final allJobs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcyberorion/pk/Booking;",
            ">;"
        }
    .end annotation
.end field

.field private bookingsRef:Lcom/google/firebase/database/DatabaseReference;

.field private dotDriverAvailability:Landroid/view/View;

.field private driverAvailable:Z

.field private driverId:Ljava/lang/String;

.field private driverRef:Lcom/google/firebase/database/DatabaseReference;

.field private emptyState:Landroid/view/View;

.field private mAuth:Lcom/google/firebase/auth/FirebaseAuth;

.field private pillDriverAvailability:Landroid/view/View;

.field private rvJobs:Landroidx/recyclerview/widget/RecyclerView;

.field private selectedTab:I

.field private tvDriverAvailability:Landroid/widget/TextView;

.field private tvDriverAvatarInitial:Landroid/widget/TextView;

.field private tvDriverGreeting:Landroid/widget/TextView;

.field private tvEarningsSummary:Landroid/widget/TextView;

.field private tvEmptyMessage:Landroid/widget/TextView;

.field private tvStatRating:Landroid/widget/TextView;

.field private tvStatTrips:Landroid/widget/TextView;

.field private tvStatVehicle:Landroid/widget/TextView;

.field private final visibleJobs:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcyberorion/pk/Booking;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static bridge synthetic -$$Nest$fgetallJobs(Lcyberorion/pk/DriverDashboardActivity;)Ljava/util/List;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/DriverDashboardActivity;->allJobs:Ljava/util/List;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetdriverRef(Lcyberorion/pk/DriverDashboardActivity;)Lcom/google/firebase/database/DatabaseReference;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fgetmAuth(Lcyberorion/pk/DriverDashboardActivity;)Lcom/google/firebase/auth/FirebaseAuth;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/DriverDashboardActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputselectedTab(Lcyberorion/pk/DriverDashboardActivity;I)V
    .locals 0

    iput p1, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    return-void
.end method

.method static bridge synthetic -$$Nest$mbindDriverProfile(Lcyberorion/pk/DriverDashboardActivity;Lcyberorion/pk/Driver;)V
    .locals 0

    invoke-direct {p0, p1}, Lcyberorion/pk/DriverDashboardActivity;->bindDriverProfile(Lcyberorion/pk/Driver;)V

    return-void
.end method

.method static bridge synthetic -$$Nest$mgoToLogin(Lcyberorion/pk/DriverDashboardActivity;)V
    .locals 0

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->goToLogin()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mlistenJobs(Lcyberorion/pk/DriverDashboardActivity;)V
    .locals 0

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->listenJobs()V

    return-void
.end method

.method static bridge synthetic -$$Nest$mrefreshVisibleJobs(Lcyberorion/pk/DriverDashboardActivity;)V
    .locals 0

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->refreshVisibleJobs()V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 16
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    .line 19
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->allJobs:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->visibleJobs:Ljava/util/List;

    .line 20
    const/4 v0, 0x0

    iput v0, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    iput-boolean v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    return-void
.end method

.method private applyAvailabilityUi()V
    .locals 2

    .line 43
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->dotDriverAvailability:Landroid/view/View;

    iget-boolean v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    if-eqz v1, :cond_0

    sget v1, Lcyberorion/pk/R$drawable;->bg_circle_success:I

    goto :goto_0

    :cond_0
    sget v1, Lcyberorion/pk/R$drawable;->bg_circle_error:I

    :goto_0
    invoke-virtual {v0, v1}, Landroid/view/View;->setBackgroundResource(I)V

    .line 44
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverAvailability:Landroid/widget/TextView;

    iget-boolean v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    if-eqz v1, :cond_1

    const-string v1, "Online \u00b7 tap to go offline"

    goto :goto_1

    :cond_1
    const-string v1, "Offline \u00b7 tap to go online"

    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 45
    return-void
.end method

.method private bindDriverProfile(Lcyberorion/pk/Driver;)V
    .locals 5
    .param p1, "d"    # Lcyberorion/pk/Driver;

    .line 33
    iget-object v0, p1, Lcyberorion/pk/Driver;->name:Ljava/lang/String;

    if-eqz v0, :cond_0

    iget-object v0, p1, Lcyberorion/pk/Driver;->name:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_0

    iget-object v0, p1, Lcyberorion/pk/Driver;->name:Ljava/lang/String;

    goto :goto_0

    :cond_0
    const-string v0, "Driver"

    .line 34
    .local v0, "name":Ljava/lang/String;
    :goto_0
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverGreeting:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Hi, "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 35
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverAvatarInitial:Landroid/widget/TextView;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 36
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatRating:Landroid/widget/TextView;

    iget v2, p1, Lcyberorion/pk/Driver;->rating:F

    const/4 v3, 0x0

    cmpl-float v2, v2, v3

    if-lez v2, :cond_1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    iget v3, p1, Lcyberorion/pk/Driver;->rating:F

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const-string v4, "%.1f \u2605"

    invoke-static {v2, v4, v3}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    goto :goto_1

    :cond_1
    const-string v2, "New"

    :goto_1
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 37
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatTrips:Landroid/widget/TextView;

    iget v2, p1, Lcyberorion/pk/Driver;->completedTrips:I

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 38
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatVehicle:Landroid/widget/TextView;

    iget-object v2, p1, Lcyberorion/pk/Driver;->vehicleType:Ljava/lang/String;

    if-eqz v2, :cond_2

    iget-object v2, p1, Lcyberorion/pk/Driver;->vehicleType:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2

    iget-object v2, p1, Lcyberorion/pk/Driver;->vehicleType:Ljava/lang/String;

    goto :goto_2

    :cond_2
    const-string v2, "\u2014"

    :goto_2
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 39
    iget-boolean v1, p1, Lcyberorion/pk/Driver;->available:Z

    iput-boolean v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    .line 40
    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->applyAvailabilityUi()V

    .line 41
    return-void
.end method

.method private countTripOnce(Ljava/lang/String;)V
    .locals 2
    .param p1, "bookingId"    # Ljava/lang/String;

    .line 56
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->bookingsRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v0, p1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    const-string v1, "driverTripCounted"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    .local v0, "flag":Lcom/google/firebase/database/DatabaseReference;
    new-instance v1, Lcyberorion/pk/DriverDashboardActivity$4;

    invoke-direct {v1, p0}, Lcyberorion/pk/DriverDashboardActivity$4;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->runTransaction(Lcom/google/firebase/database/Transaction$Handler;)V

    return-void
.end method

.method private fare(Lcyberorion/pk/Booking;)D
    .locals 2
    .param p1, "b"    # Lcyberorion/pk/Booking;

    .line 53
    iget-object v0, p1, Lcyberorion/pk/Booking;->finalFare:Ljava/lang/Double;

    if-eqz v0, :cond_0

    iget-object v0, p1, Lcyberorion/pk/Booking;->finalFare:Ljava/lang/Double;

    :goto_0
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    goto :goto_1

    :cond_0
    iget-object v0, p1, Lcyberorion/pk/Booking;->negotiatedFare:Ljava/lang/Double;

    if-eqz v0, :cond_1

    iget-object v0, p1, Lcyberorion/pk/Booking;->negotiatedFare:Ljava/lang/Double;

    goto :goto_0

    :cond_1
    iget-wide v0, p1, Lcyberorion/pk/Booking;->estimatedFare:D

    :goto_1
    return-wide v0
.end method

.method private goToLogin()V
    .locals 2

    .line 57
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/DriverLoginActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "i":Landroid/content/Intent;
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->startActivity(Landroid/content/Intent;)V

    invoke-virtual {p0}, Lcyberorion/pk/DriverDashboardActivity;->finish()V

    return-void
.end method

.method private listenJobs()V
    .locals 2

    .line 51
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->bookingsRef:Lcom/google/firebase/database/DatabaseReference;

    const-string v1, "driverId"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->orderByChild(Ljava/lang/String;)Lcom/google/firebase/database/Query;

    move-result-object v0

    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/Query;->equalTo(Ljava/lang/String;)Lcom/google/firebase/database/Query;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/DriverDashboardActivity$3;

    invoke-direct {v1, p0}, Lcyberorion/pk/DriverDashboardActivity$3;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/Query;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    return-void
.end method

.method private refreshVisibleJobs()V
    .locals 13

    .line 52
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->visibleJobs:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const-wide/16 v0, 0x0

    .local v0, "earnings":D
    const/4 v2, 0x0

    .local v2, "paidTrips":I
    iget-object v3, p0, Lcyberorion/pk/DriverDashboardActivity;->allJobs:Ljava/util/List;

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v4, :cond_7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcyberorion/pk/Booking;

    .local v4, "b":Lcyberorion/pk/Booking;
    iget-object v8, v4, Lcyberorion/pk/Booking;->status:Ljava/lang/String;

    invoke-static {v8}, Lcyberorion/pk/BookingStatus;->fromLabel(Ljava/lang/String;)Lcyberorion/pk/BookingStatus;

    move-result-object v8

    .local v8, "st":Lcyberorion/pk/BookingStatus;
    sget-object v9, Lcyberorion/pk/BookingStatus;->DELIVERED:Lcyberorion/pk/BookingStatus;

    if-eq v8, v9, :cond_1

    sget-object v9, Lcyberorion/pk/BookingStatus;->COMPLETED:Lcyberorion/pk/BookingStatus;

    if-ne v8, v9, :cond_2

    :cond_1
    invoke-direct {p0, v4}, Lcyberorion/pk/DriverDashboardActivity;->fare(Lcyberorion/pk/Booking;)D

    move-result-wide v9

    add-double/2addr v0, v9

    add-int/lit8 v2, v2, 0x1

    :cond_2
    iget v9, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    if-nez v9, :cond_5

    sget-object v5, Lcyberorion/pk/BookingStatus;->PENDING:Lcyberorion/pk/BookingStatus;

    if-ne v8, v5, :cond_4

    :cond_3
    :goto_1
    goto :goto_2

    :cond_4
    move v6, v7

    goto :goto_2

    :cond_5
    iget v9, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    if-ne v9, v6, :cond_6

    invoke-virtual {v8}, Lcyberorion/pk/BookingStatus;->isActive()Z

    move-result v6

    goto :goto_2

    :cond_6
    iget v9, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    if-lt v9, v5, :cond_4

    sget-object v9, Lcyberorion/pk/BookingStatus;->DELIVERED:Lcyberorion/pk/BookingStatus;

    if-eq v8, v9, :cond_3

    sget-object v9, Lcyberorion/pk/BookingStatus;->COMPLETED:Lcyberorion/pk/BookingStatus;

    if-eq v8, v9, :cond_3

    iget v9, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    if-ne v9, v5, :cond_4

    sget-object v5, Lcyberorion/pk/BookingStatus;->CANCELLED:Lcyberorion/pk/BookingStatus;

    if-eq v8, v5, :cond_3

    sget-object v5, Lcyberorion/pk/BookingStatus;->REJECTED:Lcyberorion/pk/BookingStatus;

    if-ne v8, v5, :cond_4

    goto :goto_1

    .local v6, "match":Z
    :goto_2
    if-eqz v6, :cond_0

    iget-object v5, p0, Lcyberorion/pk/DriverDashboardActivity;->visibleJobs:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .end local v4    # "b":Lcyberorion/pk/Booking;
    .end local v6    # "match":Z
    .end local v8    # "st":Lcyberorion/pk/BookingStatus;
    :cond_7
    iget-object v3, p0, Lcyberorion/pk/DriverDashboardActivity;->adapter:Lcyberorion/pk/DriverJobAdapter;

    invoke-virtual {v3}, Lcyberorion/pk/DriverJobAdapter;->notifyDataSetChanged()V

    iget v3, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    const/4 v4, 0x3

    if-ne v3, v4, :cond_8

    move v3, v6

    goto :goto_3

    :cond_8
    move v3, v7

    .local v3, "earning":Z
    :goto_3
    iget-object v8, p0, Lcyberorion/pk/DriverDashboardActivity;->tvEarningsSummary:Landroid/widget/TextView;

    const/16 v9, 0x8

    if-eqz v3, :cond_9

    move v10, v7

    goto :goto_4

    :cond_9
    move v10, v9

    :goto_4
    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setVisibility(I)V

    iget-object v8, p0, Lcyberorion/pk/DriverDashboardActivity;->tvEarningsSummary:Landroid/widget/TextView;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v10

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v11

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    filled-new-array {v11, v12}, [Ljava/lang/Object;

    move-result-object v11

    const-string v12, "Total earnings: Rs. %,.0f\nCompleted paid trips: %d"

    invoke-static {v10, v12, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v8, p0, Lcyberorion/pk/DriverDashboardActivity;->visibleJobs:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->isEmpty()Z

    move-result v8

    .local v8, "empty":Z
    iget-object v10, p0, Lcyberorion/pk/DriverDashboardActivity;->emptyState:Landroid/view/View;

    if-eqz v8, :cond_a

    move v11, v7

    goto :goto_5

    :cond_a
    move v11, v9

    :goto_5
    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    iget-object v10, p0, Lcyberorion/pk/DriverDashboardActivity;->rvJobs:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v8, :cond_b

    goto :goto_6

    :cond_b
    move v9, v7

    :goto_6
    invoke-virtual {v10, v9}, Landroidx/recyclerview/widget/RecyclerView;->setVisibility(I)V

    if-eqz v8, :cond_c

    const/4 v9, 0x4

    new-array v9, v9, [Ljava/lang/String;

    const-string v10, "No available jobs right now"

    aput-object v10, v9, v7

    const-string v7, "No active trips right now"

    aput-object v7, v9, v6

    const-string v6, "No completed jobs yet"

    aput-object v6, v9, v5

    const-string v5, "No paid trips yet"

    aput-object v5, v9, v4

    .local v9, "m":[Ljava/lang/String;
    iget-object v5, p0, Lcyberorion/pk/DriverDashboardActivity;->tvEmptyMessage:Landroid/widget/TextView;

    iget v6, p0, Lcyberorion/pk/DriverDashboardActivity;->selectedTab:I

    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v4

    aget-object v4, v9, v4

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .end local v9    # "m":[Ljava/lang/String;
    :cond_c
    return-void
.end method

.method private toggleAvailability()V
    .locals 3

    .line 47
    iget-boolean v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    xor-int/lit8 v0, v0, 0x1

    .line 48
    .local v0, "next":Z
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    const-string v2, "available"

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0, v0}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda4;-><init>(Lcyberorion/pk/DriverDashboardActivity;Z)V

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda5;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    .line 49
    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnFailureListener(Lcom/google/android/gms/tasks/OnFailureListener;)Lcom/google/android/gms/tasks/Task;

    .line 50
    return-void
.end method

.method private updateStatus(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V
    .locals 3

    sget-object v0, Lcyberorion/pk/BookingStatus;->DELIVERED:Lcyberorion/pk/BookingStatus;
    if-eq p2, v0, :new_delivery_proof
    sget-object v0, Lcyberorion/pk/BookingStatus;->COMPLETED:Lcyberorion/pk/BookingStatus;
    if-ne p2, v0, :original_status_update
    :new_delivery_proof
    iget-object v0, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;
    invoke-static {p0, v0}, Lcyberorion/pk/features/FeatureEntry;->open(Landroid/app/Activity;Ljava/lang/String;)V
    return-void
    :original_status_update

    .param p1, "b"    # Lcyberorion/pk/Booking;
    .param p2, "st"    # Lcyberorion/pk/BookingStatus;

    .line 55
    iget-object v0, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .local v0, "u":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;"
    const-string v1, "status"

    iget-object v2, p2, Lcyberorion/pk/BookingStatus;->label:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "updatedAt"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->bookingsRef:Lcom/google/firebase/database/DatabaseReference;

    iget-object v2, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/google/firebase/database/DatabaseReference;->updateChildren(Ljava/util/Map;)Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda0;

    invoke-direct {v2, p0, p1, p2}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda0;-><init>(Lcyberorion/pk/DriverDashboardActivity;Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    return-void
.end method

.method private verifyAccessAndListen()V
    .locals 2

    .line 30
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    new-instance v1, Lcyberorion/pk/DriverDashboardActivity$2;

    invoke-direct {v1, p0}, Lcyberorion/pk/DriverDashboardActivity$2;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    return-void
.end method


# virtual methods
.method synthetic lambda$onCreate$0$cyberorion-pk-DriverDashboardActivity(Landroid/view/View;)V
    .locals 1
    .param p1, "v"    # Landroid/view/View;

    .line 27
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseAuth;->signOut()V

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->goToLogin()V

    return-void
.end method

.method synthetic lambda$onCreate$1$cyberorion-pk-DriverDashboardActivity(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 27
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/NotificationsActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method synthetic lambda$onCreate$2$cyberorion-pk-DriverDashboardActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 28
    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->toggleAvailability()V

    return-void
.end method

.method synthetic lambda$toggleAvailability$3$cyberorion-pk-DriverDashboardActivity(ZLjava/lang/Void;)V
    .locals 0
    .param p1, "next"    # Z
    .param p2, "v"    # Ljava/lang/Void;

    .line 48
    iput-boolean p1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverAvailable:Z

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->applyAvailabilityUi()V

    return-void
.end method

.method synthetic lambda$toggleAvailability$4$cyberorion-pk-DriverDashboardActivity(Ljava/lang/Exception;)V
    .locals 2
    .param p1, "e"    # Ljava/lang/Exception;

    .line 49
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Could not update status: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {p1}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method

.method synthetic lambda$updateStatus$5$cyberorion-pk-DriverDashboardActivity(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;Ljava/lang/Void;)V
    .locals 3
    .param p1, "b"    # Lcyberorion/pk/Booking;
    .param p2, "st"    # Lcyberorion/pk/BookingStatus;
    .param p3, "v"    # Ljava/lang/Void;

    .line 55
    iget-object v0, p1, Lcyberorion/pk/Booking;->userId:Ljava/lang/String;

    invoke-static {v0, p1, p2}, Lcyberorion/pk/NotificationHelper;->notifyStatusChange(Ljava/lang/String;Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V

    sget-object v0, Lcyberorion/pk/BookingStatus;->ACCEPTED:Lcyberorion/pk/BookingStatus;

    const-string v1, "available"

    if-ne p2, v0, :cond_0

    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    :cond_0
    sget-object v0, Lcyberorion/pk/BookingStatus;->REJECTED:Lcyberorion/pk/BookingStatus;

    if-eq p2, v0, :cond_1

    sget-object v0, Lcyberorion/pk/BookingStatus;->DELIVERED:Lcyberorion/pk/BookingStatus;

    if-eq p2, v0, :cond_1

    sget-object v0, Lcyberorion/pk/BookingStatus;->COMPLETED:Lcyberorion/pk/BookingStatus;

    if-eq p2, v0, :cond_1

    sget-object v0, Lcyberorion/pk/BookingStatus;->CANCELLED:Lcyberorion/pk/BookingStatus;

    if-ne p2, v0, :cond_2

    :cond_1
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->setValue(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    :cond_2
    sget-object v0, Lcyberorion/pk/BookingStatus;->DELIVERED:Lcyberorion/pk/BookingStatus;

    if-eq p2, v0, :cond_3

    sget-object v0, Lcyberorion/pk/BookingStatus;->COMPLETED:Lcyberorion/pk/BookingStatus;

    if-ne p2, v0, :cond_4

    :cond_3
    iget-object v0, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->countTripOnce(Ljava/lang/String;)V

    :cond_4
    return-void
.end method

.method public onAccept(Lcyberorion/pk/Booking;)V
    .locals 1
    .param p1, "b"    # Lcyberorion/pk/Booking;

    .line 54
    sget-object v0, Lcyberorion/pk/BookingStatus;->ACCEPTED:Lcyberorion/pk/BookingStatus;

    invoke-direct {p0, p1, v0}, Lcyberorion/pk/DriverDashboardActivity;->updateStatus(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V

    return-void
.end method

.method public onAdvanceStatus(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V
    .locals 0
    .param p1, "b"    # Lcyberorion/pk/Booking;
    .param p2, "s"    # Lcyberorion/pk/BookingStatus;

    .line 54
    invoke-direct {p0, p1, p2}, Lcyberorion/pk/DriverDashboardActivity;->updateStatus(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .param p1, "b"    # Landroid/os/Bundle;

    .line 21
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    sget v0, Lcyberorion/pk/R$layout;->activity_driver_dashboard:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->setContentView(I)V

    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->goToLogin()V

    invoke-static {p0}, Lcyberorion/pk/features/FeatureEntry;->attachDriverDashboard(Landroid/app/Activity;)V

    return-void

    :cond_0
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseAuth;->getCurrentUser()Lcom/google/firebase/auth/FirebaseUser;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/auth/FirebaseUser;->getUid()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->driverId:Ljava/lang/String;

    .line 22
    sget v0, Lcyberorion/pk/R$id;->rvJobs:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->rvJobs:Landroidx/recyclerview/widget/RecyclerView;

    sget v0, Lcyberorion/pk/R$id;->emptyState:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->emptyState:Landroid/view/View;

    sget v0, Lcyberorion/pk/R$id;->tvEmptyMessage:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvEmptyMessage:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->tvDriverGreeting:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverGreeting:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->tvEarningsSummary:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvEarningsSummary:Landroid/widget/TextView;

    .line 23
    sget v0, Lcyberorion/pk/R$id;->tvDriverAvatarInitial:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverAvatarInitial:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->tvDriverAvailability:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvDriverAvailability:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->dotDriverAvailability:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->dotDriverAvailability:Landroid/view/View;

    sget v0, Lcyberorion/pk/R$id;->pillDriverAvailability:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->pillDriverAvailability:Landroid/view/View;

    .line 24
    sget v0, Lcyberorion/pk/R$id;->tvStatRating:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatRating:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->tvStatTrips:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatTrips:Landroid/widget/TextView;

    sget v0, Lcyberorion/pk/R$id;->tvStatVehicle:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->tvStatVehicle:Landroid/widget/TextView;

    .line 25
    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->rvJobs:Landroidx/recyclerview/widget/RecyclerView;

    new-instance v1, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-direct {v1, p0}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    new-instance v0, Lcyberorion/pk/DriverJobAdapter;

    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->visibleJobs:Ljava/util/List;

    invoke-direct {v0, v1, p0}, Lcyberorion/pk/DriverJobAdapter;-><init>(Ljava/util/List;Lcyberorion/pk/DriverJobAdapter$OnJobActionListener;)V

    iput-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->adapter:Lcyberorion/pk/DriverJobAdapter;

    iget-object v0, p0, Lcyberorion/pk/DriverDashboardActivity;->rvJobs:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->adapter:Lcyberorion/pk/DriverJobAdapter;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 26
    sget v0, Lcyberorion/pk/R$id;->tabLayout:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/tabs/TabLayout;

    .local v0, "tabs":Lcom/google/android/material/tabs/TabLayout;
    new-instance v1, Lcyberorion/pk/DriverDashboardActivity$1;

    invoke-direct {v1, p0}, Lcyberorion/pk/DriverDashboardActivity$1;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/android/material/tabs/TabLayout;->addOnTabSelectedListener(Lcom/google/android/material/tabs/TabLayout$OnTabSelectedListener;)V

    .line 27
    sget v1, Lcyberorion/pk/R$id;->tvDriverLogout:I

    invoke-virtual {p0, v1}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda1;

    invoke-direct {v2, p0}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda1;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    sget v1, Lcyberorion/pk/R$id;->btnDriverNotifications:I

    invoke-virtual {p0, v1}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda2;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverId:Ljava/lang/String;

    sget v2, Lcyberorion/pk/R$id;->viewDriverNotifBadge:I

    invoke-virtual {p0, v2}, Lcyberorion/pk/DriverDashboardActivity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    invoke-static {v1, v2}, Lcyberorion/pk/NotificationHelper;->attachUnreadBadge(Ljava/lang/String;Landroid/view/View;)V

    .line 28
    iget-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->pillDriverAvailability:Landroid/view/View;

    new-instance v2, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcyberorion/pk/DriverDashboardActivity$$ExternalSyntheticLambda3;-><init>(Lcyberorion/pk/DriverDashboardActivity;)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 29
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v1

    const-string v2, "bookings"

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iput-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->bookingsRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v1

    const-string v2, "drivers"

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/FirebaseDatabase;->getReference(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iget-object v2, p0, Lcyberorion/pk/DriverDashboardActivity;->driverId:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iput-object v1, p0, Lcyberorion/pk/DriverDashboardActivity;->driverRef:Lcom/google/firebase/database/DatabaseReference;

    invoke-direct {p0}, Lcyberorion/pk/DriverDashboardActivity;->verifyAccessAndListen()V

    invoke-static {p0}, Lcyberorion/pk/features/FeatureEntry;->attachDriverDashboard(Landroid/app/Activity;)V

    return-void
.end method

.method public onNegotiate(Lcyberorion/pk/Booking;)V
    .locals 4
    .param p1, "b"    # Lcyberorion/pk/Booking;

    .line 54
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/NegotiationActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "i":Landroid/content/Intent;
    const-string v1, "extra_booking_id"

    iget-object v2, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "extra_role"

    const-string v2, "driver"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "extra_ai_fare"

    iget-wide v2, p1, Lcyberorion/pk/Booking;->estimatedFare:D

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;D)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onOpenTracking(Lcyberorion/pk/Booking;)V
    .locals 3
    .param p1, "b"    # Lcyberorion/pk/Booking;

    .line 54
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/TrackingActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "i":Landroid/content/Intent;
    const-string v1, "extra_booking_id"

    iget-object v2, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "extra_role"

    const-string v2, "driver"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method

.method public onReject(Lcyberorion/pk/Booking;)V
    .locals 1
    .param p1, "b"    # Lcyberorion/pk/Booking;

    .line 54
    sget-object v0, Lcyberorion/pk/BookingStatus;->REJECTED:Lcyberorion/pk/BookingStatus;

    invoke-direct {p0, p1, v0}, Lcyberorion/pk/DriverDashboardActivity;->updateStatus(Lcyberorion/pk/Booking;Lcyberorion/pk/BookingStatus;)V

    return-void
.end method

.method public onVerifyDamage(Lcyberorion/pk/Booking;Ljava/lang/String;)V
    .locals 3
    .param p1, "b"    # Lcyberorion/pk/Booking;
    .param p2, "stage"    # Ljava/lang/String;

    .line 54
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/DamageVerificationActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .local v0, "i":Landroid/content/Intent;
    const-string v1, "extra_booking_id"

    iget-object v2, p1, Lcyberorion/pk/Booking;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v1, "extra_damage_stage"

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0, v0}, Lcyberorion/pk/DriverDashboardActivity;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
