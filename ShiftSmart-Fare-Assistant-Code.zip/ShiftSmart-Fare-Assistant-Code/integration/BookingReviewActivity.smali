.class public Lcyberorion/pk/BookingReviewActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "BookingReviewActivity.java"


# static fields
.field private static final PICK_PDF_REQUEST:I = 0x65


# instance fields
.field private bookingId:Ljava/lang/String;

.field private btnConfirmBooking:Landroid/widget/Button;

.field private btnDeleteNOC:Lcom/google/android/material/button/MaterialButton;

.field private btnNegotiate:Lcom/google/android/material/button/MaterialButton;

.field private btnPreviewNOC:Lcom/google/android/material/button/MaterialButton;

.field private btnReplaceNOC:Lcom/google/android/material/button/MaterialButton;

.field private btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

.field private cargoSelection:Lcyberorion/pk/CargoSelection;

.field private distanceKm:Ljava/lang/Double;

.field private driverId:Ljava/lang/String;

.field private driverName:Ljava/lang/String;

.field private dropoff:Ljava/lang/String;

.field private estimatedDurationMin:I

.field private estimatedFare:D

.field private etInstructions:Lcom/google/android/material/textfield/TextInputEditText;

.field private finalFare:Ljava/lang/Double;

.field private layoutNocActions:Landroid/view/View;

.field private layoutNocNotice:Landroid/view/View;

.field private luggageType:Ljava/lang/String;

.field private mAuth:Lcom/google/firebase/auth/FirebaseAuth;

.field private mDatabase:Lcom/google/firebase/database/DatabaseReference;

.field private nocFileUri:Landroid/net/Uri;

.field private nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

.field private pickup:Ljava/lang/String;

.field private tvDamageRiskPreview:Landroid/widget/TextView;

.field private tvNOCStatus:Landroid/widget/TextView;

.field private tvNocNoticeReason:Landroid/widget/TextView;

.field private tvNocNoticeTitle:Landroid/widget/TextView;

.field private tvReviewFare:Landroid/widget/TextView;

.field private tvReviewFinalFare:Landroid/widget/TextView;

.field private tvSummaryDriver:Landroid/widget/TextView;

.field private tvSummaryLuggage:Landroid/widget/TextView;

.field private tvSummaryRoute:Landroid/widget/TextView;

.field private vehicleCapacity:D

.field private vehicleNumber:Ljava/lang/String;

.field private vehicleType:Ljava/lang/String;


# direct methods
.method static bridge synthetic -$$Nest$fgettvReviewFinalFare(Lcyberorion/pk/BookingReviewActivity;)Landroid/widget/TextView;
    .locals 0

    iget-object p0, p0, Lcyberorion/pk/BookingReviewActivity;->tvReviewFinalFare:Landroid/widget/TextView;

    return-object p0
.end method

.method static bridge synthetic -$$Nest$fputfinalFare(Lcyberorion/pk/BookingReviewActivity;Ljava/lang/Double;)V
    .locals 0

    iput-object p1, p0, Lcyberorion/pk/BookingReviewActivity;->finalFare:Ljava/lang/Double;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 24
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method

.method private applyNocRequirementToUi()V
    .locals 3

    .line 124
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    iget-boolean v0, v0, Lcyberorion/pk/NocPolicy$NocRequirement;->required:Z

    .line 129
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->layoutNocNotice:Landroid/view/View;

    .line 124
    const/4 v2, 0x0

    if-eqz v0, :cond_0

    .line 125
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 126
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeTitle:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->noc_required_title:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 127
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeReason:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->noc_required_reason_format:I

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    invoke-virtual {v2}, Lcyberorion/pk/NocPolicy$NocRequirement;->reasonSummary()Ljava/lang/String;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 129
    :cond_0
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 130
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeTitle:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->noc_not_required_title:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 131
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeReason:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->noc_not_required_message:I

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(I)V

    .line 133
    :goto_0
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->refreshNocFileUi()V

    .line 134
    return-void
.end method

.method private confirmBooking()V
    .locals 3

    .line 231
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    iget-boolean v0, v0, Lcyberorion/pk/NocPolicy$NocRequirement;->required:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    if-nez v0, :cond_0

    .line 232
    sget v0, Lcyberorion/pk/R$string;->noc_missing_toast:I

    const/4 v1, 0x1

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 233
    return-void

    .line 235
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_1

    .line 236
    const-string v0, "Booking reference missing. Please go back and try again."

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 237
    return-void

    .line 239
    :cond_1
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    invoke-virtual {v0}, Landroid/widget/Button;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_2

    return-void

    .line 241
    :cond_2
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 242
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    sget v1, Lcyberorion/pk/R$string;->confirming_booking:I

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 244
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 245
    .local v0, "bookingUpdates":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/Object;>;"
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->etInstructions:Lcom/google/android/material/textfield/TextInputEditText;

    invoke-virtual {v1}, Lcom/google/android/material/textfield/TextInputEditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const-string v2, "specialInstructions"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 246
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    iget-boolean v1, v1, Lcyberorion/pk/NocPolicy$NocRequirement;->required:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const-string v2, "nocRequired"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    invoke-virtual {v1}, Lcyberorion/pk/NocPolicy$NocRequirement;->reasonSummary()Ljava/lang/String;

    move-result-object v1

    const-string v2, "nocReasons"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    if-eqz v1, :cond_3

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_0

    :cond_3
    const-string v1, ""

    :goto_0
    const-string v2, "nocUri"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 249
    sget-object v1, Lcyberorion/pk/BookingStatus;->PENDING:Lcyberorion/pk/BookingStatus;

    iget-object v1, v1, Lcyberorion/pk/BookingStatus;->label:Ljava/lang/String;

    const-string v2, "status"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 250
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const-string v2, "updatedAt"

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 251
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->finalFare:Ljava/lang/Double;

    if-eqz v1, :cond_4

    .line 252
    const-string v1, "finalFare"

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->finalFare:Ljava/lang/Double;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 255
    :cond_4
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->mDatabase:Lcom/google/firebase/database/DatabaseReference;

    const-string v2, "bookings"

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v1, v2}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/google/firebase/database/DatabaseReference;->updateChildren(Ljava/util/Map;)Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda7;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda7;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    .line 256
    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    .line 265
    return-void
.end method

.method private displayNameForUri(Landroid/net/Uri;)Ljava/lang/String;
    .locals 2
    .param p1, "uri"    # Landroid/net/Uri;

    .line 151
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    move-result-object v0

    .line 152
    .local v0, "segment":Ljava/lang/String;
    if-eqz v0, :cond_0

    move-object v1, v0

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    :goto_0
    return-object v1
.end method

.method private listenForFinalFare()V
    .locals 2

    .line 210
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    .line 211
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->mDatabase:Lcom/google/firebase/database/DatabaseReference;

    const-string v1, "bookings"

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->child(Ljava/lang/String;)Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/BookingReviewActivity$1;

    invoke-direct {v1, p0}, Lcyberorion/pk/BookingReviewActivity$1;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    .line 212
    invoke-virtual {v0, v1}, Lcom/google/firebase/database/DatabaseReference;->addValueEventListener(Lcom/google/firebase/database/ValueEventListener;)Lcom/google/firebase/database/ValueEventListener;

    .line 228
    return-void
.end method

.method private openFilePicker()V
    .locals 3

    .line 156
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.GET_CONTENT"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 157
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "application/pdf"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 158
    const-string v1, "android.intent.category.OPENABLE"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    .line 159
    const-string v1, "Select NOC Document"

    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v1

    const/16 v2, 0x65

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->startActivityForResult(Landroid/content/Intent;I)V

    .line 160
    return-void
.end method

.method private openNegotiation()V
    .locals 4

    .line 200
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    if-nez v0, :cond_0

    return-void

    .line 201
    :cond_0
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/NegotiationActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 202
    .local v0, "intent":Landroid/content/Intent;
    const-string v1, "extra_booking_id"

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 203
    const-string v1, "extra_role"

    const-string v2, "customer"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 204
    const-string v1, "extra_ai_fare"

    iget-wide v2, p0, Lcyberorion/pk/BookingReviewActivity;->estimatedFare:D

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;D)Landroid/content/Intent;

    .line 205
    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->startActivity(Landroid/content/Intent;)V

    .line 206
    return-void
.end method

.method private previewNoc()V
    .locals 3

    .line 163
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    if-nez v0, :cond_0

    return-void

    .line 165
    :cond_0
    :try_start_0
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 166
    .local v0, "intent":Landroid/content/Intent;
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    const-string v2, "application/pdf"

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    .line 167
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 168
    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 171
    .end local v0    # "intent":Landroid/content/Intent;
    goto :goto_0

    .line 169
    :catch_0
    move-exception v0

    .line 170
    .local v0, "e":Landroid/content/ActivityNotFoundException;
    sget v1, Lcyberorion/pk/R$string;->noc_no_viewer_message:I

    const/4 v2, 0x0

    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v1

    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 172
    .end local v0    # "e":Landroid/content/ActivityNotFoundException;
    :goto_0
    return-void
.end method

.method private refreshNocFileUi()V
    .locals 5

    .line 138
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    .line 143
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->tvNOCStatus:Landroid/widget/TextView;

    .line 138
    const/16 v2, 0x8

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    .line 139
    sget v0, Lcyberorion/pk/R$string;->noc_selected_format:I

    iget-object v4, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    invoke-direct {p0, v4}, Lcyberorion/pk/BookingReviewActivity;->displayNameForUri(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v4

    filled-new-array {v4}, [Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {p0, v0, v4}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 140
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

    invoke-virtual {v0, v2}, Lcom/google/android/material/button/MaterialButton;->setVisibility(I)V

    .line 141
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->layoutNocActions:Landroid/view/View;

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    goto :goto_0

    .line 143
    :cond_0
    sget v0, Lcyberorion/pk/R$string;->no_file_selected:I

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(I)V

    .line 144
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

    invoke-virtual {v0, v3}, Lcom/google/android/material/button/MaterialButton;->setVisibility(I)V

    .line 145
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

    sget v1, Lcyberorion/pk/R$string;->upload_noc:I

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setText(I)V

    .line 146
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->layoutNocActions:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 148
    :goto_0
    return-void
.end method

.method private removeNoc()V
    .locals 2

    .line 175
    const/4 v0, 0x0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    .line 176
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->refreshNocFileUi()V

    .line 177
    sget v0, Lcyberorion/pk/R$string;->noc_removed_message:I

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 178
    return-void
.end method

.method private showConfirmationDialog()V
    .locals 3

    .line 268
    new-instance v0, Landroidx/appcompat/app/AlertDialog$Builder;

    invoke-direct {v0, p0}, Landroidx/appcompat/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    sget v1, Lcyberorion/pk/R$drawable;->ic_check_circle:I

    .line 269
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setIcon(I)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcyberorion/pk/R$string;->booking_confirmed_title:I

    .line 270
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setTitle(I)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    sget v1, Lcyberorion/pk/R$string;->booking_confirmed_msg:I

    .line 271
    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setMessage(I)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda0;

    invoke-direct {v1, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda0;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    .line 272
    const-string v2, "Track Order"

    invoke-virtual {v0, v2, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 277
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/app/AlertDialog$Builder;->setCancelable(Z)Landroidx/appcompat/app/AlertDialog$Builder;

    move-result-object v0

    .line 278
    invoke-virtual {v0}, Landroidx/appcompat/app/AlertDialog$Builder;->show()Landroidx/appcompat/app/AlertDialog;

    .line 279
    return-void
.end method


# virtual methods
.method synthetic lambda$confirmBooking$6$cyberorion-pk-BookingReviewActivity(Lcom/google/android/gms/tasks/Task;)V
    .locals 2
    .param p1, "task"    # Lcom/google/android/gms/tasks/Task;

    .line 257
    invoke-virtual {p1}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 258
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->showConfirmationDialog()V

    goto :goto_0

    .line 260
    :cond_0
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 261
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    sget v1, Lcyberorion/pk/R$string;->confirm_booking:I

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(I)V

    .line 262
    const-string v0, "Booking failed. Please try again."

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 264
    :goto_0
    return-void
.end method

.method synthetic lambda$onCreate$0$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 98
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->openNegotiation()V

    return-void
.end method

.method synthetic lambda$onCreate$1$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 115
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->openFilePicker()V

    return-void
.end method

.method synthetic lambda$onCreate$2$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 116
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->openFilePicker()V

    return-void
.end method

.method synthetic lambda$onCreate$3$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 117
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->previewNoc()V

    return-void
.end method

.method synthetic lambda$onCreate$4$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 118
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->removeNoc()V

    return-void
.end method

.method synthetic lambda$onCreate$5$cyberorion-pk-BookingReviewActivity(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 119
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->confirmBooking()V

    return-void
.end method

.method synthetic lambda$showConfirmationDialog$7$cyberorion-pk-BookingReviewActivity(Landroid/content/DialogInterface;I)V
    .locals 2
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .line 273
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcyberorion/pk/TrackOrderActivity;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 274
    .local v0, "intent":Landroid/content/Intent;
    const v1, 0x10008000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 275
    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->startActivity(Landroid/content/Intent;)V

    .line 276
    return-void
.end method

.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 3
    .param p1, "requestCode"    # I
    .param p2, "resultCode"    # I
    .param p3, "data"    # Landroid/content/Intent;

    .line 182
    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/app/AppCompatActivity;->onActivityResult(IILandroid/content/Intent;)V

    .line 183
    const/16 v0, 0x65

    if-ne p1, v0, :cond_0

    const/4 v0, -0x1

    if-ne p2, v0, :cond_0

    if-eqz p3, :cond_0

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 184
    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    .line 188
    :try_start_0
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v0

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocFileUri:Landroid/net/Uri;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentResolver;->takePersistableUriPermission(Landroid/net/Uri;I)V
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 192
    goto :goto_0

    .line 189
    :catch_0
    move-exception v0

    .line 193
    :goto_0
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->refreshNocFileUi()V

    .line 194
    sget v0, Lcyberorion/pk/R$string;->noc_linked_message:I

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 196
    :cond_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .line 56
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    .line 57
    sget v0, Lcyberorion/pk/R$layout;->activity_booking_review:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->setContentView(I)V

    .line 59
    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->mAuth:Lcom/google/firebase/auth/FirebaseAuth;

    .line 60
    invoke-static {}, Lcom/google/firebase/database/FirebaseDatabase;->getInstance()Lcom/google/firebase/database/FirebaseDatabase;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/firebase/database/FirebaseDatabase;->getReference()Lcom/google/firebase/database/DatabaseReference;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->mDatabase:Lcom/google/firebase/database/DatabaseReference;

    .line 62
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_booking_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->bookingId:Ljava/lang/String;

    .line 63
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_pickup"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->pickup:Ljava/lang/String;

    .line 64
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_dropoff"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->dropoff:Ljava/lang/String;

    .line 65
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_luggage_type"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->luggageType:Ljava/lang/String;

    .line 66
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_driver_id"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->driverId:Ljava/lang/String;

    .line 67
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_driver_name"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->driverName:Ljava/lang/String;

    .line 68
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_vehicle_type"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->vehicleType:Ljava/lang/String;

    .line 69
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_vehicle_number"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->vehicleNumber:Ljava/lang/String;

    .line 70
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_vehicle_capacity"

    const-wide/16 v2, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v0

    iput-wide v0, p0, Lcyberorion/pk/BookingReviewActivity;->vehicleCapacity:D

    .line 71
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_cargo_selection"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v0

    check-cast v0, Lcyberorion/pk/CargoSelection;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->cargoSelection:Lcyberorion/pk/CargoSelection;

    .line 72
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_distance_km"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 73
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    goto :goto_0

    .line 74
    :cond_0
    const/4 v0, 0x0

    :goto_0
    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->distanceKm:Ljava/lang/Double;

    .line 75
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_estimated_fare"

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getDoubleExtra(Ljava/lang/String;D)D

    move-result-wide v0

    iput-wide v0, p0, Lcyberorion/pk/BookingReviewActivity;->estimatedFare:D

    .line 76
    invoke-virtual {p0}, Lcyberorion/pk/BookingReviewActivity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const-string v1, "extra_estimated_duration_min"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    iput v0, p0, Lcyberorion/pk/BookingReviewActivity;->estimatedDurationMin:I

    .line 78
    sget v0, Lcyberorion/pk/R$id;->tvSummaryRoute:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryRoute:Landroid/widget/TextView;

    .line 79
    sget v0, Lcyberorion/pk/R$id;->tvSummaryLuggage:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryLuggage:Landroid/widget/TextView;

    .line 80
    sget v0, Lcyberorion/pk/R$id;->tvSummaryDriver:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryDriver:Landroid/widget/TextView;

    .line 81
    sget v0, Lcyberorion/pk/R$id;->tvReviewFare:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvReviewFare:Landroid/widget/TextView;

    .line 82
    sget v0, Lcyberorion/pk/R$id;->tvReviewFinalFare:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvReviewFinalFare:Landroid/widget/TextView;

    .line 83
    sget v0, Lcyberorion/pk/R$id;->tvDamageRiskPreview:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvDamageRiskPreview:Landroid/widget/TextView;

    .line 84
    sget v0, Lcyberorion/pk/R$id;->btnNegotiate:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnNegotiate:Lcom/google/android/material/button/MaterialButton;

    .line 85
    sget v0, Lcyberorion/pk/R$id;->etInstructions:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/textfield/TextInputEditText;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->etInstructions:Lcom/google/android/material/textfield/TextInputEditText;

    .line 86
    sget v0, Lcyberorion/pk/R$id;->btnUploadNOC:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

    .line 87
    sget v0, Lcyberorion/pk/R$id;->btnConfirmBooking:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    .line 88
    sget v0, Lcyberorion/pk/R$id;->tvNOCStatus:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNOCStatus:Landroid/widget/TextView;

    .line 89
    sget v0, Lcyberorion/pk/R$id;->layoutNocNotice:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->layoutNocNotice:Landroid/view/View;

    .line 90
    sget v0, Lcyberorion/pk/R$id;->tvNocNoticeTitle:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeTitle:Landroid/widget/TextView;

    .line 91
    sget v0, Lcyberorion/pk/R$id;->tvNocNoticeReason:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvNocNoticeReason:Landroid/widget/TextView;

    .line 92
    sget v0, Lcyberorion/pk/R$id;->layoutNocActions:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->layoutNocActions:Landroid/view/View;

    .line 93
    sget v0, Lcyberorion/pk/R$id;->btnPreviewNOC:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnPreviewNOC:Lcom/google/android/material/button/MaterialButton;

    .line 94
    sget v0, Lcyberorion/pk/R$id;->btnReplaceNOC:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnReplaceNOC:Lcom/google/android/material/button/MaterialButton;

    .line 95
    sget v0, Lcyberorion/pk/R$id;->btnDeleteNOC:I

    invoke-virtual {p0, v0}, Lcyberorion/pk/BookingReviewActivity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/google/android/material/button/MaterialButton;

    iput-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnDeleteNOC:Lcom/google/android/material/button/MaterialButton;

    .line 97
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvReviewFare:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->fare_amount_format:I

    iget-wide v2, p0, Lcyberorion/pk/BookingReviewActivity;->estimatedFare:D

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 98
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->btnNegotiate:Lcom/google/android/material/button/MaterialButton;

    new-instance v1, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda1;

    invoke-direct {v1, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda1;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v0, v1}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 99
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->listenForFinalFare()V

    .line 101
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryRoute:Landroid/widget/TextView;

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->distanceKm:Ljava/lang/Double;

    if-eqz v1, :cond_1

    .line 102
    sget v1, Lcyberorion/pk/R$string;->route_with_distance_format:I

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->pickup:Ljava/lang/String;

    iget-object v3, p0, Lcyberorion/pk/BookingReviewActivity;->dropoff:Ljava/lang/String;

    iget-object v4, p0, Lcyberorion/pk/BookingReviewActivity;->distanceKm:Ljava/lang/Double;

    filled-new-array {v2, v3, v4}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    goto :goto_1

    .line 103
    :cond_1
    sget v1, Lcyberorion/pk/R$string;->route_format:I

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->pickup:Ljava/lang/String;

    iget-object v3, p0, Lcyberorion/pk/BookingReviewActivity;->dropoff:Ljava/lang/String;

    filled-new-array {v2, v3}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    .line 101
    :goto_1
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 104
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryLuggage:Landroid/widget/TextView;

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->cargoSelection:Lcyberorion/pk/CargoSelection;

    if-eqz v1, :cond_2

    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->cargoSelection:Lcyberorion/pk/CargoSelection;

    invoke-virtual {v1}, Lcyberorion/pk/CargoSelection;->summaryLine()Ljava/lang/String;

    move-result-object v1

    goto :goto_2

    :cond_2
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->luggageType:Ljava/lang/String;

    :goto_2
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 105
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->tvSummaryDriver:Landroid/widget/TextView;

    sget v1, Lcyberorion/pk/R$string;->summary_driver_format:I

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->driverName:Ljava/lang/String;

    iget-object v3, p0, Lcyberorion/pk/BookingReviewActivity;->vehicleType:Ljava/lang/String;

    iget-object v4, p0, Lcyberorion/pk/BookingReviewActivity;->vehicleNumber:Ljava/lang/String;

    filled-new-array {v2, v3, v4}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {p0, v1, v2}, Lcyberorion/pk/BookingReviewActivity;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 106
    iget-object v0, p0, Lcyberorion/pk/BookingReviewActivity;->cargoSelection:Lcyberorion/pk/CargoSelection;

    invoke-static {v0}, Lcyberorion/pk/DamageRiskScorer;->assess(Lcyberorion/pk/CargoSelection;)Lcyberorion/pk/DamageRiskAssessment;

    move-result-object v0

    .line 107
    .local v0, "damageRisk":Lcyberorion/pk/DamageRiskAssessment;
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->tvDamageRiskPreview:Landroid/widget/TextView;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "Damage Risk: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v0, Lcyberorion/pk/DamageRiskAssessment;->level:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " ("

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget v3, v0, Lcyberorion/pk/DamageRiskAssessment;->score:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, "/100) \u2022 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, v0, Lcyberorion/pk/DamageRiskAssessment;->recommendation:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 112
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->cargoSelection:Lcyberorion/pk/CargoSelection;

    iget-object v2, p0, Lcyberorion/pk/BookingReviewActivity;->distanceKm:Ljava/lang/Double;

    invoke-static {v1, v2}, Lcyberorion/pk/NocPolicy;->evaluate(Lcyberorion/pk/CargoSelection;Ljava/lang/Double;)Lcyberorion/pk/NocPolicy$NocRequirement;

    move-result-object v1

    iput-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->nocRequirement:Lcyberorion/pk/NocPolicy$NocRequirement;

    .line 113
    invoke-direct {p0}, Lcyberorion/pk/BookingReviewActivity;->applyNocRequirementToUi()V

    .line 115
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->btnUploadNOC:Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda2;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda2;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 116
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->btnReplaceNOC:Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda3;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda3;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 117
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->btnPreviewNOC:Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda4;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda4;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 118
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->btnDeleteNOC:Lcom/google/android/material/button/MaterialButton;

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda5;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda5;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v1, v2}, Lcom/google/android/material/button/MaterialButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 119
    iget-object v1, p0, Lcyberorion/pk/BookingReviewActivity;->btnConfirmBooking:Landroid/widget/Button;

    new-instance v2, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda6;

    invoke-direct {v2, p0}, Lcyberorion/pk/BookingReviewActivity$$ExternalSyntheticLambda6;-><init>(Lcyberorion/pk/BookingReviewActivity;)V

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 120
    invoke-static {p0}, Lcyberorion/pk/features/FeatureEntry;->attach(Landroid/app/Activity;)V

    return-void
.end method
