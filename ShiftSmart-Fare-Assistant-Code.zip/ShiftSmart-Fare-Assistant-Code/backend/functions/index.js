"use strict";

const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const { onValueCreated, onValueWritten } = require("firebase-functions/v2/database");
const { addReview, addCompletedTrip } = require("./aggregate");
initializeApp();

// Deploy to the region of the project's Realtime Database.
// The sample uses us-central1; change this before deployment if required.
const region = "us-central1";

exports.updateDriverRating = onValueCreated({ ref: "/bookings/{bookingId}/serviceExtras/review", region, retry: true }, async event => {
  const review = event.data.val();
  const booking = (await event.data.ref.parent.parent.get()).val();
  if (!booking || booking.status !== "Completed" || review.customerId !== booking.userId || review.driverId !== booking.driverId) {
    throw new Error("Review does not match a completed booking");
  }
  const driver = getDatabase().ref(`drivers/${booking.driverId}`);
  const result = await driver.transaction(current => current ? addReview(current, event.params.bookingId, review) : undefined);
  if (!result.committed) throw new Error("Driver profile missing; rating was not updated");
});

exports.recordCompletedTrip = onValueWritten({ ref: "/bookings/{bookingId}/status", region, retry: true }, async event => {
  if (event.data.after.val() !== "Completed" || event.data.before.val() === "Completed") return;
  const bookingRef = event.data.after.ref.parent;
  const booking = (await bookingRef.get()).val();
  if (!booking || !booking.driverId) return;
  // The legacy driver already counts its own completion path. Only handle new proof confirmations.
  if (!booking.serviceExtras || !booking.serviceExtras.proof || !booking.serviceExtras.proof.confirmedBy) return;
  const driver = getDatabase().ref(`drivers/${booking.driverId}`);
  const result = await driver.transaction(current => current
    ? addCompletedTrip(current, event.params.bookingId, booking.driverTripCounted === true)
    : undefined);
  if (result.committed) await bookingRef.child("driverTripCounted").set(true);
  // Availability stays an explicit driver control, avoiding re-enabling a driver on another trip.
});
