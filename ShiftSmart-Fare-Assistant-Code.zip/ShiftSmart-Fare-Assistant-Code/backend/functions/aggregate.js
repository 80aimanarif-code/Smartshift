"use strict";

// A retry of the same event must never increase the count twice.
function addReview(driver, bookingId, review) {
  if (!driver || !Number.isInteger(review.stars) || review.stars < 1 || review.stars > 5) {
    throw new Error("Invalid driver review");
  }
  const next = { ...driver };
  const ledger = { ...(next.reviewLedger || {}) };
  if (Object.prototype.hasOwnProperty.call(ledger, bookingId)) return driver;
  ledger[bookingId] = review.stars;
  const scores = Object.values(ledger);
  if (scores.some(value => !Number.isInteger(value) || value < 1 || value > 5)) throw new Error("Invalid review ledger");
  next.reviewLedger = ledger;
  next.ratingCount = scores.length;
  next.ratingTotal = scores.reduce((sum, score) => sum + score, 0);
  next.rating = next.ratingTotal / next.ratingCount;
  return next;
}

function addCompletedTrip(driver, bookingId, previouslyCounted) {
  if (!driver) throw new Error("Driver profile missing");
  const ledger = { ...(driver.completedBookingLedger || {}) };
  if (ledger[bookingId]) return driver;
  ledger[bookingId] = true;
  return {
    ...driver,
    completedBookingLedger: ledger,
    completedTrips: (Number(driver.completedTrips) || 0) + (previouslyCounted ? 0 : 1)
  };
}

module.exports = { addReview, addCompletedTrip };
