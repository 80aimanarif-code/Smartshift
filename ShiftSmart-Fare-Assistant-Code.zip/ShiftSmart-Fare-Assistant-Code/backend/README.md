# Firebase setup required

No Firebase account was provided. Nothing has been deployed and the live database was not contacted during development. The APK retains its original Firebase configuration. Authenticated test accounts and project-owner access are required for complete workflow testing.

## Server functions

Deploy the supplied functions to update the existing driver rating display and count new customer-confirmed completions. Both use booking IDs to avoid counting retries twice. Set the function region to match the Realtime Database, install packages with Node 22, and test with the Emulator Suite before deploying the two named functions. Do not replace unrelated existing functions. Check the project's Cloud Functions billing requirements. Driver availability remains an explicit driver control.

## Database rules must be merged and tested

The Java transaction checks are not production authorization. The project owner must inspect the actual rules and enforce these constraints on the server:

- Only the booking customer and assigned driver can read private extras and chat. A broad ancestor read/write grant must be removed or narrowed; child rules cannot revoke it.
- Customer-only service, stop and schedule edits are limited to Pending bookings. Allow 1-10 workers when required, at most 3 addresses of 5-200 characters, and pickup times between 30 minutes and 90 days ahead.
- Validate tariffs and totals server-side: packing 50,000 paisa per worker, unpacking 30,000, and 6,000 paisa per entered additional kilometre. Distance must be 0-500 km. Total must equal base plus packing and distance fees and match finalFare. Negotiation must retain surcharges.
- Only the assigned driver can update service progress, stop progress and delivery proof. Cap the compressed photo at 240,000 base64 characters. All stops must finish before final proof. Only the customer can confirm receipt and completion.
- Customer chooses JazzCash demo, Easypaisa demo, bank-transfer demo or cash. Digital choices are simulations and must remain pending; no real gateway/account is connected. The assigned driver records actual cash receipt only after completion. Amount must match the fare. Paid receipts cannot be changed or deleted.
- Customer creates one immutable review after completion: 1-5 stars, at most 500 comment characters, and matching customer/driver IDs. No deletion or overwrite, including parent deletion.
- Driver rating aggregates and review/trip ledgers are server-owned. Existing profile writes must preserve them.
- Reject invalid state transitions, ID changes, unrelated field changes, and removal of confirmed proof, paid receipts or reviews. Enforce server timestamp bounds.

Run allowed and rejected two-user emulator tests, including direct malicious writes. A chat rules fragment is supplied separately. It is not a replacement for the complete existing ruleset. The APK remains a review build until backend rules and functions are deployed and verified.

## Photos and maps

This build saves a small compressed JPEG in Realtime Database, allowing the other participant to see it on another device. It does not save a device-local URI as delivery proof. For production, use private Cloud Storage objects to reduce database bandwidth.

The original Maps API key is empty. Configure a valid key and register the review APK signing certificate where authentication or Maps restrictions require it. Original Firebase permissions, connectivity and maps behavior are unverified.
