# UI and driver approval fixes

## Step 2 cargo cards

- All category cards use the same fixed height.
- Long names can use two lines and descriptions can use three lines.
- Electronics, Glass Items and Appliances no longer depend on recycled content height.

## Driver approval

1. Driver signup creates a record under `drivers/{uid}` with `approvalStatus = pending`.
2. The admin dashboard reads pending records and shows their count on the Driver approvals button.
3. The admin opens Driver approvals and sees photo, email, vehicle, rating, trips and experience.
4. Approve changes the record to approved and enables availability. Reject keeps the driver offline.
5. Driver login blocks pending and rejected accounts.

## Booking services screen

- Route arrows and separators use characters that render correctly on the target device.
- Empty packing and extra-stop sections show a short message.
- Demo payment account details only appear for the customer who is selecting a method.
- The screen uses compact spacing and the app's green action buttons.

## Mapbox route

- Step 4 searches pickup, optional middle stop and drop-off locations in Pakistan.
- Mapbox Directions supplies driving distance rather than straight-line distance.
- The longer route updates the booking distance and additional fare display.
- The old Google map view and separate route button are hidden.
- The same map card automatically shows pickup, optional stop, drop-off and the Mapbox route line after typing stops.
- Route results show estimated travel duration and arrival day/date/time.
- Driver status changes save when the driver accepted, left for pickup, picked up and started delivery.
- The expected arrival is recalculated from the actual Out for Delivery time.
- Live Tracking uses Mapbox instead of the visible Google MapView.
- The truck marker follows Firebase location updates and reports remaining road distance, minutes and live arrival time.
- Before pickup the driver is routed to the pickup point; after pickup the truck is routed to drop-off.
- A location older than two minutes is marked as delayed.
